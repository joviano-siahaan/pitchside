<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttPhysicalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('att_physicals', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('speed');
            $table->unsignedInteger('balance');
            $table->unsignedInteger('strength');
            $table->unsignedInteger('durability');
            $table->unsignedInteger('agility');
            $table->unsignedInteger('power');
            $table->unsignedInteger('stamina');
            $table->unsignedInteger('jumping');
            $table->unsignedInteger('players_id');
            $table->foreign('players_id')->references('id')->on('players')->onDelete('cascade');      
            $table->unsignedInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users');                                                        
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('att_physicals');
    }
}
