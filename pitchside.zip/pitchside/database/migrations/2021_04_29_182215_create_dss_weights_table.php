<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDssWeightsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dss_weights', function (Blueprint $table) {
            $table->increments('id');

            $table->unsignedDecimal('gk_speed', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_balance', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_strength', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_durability', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_agility', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_power', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_stamina', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_jumping', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_control', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_long_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_shot_acc', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_heading', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_tackle', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_catching', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_reflex', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_positioning', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_creative', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_determination', $precision = 8, $scale = 2);
            $table->unsignedDecimal('gk_reading', $precision = 8, $scale = 2);

            $table->unsignedDecimal('def_speed', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_balance', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_strength', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_durability', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_agility', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_power', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_stamina', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_jumping', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_control', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_long_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_shot_acc', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_heading', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_tackle', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_catching', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_reflex', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_positioning', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_creative', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_determination', $precision = 8, $scale = 2);
            $table->unsignedDecimal('def_reading', $precision = 8, $scale = 2);

            $table->unsignedDecimal('dm_speed', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_balance', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_strength', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_durability', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_agility', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_power', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_stamina', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_jumping', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_control', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_long_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_shot_acc', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_heading', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_tackle', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_catching', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_reflex', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_positioning', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_creative', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_determination', $precision = 8, $scale = 2);
            $table->unsignedDecimal('dm_reading', $precision = 8, $scale = 2);

            $table->unsignedDecimal('am_speed', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_balance', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_strength', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_durability', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_agility', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_power', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_stamina', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_jumping', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_control', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_long_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_shot_acc', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_heading', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_tackle', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_catching', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_reflex', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_positioning', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_creative', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_determination', $precision = 8, $scale = 2);
            $table->unsignedDecimal('am_reading', $precision = 8, $scale = 2);

            $table->unsignedDecimal('wing_speed', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_balance', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_strength', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_durability', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_agility', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_power', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_stamina', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_jumping', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_control', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_long_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_shot_acc', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_heading', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_tackle', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_catching', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_reflex', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_positioning', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_creative', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_determination', $precision = 8, $scale = 2);
            $table->unsignedDecimal('wing_reading', $precision = 8, $scale = 2);

            $table->unsignedDecimal('st_speed', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_balance', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_strength', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_durability', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_agility', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_power', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_stamina', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_jumping', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_control', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_long_pass', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_shot_acc', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_heading', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_tackle', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_catching', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_reflex', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_positioning', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_creative', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_determination', $precision = 8, $scale = 2);
            $table->unsignedDecimal('st_reading', $precision = 8, $scale = 2);

            $table->unsignedInteger('userPref_id');
            $table->foreign('userPref_id')->references('id')->on('users')->onDelete('cascade');      
            $table->unsignedInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users');                                                        
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dss_weights');
    }
}
