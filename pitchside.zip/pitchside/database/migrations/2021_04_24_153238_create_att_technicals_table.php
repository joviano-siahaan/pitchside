<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttTechnicalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('att_technicals', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('pass');
            $table->unsignedInteger('control');
            $table->unsignedInteger('long_pass');
            $table->unsignedInteger('shot_acc');
            $table->unsignedInteger('heading');
            $table->unsignedInteger('tackle');
            $table->unsignedInteger('catching');
            $table->unsignedInteger('reflex');
            $table->unsignedInteger('players_id');
            $table->foreign('players_id')->references('id')->on('players')->onDelete('cascade');      
            $table->unsignedInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users');                                                        
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('att_technicals');
    }
}
