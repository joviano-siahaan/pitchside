<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePlayerStatsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('player_stats', function (Blueprint $table) {
            $table->increments('id');

            //General

            $table->unsignedInteger('min_played');
            $table->unsignedInteger('goals');
            $table->unsignedInteger('assist');
            $table->unsignedInteger('goals_conceded');
            $table->unsignedInteger('own_goals');            
            $table->unsignedInteger('yellow_c');
            $table->unsignedInteger('red_c');

            //Involvement

            $table->unsignedInteger('touches_t');
            $table->unsignedInteger('touches_opp_half');
            $table->unsignedInteger('touches_f3');
            $table->unsignedInteger('min_touches');

            $table->unsignedInteger('pass_received_t');
            $table->unsignedInteger('pass_received_opp_half');
            $table->unsignedInteger('pass_received_f3');
            $table->unsignedInteger('min_pass_received');

            $table->unsignedInteger('take_ons_t');
            $table->unsignedInteger('take_ons_s');
            $table->unsignedInteger('take_ons_s_p');

            //Distribution

            $table->unsignedInteger('pass_t');
            $table->unsignedInteger('pass_s');
            $table->unsignedInteger('pass_s_p');

            $table->unsignedInteger('chance_created');
            $table->unsignedInteger('big_chance_created');
            $table->unsignedInteger('min_chance_created');

            //Goal Threat

            $table->unsignedInteger('goals_threat');
            $table->unsignedInteger('min_goals');

            $table->unsignedInteger('attempts_t');
            $table->unsignedInteger('attempts_on_target');
            $table->unsignedInteger('min_attempts');

            $table->unsignedInteger('shot_acc');
            $table->unsignedInteger('goal_conversion');

            //Defending

            $table->unsignedInteger('aerial_t');
            $table->unsignedInteger('aerial_w');
            $table->unsignedInteger('aerial_w_p');

            $table->unsignedInteger('tackles_t');
            $table->unsignedInteger('tackles_w');
            $table->unsignedInteger('tackles_w_p');

            $table->unsignedInteger('interceptions');
            $table->unsignedInteger('recoveries');
            $table->unsignedInteger('clearances');
            $table->unsignedInteger('blocks');
            $table->unsignedInteger('err_chance');
            $table->unsignedInteger('err_goals');
            
            $table->unsignedInteger('fixtures_id');
            $table->foreign('fixtures_id')->references('id')->on('fixtures')->onDelete('cascade'); 

            $table->unsignedInteger('player_id');
            $table->foreign('player_id')->references('id')->on('players')->onDelete('cascade'); 

            $table->unsignedInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('player_stats');
    }
}
