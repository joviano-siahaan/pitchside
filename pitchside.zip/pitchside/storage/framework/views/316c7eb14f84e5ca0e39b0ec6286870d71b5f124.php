<div class="bg-white rounded shadow-sm mb-3 p-4">
    <?php if(isset($title)): ?>
        <h4 class="font-weight-light text-black mb-3"><?php echo e(__($title)); ?></h4>
    <?php endif; ?>
    <div class="row mb-2">
        <?php $__currentLoopData = $metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm col-6 mb-3 mb-sm-0  <?php if(!$loop->last): ?> border-right <?php endif; ?>">
                <small class="text-muted d-block mb-1"><?php echo e(__($key)); ?></small>
                <p class="h4 mb-1 text-black font-weight-light"><?php echo e($metric['keyValue']); ?></p>

                <?php if(isset($metric['keyDiff'])): ?>
                    <?php if((float)$metric['keyDiff'] < 0): ?>
                        <small class="text-xs text-danger"><?php echo e($metric['keyDiff']); ?> %
                            <?php if (isset($component)) { $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc = $component; } ?>
<?php $component = $__env->getContainer()->make(Orchid\Icons\IconComponent::class, ['path' => 'arrow-down','class' => 'v-top']); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc)): ?>
<?php $component = $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc; ?>
<?php unset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </small>
                    <?php elseif((float)$metric['keyDiff'] == 0): ?>
                        <small class="text-xs text-muted">
                            —
                        </small>
                    <?php else: ?>
                        <small class="text-xs text-success"><?php echo e($metric['keyDiff']); ?> %
                            <?php if (isset($component)) { $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc = $component; } ?>
<?php $component = $__env->getContainer()->make(Orchid\Icons\IconComponent::class, ['path' => 'arrow-up','class' => 'v-top']); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc)): ?>
<?php $component = $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc; ?>
<?php unset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </small>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\xampp2\htdocs\skripsi\vendor\orchid\platform\resources\views/layouts/metric.blade.php ENDPATH**/ ?>