<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="1em" height="1em" role="img" fill="currentColor" componentName="orchid-icon">
    <path d="M21.66,10.34a1,1,0,0,0-1.42,0L16,14.59l-4.24-4.25a1,1,0,0,0-1.42,1.42L14.59,16l-4.25,4.24a1,1,0,0,0,1.42,1.42L16,17.41l4.24,4.25a1,1,0,0,0,1.42-1.42L17.41,16l4.25-4.24A1,1,0,0,0,21.66,10.34Z"></path>
</svg>
<?php /**PATH C:\xampp\htdocs\skripsi\storage\framework\views/e10c1aeb2f3caaf0866065caa7b4477416380c1f.blade.php ENDPATH**/ ?>