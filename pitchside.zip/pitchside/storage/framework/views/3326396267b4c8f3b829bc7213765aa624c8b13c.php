<?php $__env->startPush('head'); ?>
    <link
        href="/favicon.ico"
        id="favicon"
        rel="icon"
    >
<?php $__env->stopPush(); ?>

<p class="h1 n-m font-thin v-center">
    <?php if (isset($component)) { $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc = $component; } ?>
<?php $component = $__env->getContainer()->make(Orchid\Icons\IconComponent::class, ['path' => 'soccer-field']); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc)): ?>
<?php $component = $__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc; ?>
<?php unset($__componentOriginald36eae2be856e5ea3de02a2f65da5a3c27957ebc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <span class="m-l d-none d-sm-block">
        PitchSide
    </span>
</p><?php /**PATH C:\xampp2\htdocs\skripsi\resources\views/brand/header.blade.php ENDPATH**/ ?>