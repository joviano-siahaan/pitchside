<div>
    <h3><?php echo e($table_name); ?></h3>
</div><?php /**PATH C:\xampp2\htdocs\skripsi\storage\framework\views/85bc54ddd02ef06de7e4fd0a986dc3271dd326a8.blade.php ENDPATH**/ ?>