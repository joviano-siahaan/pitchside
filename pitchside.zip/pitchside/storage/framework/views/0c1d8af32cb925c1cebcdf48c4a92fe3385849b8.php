<div
     data-controller="screen--chart"
     data-screen--chart-parent="#<?php echo e($slug); ?>"
     data-screen--chart-title="<?php echo e($title); ?>"
     data-screen--chart-labels="<?php echo e($labels); ?>"
     data-screen--chart-datasets="<?php echo e($data); ?>"
     data-screen--chart-type="<?php echo e($type); ?>"
     data-screen--chart-height="<?php echo e($height); ?>"
     data-screen--chart-colors="<?php echo e($colors); ?>"
     data-screen--chart-max-slices="<?php echo e($maxSlices); ?>"
     data-screen--chart-values-over-points="<?php echo e($valuesOverPoints); ?>"
     data-screen--chart-axis-options="<?php echo e($axisOptions); ?>"
     data-screen--chart-bar-options="<?php echo e($barOptions); ?>"
     data-screen--chart-line-options="<?php echo e($lineOptions); ?>"
     data-screen--chart-markers="<?php echo e($markers); ?>"
>
    <div class="bg-white rounded shadow-sm mb-3 pt-3">
        <div class="position-relative w-100">
            <?php if($export): ?>
                <div class="top-right pt-1 pr-4" style="z-index: 1">
                    <button class="btn btn-sm btn-link"
                            data-action="screen--chart#export">
                        <?php echo e(__('Export')); ?>

                    </button>
                </div>
            <?php endif; ?>
            <figure id="<?php echo e($slug); ?>" class="w-100 h-full"></figure>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\skripsi\vendor\orchid\platform\resources\views/layouts/chart.blade.php ENDPATH**/ ?>