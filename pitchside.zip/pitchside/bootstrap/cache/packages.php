<?php return array (
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'laravel/fortify' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Fortify\\FortifyServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/scout' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Scout\\ScoutServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'orchid/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Orchid\\Icons\\IconServiceProvider',
    ),
  ),
  'orchid/crud' => 
  array (
    'providers' => 
    array (
      0 => 'Orchid\\Crud\\CrudServiceProvider',
    ),
  ),
  'orchid/fortify' => 
  array (
    'providers' => 
    array (
      0 => 'Orchid\\Fortify\\AuthServiceProvider',
    ),
  ),
  'orchid/platform' => 
  array (
    'providers' => 
    array (
      0 => 'Orchid\\Platform\\Providers\\FoundationServiceProvider',
    ),
    'aliases' => 
    array (
      'Alert' => 'Orchid\\Support\\Facades\\Alert',
      'Dashboard' => 'Orchid\\Support\\Facades\\Dashboard',
    ),
  ),
  'tabuna/breadcrumbs' => 
  array (
    'providers' => 
    array (
      0 => 'Tabuna\\Breadcrumbs\\BreadcrumbsServiceProvider',
    ),
    'aliases' => 
    array (
      'Breadcrumbs' => 'Tabuna\\Breadcrumbs\\Breadcrumbs',
    ),
  ),
  'watson/active' => 
  array (
    'providers' => 
    array (
      0 => 'Watson\\Active\\ActiveServiceProvider',
    ),
    'aliases' => 
    array (
      'Active' => 'Watson\\Watson\\Facades\\Active',
    ),
  ),
);