<?php

declare(strict_types=1);

use App\Orchid\Screens\Examples\ExampleCardsScreen;
use App\Orchid\Screens\Examples\ExampleChartsScreen;
use App\Orchid\Screens\Examples\ExampleFieldsAdvancedScreen;
use App\Orchid\Screens\Examples\ExampleFieldsScreen;
use App\Orchid\Screens\Examples\ExampleLayoutsScreen;
use App\Orchid\Screens\Examples\ExampleScreen;
use App\Orchid\Screens\Examples\ExampleTextEditorsScreen;
use App\Orchid\Screens\PlatformScreen;
use App\Orchid\Screens\Role\RoleEditScreen;
use App\Orchid\Screens\Role\RoleListScreen;
use App\Orchid\Screens\User\UserEditScreen;
use App\Orchid\Screens\User\UserListScreen;
use App\Orchid\Screens\User\UserProfileScreen;
use App\Orchid\Screens\PlayersScreen;
use App\Orchid\Screens\PlayersEditScreen;
use App\Orchid\Screens\PlayersViewScreen;
use App\Orchid\Screens\DashboardScreen;
use App\Orchid\Screens\OpponentsScreen;
use App\Orchid\Screens\OpponentsEditScreen;
use App\Orchid\Screens\FixturesScreen;
use App\Orchid\Screens\FixturesEditScreen;
use App\Orchid\Screens\AttributeEditScreen;
use App\Orchid\Screens\dssScreen;
use App\Orchid\Screens\dssCustomScreen;
use App\Orchid\Screens\statsScreen;
use App\Orchid\Screens\PreferencesScreen;
use App\Orchid\Screens\statsEditScreen;
use App\Orchid\Screens\statsViewScreen;
use App\Orchid\Screens\statsAllScreen;
use App\Orchid\Screens\TwoFactorScreen;
use Illuminate\Support\Facades\Route;
use Tabuna\Breadcrumbs\Trail;

/*
|--------------------------------------------------------------------------
| Dashboard Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the need "dashboard" middleware group. Now create something great!
|
*/  

// Main
Route::screen('/main', DashboardScreen::class)
    ->name('platform.main');

// Platform > Profile
Route::screen('profile', UserProfileScreen::class)
    ->name('platform.profile')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Profile'), route('platform.profile'));
    });

// Platform > Preferences
Route::screen('preferences', PreferencesScreen::class)
    ->name('platform.preferences')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Profile'), route('platform.preferences'));
    });

// Platform > statsAll
Route::screen('statistics', statsAllScreen::class)
    ->name('platform.statistics')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Profile'), route('platform.preferences'));
    });

// Platform > Players > Stats > View
Route::screen('players/view/stats/detailed/{playerStat?}', statsViewScreen::class)
    ->name('platform.stats.detailed')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('fixtures'), route('platform.players.edit'));
    });

// Platform > Players > Stats > Edit
Route::screen('players/view/stats/edit/{player?}', statsEditScreen::class)
    ->name('platform.players.stats.edit')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('fixtures'), route('platform.players.edit'));
    });

// Platform > Players > Stats
Route::screen('players/view/stats/{player?}', statsScreen::class)
    ->name('platform.players.stats')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('fixtures'), route('platform.players.edit'));
    });    

// Platform > Players > DSS
Route::screen('players/view/dss/{player?}', dssScreen::class)
    ->name('platform.players.dss')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('fixtures'), route('platform.players.edit'));
    });  

// Platform > Players > DSS > Custom
Route::screen('players/view/dss/custom/{player?}', dssCustomScreen::class)
    ->name('platform.players.dss.custom')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('fixtures'), route('platform.players.edit'));
    }); 

// Platform > Players > View
Route::screen('players/view/{player?}', PlayersViewScreen::class)
    ->name('platform.players.view')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Players'), route('platform.players.view'));
    });

// Platform > Players > Edit
Route::screen('players/edit/{player?}', PlayersEditScreen::class)
    ->name('platform.players.edit')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Players'), route('platform.players.edit'));
    });

// Platform > Attributes > Edit
Route::screen('players/attributes/{player?}', AttributeEditScreen::class)
    ->name('platform.attributes.edit')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Players'), route('platform.players.edit'));
    });

// Platform > Players
Route::screen('players', PlayersScreen::class)
    ->name('platform.players.list')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Players'), route('platform.players.list'));
    });

// Platform > Opponents > Edit
Route::screen('opponents/edit/{player?}', OpponentsEditScreen::class)
    ->name('platform.opponents.edit')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Opponents'), route('platform.opponents.edit'));
    });    

// Platform > Opponents
Route::screen('opponents', OpponentsScreen::class)
    ->name('platform.opponents.list')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Opponents'), route('platform.opponents.list'));
    });

// Platform > Fixtures > Edit
Route::screen('fixtures/edit/{player?}', FixturesEditScreen::class)
    ->name('platform.fixtures.edit')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('fixtures'), route('platform.fixtures.edit'));
    });    

// Platform > Fixtures
Route::screen('fixtures', FixturesScreen::class)
    ->name('platform.fixtures.list')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('fixtures'), route('platform.fixtures.list'));
    });

// Platform > System > Users
Route::screen('users/{users}/edit', UserEditScreen::class)
    ->name('platform.systems.users.edit')
    ->breadcrumbs(function (Trail $trail, $user) {
        return $trail
            ->parent('platform.systems.users')
            ->push(__('Edit'), route('platform.systems.users.edit', $user));
    });

// Platform > System > Users > Create
Route::screen('users/create', UserEditScreen::class)
    ->name('platform.systems.users.create')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.systems.users')
            ->push(__('Create'), route('platform.systems.users.create'));
    });

// Platform > System > Users > User
Route::screen('users', UserListScreen::class)
    ->name('platform.systems.users')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.systems.index')
            ->push(__('Users'), route('platform.systems.users'));
    });

// Platform > System > Roles > Role
Route::screen('roles/{roles}/edit', RoleEditScreen::class)
    ->name('platform.systems.roles.edit')
    ->breadcrumbs(function (Trail $trail, $role) {
        return $trail
            ->parent('platform.systems.roles')
            ->push(__('Role'), route('platform.systems.roles.edit', $role));
    });

// Platform > System > Roles > Create
Route::screen('roles/create', RoleEditScreen::class)
    ->name('platform.systems.roles.create')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.systems.roles')
            ->push(__('Create'), route('platform.systems.roles.create'));
    });

// Platform > System > Roles
Route::screen('roles', RoleListScreen::class)
    ->name('platform.systems.roles')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.systems.index')
            ->push(__('Roles'), route('platform.systems.roles'));
    });

// Example...
Route::screen('example', ExampleScreen::class)
    ->name('platform.example')
    ->breadcrumbs(function (Trail $trail) {
        return $trail
            ->parent('platform.index')
            ->push(__('Example screen'));
    });

Route::screen('example-fields', ExampleFieldsScreen::class)->name('platform.example.fields');
Route::screen('example-layouts', ExampleLayoutsScreen::class)->name('platform.example.layouts');
Route::screen('example-charts', ExampleChartsScreen::class)->name('platform.example.charts');
Route::screen('example-editors', ExampleTextEditorsScreen::class)->name('platform.example.editors');
Route::screen('example-cards', ExampleCardsScreen::class)->name('platform.example.cards');
Route::screen('example-advanced', ExampleFieldsAdvancedScreen::class)->name('platform.example.advanced');

//Route::screen('idea', 'Idea::class','platform.screens.idea');
