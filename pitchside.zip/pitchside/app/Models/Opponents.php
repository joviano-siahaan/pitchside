<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Multitenantable;
use Orchid\Screen\AsSource;
use App\Orchid\Presenters\OpponentsPresenter;
use App\Models\Fixtures;

class Opponents extends Model
{
    use HasFactory;
    use Multitenantable;
    use AsSource;

    protected $fillable = [
    'team_name',
    'abv',
    'urlImage',
    'created_at',
    'updated_at',    
    ];

    public function fixtures()
    {
        return $this->hasMany(Fixtures::class, 'opp_id');
    }


    public function presenter(): OpponentsPresenter
    {
        return new OpponentsPresenter($this);
    } 
}
