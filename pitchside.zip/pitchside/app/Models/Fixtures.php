<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Multitenantable;
use Orchid\Screen\AsSource;
use App\Orchid\Presenters\FixturesPresenter;
use App\Models\Opponents;

class Fixtures extends Model
{
    use HasFactory;
    use Multitenantable;
    use AsSource;
    
    protected $fillable = [
    'opp_id',
    'homeaway',
    'match_date',
    'team_score',
    'opp_score',  
    'created_at',
    'updated_at',
    ];

    public function opponents()
    {
        return $this->belongsTo(Opponents::class, 'opp_id');
    }

    public function player_stats()
    {
        return $this->hasMany(playerStats::class, 'player_id');
    }

    public function presenter(): FixturesPresenter
    {
        return new FixturesPresenter($this);
    } 
}
