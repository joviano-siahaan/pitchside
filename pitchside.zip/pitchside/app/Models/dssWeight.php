<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Multitenantable;
use Orchid\Screen\AsSource;
use App\Orchid\Presenters\dssWeightPresenter;
use App\Models\User;

class dssWeight extends Model
{
    use HasFactory;
    use Multitenantable;
    use AsSource;

    protected $fillable = [  
    'userPref_id',

    'gk_speed',
    'gk_balance',
    'gk_strength',
    'gk_durability',
    'gk_agility',
    'gk_power',
    'gk_stamina',
    'gk_jumping',
    'gk_pass',
    'gk_control',
    'gk_long_pass',
    'gk_shot_acc',
    'gk_heading',
    'gk_tackle',
    'gk_catching',
    'gk_reflex',
    'gk_positioning',
    'gk_creative',
    'gk_determination',
    'gk_reading',

    'def_speed',
    'def_balance',
    'def_strength',
    'def_durability',
    'def_agility',
    'def_power',
    'def_stamina',
    'def_jumping',
    'def_pass',
    'def_control',
    'def_long_pass',
    'def_shot_acc',
    'def_heading',
    'def_tackle',
    'def_catching',
    'def_reflex',
    'def_positioning',
    'def_creative',
    'def_determination',
    'def_reading',

    'dm_speed',
    'dm_balance',
    'dm_strength',
    'dm_durability',
    'dm_agility',
    'dm_power',
    'dm_stamina',
    'dm_jumping',
    'dm_pass',
    'dm_control',
    'dm_long_pass',
    'dm_shot_acc',
    'dm_heading',
    'dm_tackle',
    'dm_catching',
    'dm_reflex',
    'dm_positioning',
    'dm_creative',
    'dm_determination',
    'dm_reading',

    'am_speed',
    'am_balance',
    'am_strength',
    'am_durability',
    'am_agility',
    'am_power',
    'am_stamina',
    'am_jumping',
    'am_pass',
    'am_control',
    'am_long_pass',
    'am_shot_acc',
    'am_heading',
    'am_tackle',
    'am_catching',
    'am_reflex',
    'am_positioning',
    'am_creative',
    'am_determination',
    'am_reading', 

    'wing_speed',
    'wing_balance',
    'wing_strength',
    'wing_durability',
    'wing_agility',
    'wing_power',
    'wing_stamina',
    'wing_jumping',
    'wing_pass',
    'wing_control',
    'wing_long_pass',
    'wing_shot_acc',
    'wing_heading',
    'wing_tackle',
    'wing_catching',
    'wing_reflex',
    'wing_positioning',
    'wing_creative',
    'wing_determination',
    'wing_reading', 

    'st_speed',
    'st_balance',
    'st_strength',
    'st_durability',
    'st_agility',
    'st_power',
    'st_stamina',
    'st_jumping',
    'st_pass',
    'st_control',
    'st_long_pass',
    'st_shot_acc',
    'st_heading',
    'st_tackle',
    'st_catching',
    'st_reflex',
    'st_positioning',
    'st_creative',
    'st_determination',
    'st_reading', 

    'created_at',
    'updated_at',    
    ];

    public function userPref()
    {
        return $this->belongsTo(User::class, 'userPref_id');
    } 

    public function presenter(): dssWeightPresenter
    {
        return new dssWeightPresenter($this);
    } 
}
