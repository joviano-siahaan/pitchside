<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Multitenantable;
use Orchid\Screen\AsSource;
use App\Orchid\Presenters\PlayersPresenter;
use App\Models\AttPhysical;
use App\Models\AttTechnical;
use App\Models\AttTactical;
use App\Models\playerStats;
use Orchid\Metrics\Chartable;

class Players extends Model
{
    use HasFactory;
    use Multitenantable;
    use AsSource;
    use Chartable;

    
    protected $fillable = [
    'name',
    'position',
    'created_at',
    'updated_at',
    'team_id',
    'weight',
    'height',
    'prefFoot',
    'number',
    'urlImage',
    'birthDate',
    ];

    public function AttPhysical()
    {
        return $this->hasOne(AttPhysical::class, 'players_id');
    }

    public function AttTactical()
    {
        return $this->hasOne(AttTactical::class, 'players_id');
    }

    public function AttTechnical()
    {
        return $this->hasOne(AttTechnical::class, 'players_id');
    }

    public function player_stats()
    {
        return $this->hasMany(playerStats::class, 'player_id');
    }

    public function presenter(): PlayersPresenter
    {
        return new PlayersPresenter($this);
    }
}
