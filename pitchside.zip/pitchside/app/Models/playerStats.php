<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Multitenantable;
use Orchid\Screen\AsSource;
use App\Models\Players;
use App\Models\Fixtures;
use App\Orchid\Presenters\playerStatsPresenter;
use Orchid\Metrics\Chartable;

class playerStats extends Model
{
    use HasFactory;
    use Multitenantable;
    use AsSource;
    use Chartable;

    protected $fillable = [
            
            //General

    'min_played',
    'goals',
    'assist',
    'goals_conceded',
    'own_goals',            
    'yellow_c',
    'red_c',

    //Involvement

    'touches_t',
    'touches_opp_half',
    'touches_f3',
    'min_touches', //non input

    'pass_received_t',
    'pass_received_opp_half',
    'pass_received_f3',
    'min_pass_received', //non input 

    'take_ons_t',
    'take_ons_s',
    'take_ons_s_p', //non input

    //Distribution

    'pass_t',
    'pass_s',
    'pass_s_p', //non input

    'chance_created',
    'big_chance_created',
    'min_chance_created', //non input

    //Goal Threat

    'goals_threat', //non input
    'min_goals', //non input

    'attempts_t',
    'attempts_on_target',
    'min_attempts', //non input

    'shot_acc', //non input
    'goal_conversion', //non input

    //Defending

    'aerial_t',
    'aerial_w',
    'aerial_w_p', //non input

    'tackles_t',
    'tackles_w',
    'tackles_w_p', //non input

    'interceptions',
    'recoveries',
    'clearances',
    'blocks',
    'err_chance',
    'err_goals',

    'player_id',
    'fixtures_id',

    'created_at',
    'updated_at',    
    ];

    public function player_stats()
        {
            return $this->belongsTo(Players::class, 'player_id');
        }

    public function fixtures()
        {
            return $this->belongsTo(Fixtures::class, 'fixtures_id');
        }

    public function presenter(): playerStatsPresenter
        {
            return new playerStatsPresenter($this);
        }
}
