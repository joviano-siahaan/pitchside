<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Players;
use App\Traits\Multitenantable;
use Orchid\Screen\AsSource;
use App\Orchid\Presenters\AttTacticalPresenter;

class AttTactical extends Model
{
    use HasFactory;
    use Multitenantable;
    use AsSource;

    protected $fillable = [
    'players_id',
    'positioning',
    'creative',
    'determination',
    'reading',
    'created_at',
    'updated_at',    
    ];     

    public function players()
    {
        return $this->belongsTo(Players::class, 'players_id');
    } 

    public function presenter(): AttTacticalPresenter
        {
            return new AttTacticalPresenter($this);
        } 
}
