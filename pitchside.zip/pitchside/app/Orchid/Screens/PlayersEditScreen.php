<?php

namespace App\Orchid\Screens;

use App\Models\Players;
use App\Models\User;
use App\Models\dssWeight;
use App\Models\AttPhysical;
use App\Models\AttTactical;
use App\Models\AttTechnical;
use Illuminate\Http\Request;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\Select;
use Orchid\Screen\Fields\Quill;
use Orchid\Screen\Fields\Relation;
use Orchid\Screen\Fields\TextArea;
use Orchid\Screen\Fields\Upload;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\Actions\Button;
use Orchid\Screen\Fields\DateTimer; 
use Orchid\Screen\Fields\Cropper; 
use Orchid\Screen\Screen;
use Orchid\Support\Facades\Alert;

class PlayersEditScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Add Players';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = 'Add Player Details';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(Players $players): array
    {
        $this->exists = $players->exists;

        if($this->exists){
            $this->name = 'Edit Attributes';
        }

        return [
            'players' => $players,
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [
            Button::make('Add Player')
                ->icon('pencil')
                ->method('createOrUpdate')
                ->canSee(!$this->exists),

            Button::make('Edit')
                ->icon('note')
                ->method('createOrUpdate')
                ->canSee($this->exists),

            Button::make('Remove')
                ->icon('trash')
                ->method('remove')
                ->canSee($this->exists),
        ];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            Layout::columns([
                Layout::rows([                

                    Input::make('players.name')
                        ->title('Player Name')
                        ->placeholder('Input Player Name.')
                        ->help('Input Player Name.'),

                    Select::make('players.position')
                        ->options([
                            'Goalkeeper'   => 'Goalkeeper',
                            'Defender' => 'Defender',
                            'Def. Midfield'   => 'Def. Midfield',
                            'Att. Midfield'   => 'Att. Midfield',
                            'Winger'   => 'Winger',
                            'Forward' => 'Forward',                    
                        ])
                        ->title('Player Position'),

                    DateTimer::make('players.birthDate')
                        ->title('Date of Birth')
                        ->allowInput()
                        ->required()
                        ->format('Y-m-d'),

                    Select::make('players.prefFoot')
                        ->options([
                            'Right' => 'Right', 
                            'Left'   => 'Left',                 
                        ])
                        ->title('Preferred Foot')
                        ->required(),

                    Input::make('players.height')
                        ->type('number')
                        ->min(1)
                        ->max(250)
                        ->title('Height (cm)')
                        ->required(),

                    Input::make('players.weight')
                        ->type('number')
                        ->min(1)
                        ->max(200)
                        ->title('Weight (kg)')
                        ->required(),

                    Input::make('players.number')
                        ->type('number')
                        ->min(1)
                        ->max(99)
                        ->title('Shirt Number')
                        ->required(),

                    Cropper::make('players.urlImage')
                        ->title('Photo')
                        ->minWidth(600)
                        ->minHeight(800)
                        ->maxWidth(600)
                        ->maxHeight(800)
                        ->maxFileSize(2)
                        ->targetRelativeUrl()                               
                    ]),                      

            Layout::tabs([
                'Physical' => Layout::rows([

                            Input::make('players.attphysical.speed')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Speed')
                                ->required(),   

                            Input::make('players.attphysical.balance')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Balance')
                                ->required(), 

                            Input::make('players.attphysical.strength')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Strength')
                                ->required(), 

                            Input::make('players.attphysical.durability')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Durability')
                                ->required(), 

                            Input::make('players.attphysical.agility')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Agility')
                                ->required(),   


                            Input::make('players.attphysical.power')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Power')
                                ->required(), 

                            Input::make('players.attphysical.stamina')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Stamina')
                                ->required(), 

                            Input::make('players.attphysical.jumping')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Jumping')
                                ->required(),                                                               
                        ]),                    

                'Technical' => Layout::rows([

                            Input::make('players.atttechnical.pass')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Passing')
                                ->required(),   

                            Input::make('players.atttechnical.control')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Control')
                                ->required(), 

                            Input::make('players.atttechnical.long_pass')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Long Passing')
                                ->required(), 

                            Input::make('players.atttechnical.shot_acc')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Shot Acc.')
                                ->required(), 

                            Input::make('players.atttechnical.heading')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Heading')
                                ->required(),   


                            Input::make('players.atttechnical.tackle')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Tackle')
                                ->required(), 

                            Input::make('players.atttechnical.catching')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Catching')
                                ->required(), 

                            Input::make('players.atttechnical.reflex')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Reflex')
                                ->required(),                    
                        ]), 

                'Tactical' => Layout::rows([

                            Input::make('players.atttactical.positioning')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Positioning')
                                ->required(),   

                            Input::make('players.atttactical.creative')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Creative')
                                ->required(), 

                            Input::make('players.atttactical.determination')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Determination')
                                ->required(), 

                            Input::make('players.atttactical.reading')
                                ->type('number')
                                ->min(1)
                                ->max(99)
                                ->title('Reading the Game')
                                ->required(),                   
                        ]),                                  
                ])
            ]), 
        ];
    }

    public function createOrUpdate(Players $players, Request $request)
    {       
        $players->fill($request->get('players'))->save();

        $players->AttPhysical()->updateOrCreate(
            
            [
                'players_id' => $players->id,  
            ],

            [
                'speed' => $request->input('players.attphysical.speed'),
                'balance' => $request->input('players.attphysical.balance'),
                'strength' => $request->input('players.attphysical.strength'),
                'durability' => $request->input('players.attphysical.durability'),
                'agility' => $request->input('players.attphysical.agility'),
                'power' => $request->input('players.attphysical.power'),
                'stamina' => $request->input('players.attphysical.stamina'),
                'jumping' => $request->input('players.attphysical.jumping'),
            ]
        );

        $players->AttTactical()->updateOrCreate(

            [
                'players_id' => $players->id,  
            ],

            [
            'positioning' => $request->input('players.atttactical.positioning'),
            'creative' => $request->input('players.atttactical.creative'),
            'determination' => $request->input('players.atttactical.determination'),
            'reading' => $request->input('players.atttactical.reading'),
            ]
        );

        $players->AttTechnical()->updateOrCreate(
            
            [
                'players_id' => $players->id,  
            ],

            [
                'pass' => $request->input('players.atttechnical.pass'),
                'control' => $request->input('players.atttechnical.control'),
                'long_pass' => $request->input('players.atttechnical.long_pass'),
                'shot_acc' => $request->input('players.atttechnical.shot_acc'),
                'heading' => $request->input('players.atttechnical.heading'),
                'tackle' => $request->input('players.atttechnical.tackle'),
                'catching' => $request->input('players.atttechnical.catching'),
                'reflex' => $request->input('players.atttechnical.reflex'),            
            ]
        );

        Alert::info('You have successfully added a player.');

        return redirect()->route('platform.players.view', $players);
    }

    /**
     * @param Post $post
     *
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function remove(Players $players)
    {
        $players->delete();
        $players->AttPhysical()->delete();
        $players->AttTechnical()->delete();
        $players->AttTactical()->delete();

        Alert::info('You have successfully deleted a player.');

        return redirect()->route('platform.players.list');
    }

}