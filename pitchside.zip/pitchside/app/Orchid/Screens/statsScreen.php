<?php

namespace App\Orchid\Screens;

use App\Models\Players;
use App\Models\Fixtures;
use App\Models\Opponents;
use App\Models\User;
use App\Models\playerStats;
use Orchid\Screen\Screen;
use Illuminate\Http\Request;
use Orchid\Screen\Layouts\Card;
use Orchid\Screen\Contracts\Cardable;
use Orchid\Support\Facades\Layout;
use Orchid\Support\Color;
use Orchid\Screen\Layouts\Compendium;
use Orchid\Screen\Actions\Button;
use Illuminate\Support\Facades\Storage;
use Orchid\Screen\Actions\Link;
use Orchid\Support\Facades\Alert;
use Orchid\Screen\Fields\Group;
use App\Orchid\Layouts\StatsListLayout;

class statsScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Player Stats';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = ' ';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(): array
    {
        return [
            $uri = $_SERVER["REQUEST_URI"],
            $uriArray = explode('/', $uri),
            $id = $uriArray[5],
            'playerStats' => playerStats::where('player_id', '=', $id)->with('player_stats')->paginate(),

            $this->name = Players::findOrFail($id)->presenter()->name(),
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [
            Link::make('Create new')
                ->icon('pencil')
                ->route('platform.players.stats.edit')
        ];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            StatsListLayout::class
        ];
    }

}
