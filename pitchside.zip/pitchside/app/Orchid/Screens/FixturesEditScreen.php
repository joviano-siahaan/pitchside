<?php

namespace App\Orchid\Screens;

use App\Models\Fixtures;
use App\Models\User;
use App\Models\Opponents;
use Illuminate\Http\Request;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\Select;
use Orchid\Screen\Fields\Quill;
use Orchid\Screen\Fields\Relation;
use Orchid\Screen\Fields\TextArea;
use Orchid\Screen\Fields\Upload;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\Actions\Button;
use Orchid\Screen\Fields\DateTimer; 
use Orchid\Screen\Fields\Cropper; 
use Orchid\Screen\Screen;
use Orchid\Support\Facades\Alert;

class FixturesEditScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Add Fixtures';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = 'Add Fixtures Details';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(Fixtures $fixtures): array
    {
        $this->exists = $fixtures->exists;

        if($this->exists){
            $this->name = 'Edit Fixtures';
        }

        return [
            'fixtures' => $fixtures
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [
            Button::make('Add Fixtures')
                ->icon('pencil')
                ->method('createOrUpdate')
                ->canSee(!$this->exists),

            Button::make('Edit')
                ->icon('note')
                ->method('createOrUpdate')
                ->canSee($this->exists),

            Button::make('Remove')
                ->icon('trash')
                ->method('remove')
                ->canSee($this->exists),
        ];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
    return [
        Layout::rows([
            Select::make('fixtures.opp_id')
                ->title('Opponent')
                ->required()
                ->fromModel(Opponents::class, 'team_name')
                ->targetId(),
            Select::make('fixtures.homeaway')
                ->options([
                    'Home'   => 'Home',
                    'Away' => 'Away',
                ])
                ->title('Home/Away')
                ->required()                
                ->help('Is it a home or an away fixture?'),
            DateTimer::make('fixtures.match_date')
                ->title('Match Date')
                ->allowInput()
                ->required()
                ->format('Y-m-d'),
            Input::make('fixtures.team_score')
                ->type('number')
                ->min(0)
                ->max(25)
                ->title('Team Score')
                ->required(),               
            Input::make('fixtures.opp_score')
                ->type('number')
                ->min(0)
                ->max(25)
                ->title('Opponent Score')
                ->required(),
        ])
    ];
    }

    public function createOrUpdate(Fixtures $fixtures, Request $request)
    {
        $fixtures->fill($request->get('fixtures'))->save();

        Alert::info('You have successfully added a fixture.');

        return redirect()->route('platform.fixtures.list');
    }

    /**
     * @param Post $post
     *
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function remove(Fixtures $fixtures)
    {
        $fixtures->delete();

        Alert::info('You have successfully deleted a fixture.');

        return redirect()->route('platform.fixtures.list');
    }

}
