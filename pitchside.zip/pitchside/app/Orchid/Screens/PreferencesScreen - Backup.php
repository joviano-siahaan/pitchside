<?php

namespace App\Orchid\Screens;

use Orchid\Screen\Screen;
use Illuminate\Http\Request;
use Orchid\Platform\Models\User;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\Actions\Button;
use Orchid\Support\Color;
use App\Orchid\Layouts\dssWeightLayout;
use Orchid\Screen\Fields\Input;
use Orchid\Support\Facades\Toast;

class PreferencesScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Preferences';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = 'Input Preferences for your account';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(): array
    {
        return [
            'user' => User::with('dssWeight')->paginate(),
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            Layout::block(
                Layout::tabs([
                    'Goalkeeper' => [
                        Layout::rows([                         

                            Input::make('users.dss_weights.gk_speed')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Speed')
                                ->placeholder('Speed'),

                            Input::make('users.dss_weights.gk_balance')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Balance')
                                ->placeholder('Balance'),

                            Input::make('users.dss_weights.gk_strength')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Strength')
                                ->placeholder('Strength'),

                            Input::make('users.dss_weights.gk_durability')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Durability')
                                ->placeholder('Durability'),

                            Input::make('users.dss_weights.gk_agility')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Agility')
                                ->placeholder('Agility'),

                            Input::make('users.dss_weights.gk_power')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Power')
                                ->placeholder('Power'),

                            Input::make('users.dss_weights.gk_stamina')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Stamina')
                                ->placeholder('Stamina'),

                            Input::make('users.dss_weights.gk_jumping')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Jumping')
                                ->placeholder('Jumping'),

                            Input::make('users.dss_weights.gk_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Passing')
                                ->placeholder('Passing'),

                            Input::make('users.dss_weights.gk_control')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Control')
                                ->placeholder('Control'),

                            Input::make('users.dss_weights.gk_long_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Long Passing')
                                ->placeholder('Long Passing'),

                            Input::make('users.dss_weights.gk_shot_acc')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Shot Acc.')
                                ->placeholder('Shot Acc.'),

                            Input::make('users.dss_weights.gk_heading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Heading')
                                ->placeholder('Heading'),

                            Input::make('users.dss_weights.gk_tackle')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Tackling')
                                ->placeholder('Tackling'),

                            Input::make('users.dss_weights.gk_catching')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Catching')
                                ->placeholder('Catching'),

                            Input::make('users.dss_weights.gk_reflex')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reflex')
                                ->placeholder('Reflex'),

                            Input::make('users.dss_weights.gk_positioning')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Positioning')
                                ->placeholder('Positioning'),

                            Input::make('users.dss_weights.gk_creative')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Creativity')
                                ->placeholder('Creativity'),

                            Input::make('users.dss_weights.gk_determination')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Determination')
                                ->placeholder('Determination'),

                            Input::make('users.dss_weights.gk_reading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reading the Game')
                                ->placeholder('Reading the Game'),                           
                        ]),
                    ],
                    'Defender' => [
                        Layout::rows([                         

                            Input::make('users.dss_weights.def_speed')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Speed')
                                ->placeholder('Speed'),

                            Input::make('users.dss_weights.def_balance')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Balance')
                                ->placeholder('Balance'),

                            Input::make('users.dss_weights.def_strength')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Strength')
                                ->placeholder('Strength'),

                            Input::make('users.dss_weights.def_durability')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Durability')
                                ->placeholder('Durability'),

                            Input::make('users.dss_weights.def_agility')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Agility')
                                ->placeholder('Agility'),

                            Input::make('users.dss_weights.def_power')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Power')
                                ->placeholder('Power'),

                            Input::make('users.dss_weights.def_stamina')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Stamina')
                                ->placeholder('Stamina'),

                            Input::make('users.dss_weights.def_jumping')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Jumping')
                                ->placeholder('Jumping'),

                            Input::make('users.dss_weights.def_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Passing')
                                ->placeholder('Passing'),

                            Input::make('users.dss_weights.def_control')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Control')
                                ->placeholder('Control'),

                            Input::make('users.dss_weights.def_long_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Long Passing')
                                ->placeholder('Long Passing'),

                            Input::make('users.dss_weights.def_shot_acc')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Shot Acc.')
                                ->placeholder('Shot Acc.'),

                            Input::make('users.dss_weights.def_heading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Heading')
                                ->placeholder('Heading'),

                            Input::make('users.dss_weights.def_tackle')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Tackling')
                                ->placeholder('Tackling'),

                            Input::make('users.dss_weights.def_catching')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Catching')
                                ->placeholder('Catching'),

                            Input::make('users.dss_weights.def_reflex')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reflex')
                                ->placeholder('Reflex'),

                            Input::make('users.dss_weights.def_positioning')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Positioning')
                                ->placeholder('Positioning'),

                            Input::make('users.dss_weights.def_creative')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Creativity')
                                ->placeholder('Creativity'),

                            Input::make('users.dss_weights.def_determination')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Determination')
                                ->placeholder('Determination'),

                            Input::make('users.dss_weights.def_reading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reading the Game')
                                ->placeholder('Reading the Game'),                           
                        ]),
                    ],
                    'Def. Midfield' => [
                        Layout::rows([                         

                            Input::make('users.dss_weights.dm_speed')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Speed')
                                ->placeholder('Speed'),

                            Input::make('users.dss_weights.dm_balance')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Balance')
                                ->placeholder('Balance'),

                            Input::make('users.dss_weights.dm_strength')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Strength')
                                ->placeholder('Strength'),

                            Input::make('users.dss_weights.dm_durability')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Durability')
                                ->placeholder('Durability'),

                            Input::make('users.dss_weights.dm_agility')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Agility')
                                ->placeholder('Agility'),

                            Input::make('users.dss_weights.dm_power')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Power')
                                ->placeholder('Power'),

                            Input::make('users.dss_weights.dm_stamina')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Stamina')
                                ->placeholder('Stamina'),

                            Input::make('users.dss_weights.dm_jumping')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Jumping')
                                ->placeholder('Jumping'),

                            Input::make('users.dss_weights.dm_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Passing')
                                ->placeholder('Passing'),

                            Input::make('users.dss_weights.dm_control')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Control')
                                ->placeholder('Control'),

                            Input::make('users.dss_weights.dm_long_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Long Passing')
                                ->placeholder('Long Passing'),

                            Input::make('users.dss_weights.dm_shot_acc')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Shot Acc.')
                                ->placeholder('Shot Acc.'),

                            Input::make('users.dss_weights.dm_heading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Heading')
                                ->placeholder('Heading'),

                            Input::make('users.dss_weights.dm_tackle')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Tackling')
                                ->placeholder('Tackling'),

                            Input::make('users.dss_weights.dm_catching')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Catching')
                                ->placeholder('Catching'),

                            Input::make('users.dss_weights.dm_reflex')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reflex')
                                ->placeholder('Reflex'),

                            Input::make('users.dss_weights.dm_positioning')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Positioning')
                                ->placeholder('Positioning'),

                            Input::make('users.dss_weights.dm_creative')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Creativity')
                                ->placeholder('Creativity'),

                            Input::make('users.dss_weights.dm_determination')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Determination')
                                ->placeholder('Determination'),

                            Input::make('users.dss_weights.dm_reading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reading the Game')
                                ->placeholder('Reading the Game'),                           
                        ]),
                    ],
                    'Att. Midfield' => [
                        Layout::rows([                         

                            Input::make('users.dss_weights.am_speed')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Speed')
                                ->placeholder('Speed'),

                            Input::make('users.dss_weights.am_balance')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Balance')
                                ->placeholder('Balance'),

                            Input::make('users.dss_weights.am_strength')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Strength')
                                ->placeholder('Strength'),

                            Input::make('users.dss_weights.am_durability')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Durability')
                                ->placeholder('Durability'),

                            Input::make('users.dss_weights.am_agility')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Agility')
                                ->placeholder('Agility'),

                            Input::make('users.dss_weights.am_power')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Power')
                                ->placeholder('Power'),

                            Input::make('users.dss_weights.am_stamina')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Stamina')
                                ->placeholder('Stamina'),

                            Input::make('users.dss_weights.am_jumping')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Jumping')
                                ->placeholder('Jumping'),

                            Input::make('users.dss_weights.am_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Passing')
                                ->placeholder('Passing'),

                            Input::make('users.dss_weights.am_control')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Control')
                                ->placeholder('Control'),

                            Input::make('users.dss_weights.am_long_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Long Passing')
                                ->placeholder('Long Passing'),

                            Input::make('users.dss_weights.am_shot_acc')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Shot Acc.')
                                ->placeholder('Shot Acc.'),

                            Input::make('users.dss_weights.am_heading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Heading')
                                ->placeholder('Heading'),

                            Input::make('users.dss_weights.am_tackle')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Tackling')
                                ->placeholder('Tackling'),

                            Input::make('users.dss_weights.am_catching')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Catching')
                                ->placeholder('Catching'),

                            Input::make('users.dss_weights.am_reflex')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reflex')
                                ->placeholder('Reflex'),

                            Input::make('users.dss_weights.am_positioning')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Positioning')
                                ->placeholder('Positioning'),

                            Input::make('users.dss_weights.am_creative')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Creativity')
                                ->placeholder('Creativity'),

                            Input::make('users.dss_weights.am_determination')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Determination')
                                ->placeholder('Determination'),

                            Input::make('users.dss_weights.am_reading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reading the Game')
                                ->placeholder('Reading the Game'),                           
                        ]),
                    ],
                    'Winger' => [
                        Layout::rows([                         

                            Input::make('users.dss_weights.wing_speed')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Speed')
                                ->placeholder('Speed'),

                            Input::make('users.dss_weights.wing_balance')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Balance')
                                ->placeholder('Balance'),

                            Input::make('users.dss_weights.wing_strength')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Strength')
                                ->placeholder('Strength'),

                            Input::make('users.dss_weights.wing_durability')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Durability')
                                ->placeholder('Durability'),

                            Input::make('users.dss_weights.wing_agility')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Agility')
                                ->placeholder('Agility'),

                            Input::make('users.dss_weights.wing_power')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Power')
                                ->placeholder('Power'),

                            Input::make('users.dss_weights.wing_stamina')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Stamina')
                                ->placeholder('Stamina'),

                            Input::make('users.dss_weights.wing_jumping')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Jumping')
                                ->placeholder('Jumping'),

                            Input::make('users.dss_weights.wing_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Passing')
                                ->placeholder('Passing'),

                            Input::make('users.dss_weights.wing_control')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Control')
                                ->placeholder('Control'),

                            Input::make('users.dss_weights.wing_long_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Long Passing')
                                ->placeholder('Long Passing'),

                            Input::make('users.dss_weights.wing_shot_acc')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Shot Acc.')
                                ->placeholder('Shot Acc.'),

                            Input::make('users.dss_weights.wing_heading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Heading')
                                ->placeholder('Heading'),

                            Input::make('users.dss_weights.wing_tackle')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Tackling')
                                ->placeholder('Tackling'),

                            Input::make('users.dss_weights.wing_catching')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Catching')
                                ->placeholder('Catching'),

                            Input::make('users.dss_weights.wing_reflex')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reflex')
                                ->placeholder('Reflex'),

                            Input::make('users.dss_weights.wing_positioning')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Positioning')
                                ->placeholder('Positioning'),

                            Input::make('users.dss_weights.wing_creative')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Creativity')
                                ->placeholder('Creativity'),

                            Input::make('users.dss_weights.wing_determination')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Determination')
                                ->placeholder('Determination'),

                            Input::make('users.dss_weights.wing_reading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reading the Game')
                                ->placeholder('Reading the Game'),                           
                        ]),
                    ],
                    'Striker' => [
                        Layout::rows([                         

                            Input::make('users.dss_weights.st_speed')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Speed')
                                ->placeholder('Speed'),

                            Input::make('users.dss_weights.st_balance')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Balance')
                                ->placeholder('Balance'),

                            Input::make('users.dss_weights.st_strength')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Strength')
                                ->placeholder('Strength'),

                            Input::make('users.dss_weights.st_durability')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Durability')
                                ->placeholder('Durability'),

                            Input::make('users.dss_weights.st_agility')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Agility')
                                ->placeholder('Agility'),

                            Input::make('users.dss_weights.st_power')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Power')
                                ->placeholder('Power'),

                            Input::make('users.dss_weights.st_stamina')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Stamina')
                                ->placeholder('Stamina'),

                            Input::make('users.dss_weights.st_jumping')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Jumping')
                                ->placeholder('Jumping'),

                            Input::make('users.dss_weights.st_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Passing')
                                ->placeholder('Passing'),

                            Input::make('users.dss_weights.st_control')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Control')
                                ->placeholder('Control'),

                            Input::make('users.dss_weights.st_long_pass')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Long Passing')
                                ->placeholder('Long Passing'),

                            Input::make('users.dss_weights.st_shot_acc')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Shot Acc.')
                                ->placeholder('Shot Acc.'),

                            Input::make('users.dss_weights.st_heading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Heading')
                                ->placeholder('Heading'),

                            Input::make('users.dss_weights.st_tackle')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Tackling')
                                ->placeholder('Tackling'),

                            Input::make('users.dss_weights.st_catching')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Catching')
                                ->placeholder('Catching'),

                            Input::make('users.dss_weights.st_reflex')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reflex')
                                ->placeholder('Reflex'),

                            Input::make('users.dss_weights.st_positioning')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Positioning')
                                ->placeholder('Positioning'),

                            Input::make('users.dss_weights.st_creative')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Creativity')
                                ->placeholder('Creativity'),

                            Input::make('users.dss_weights.st_determination')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Determination')
                                ->placeholder('Determination'),

                            Input::make('users.dss_weights.st_reading')
                                ->type('number')
                                ->min(0)
                                ->max(1)
                                ->step(0.01)
                                ->required()
                                ->title('Reading the Game')
                                ->placeholder('Reading the Game'),                           
                        ]),
                    ],
                ]),
            )
                ->title(__('Decision Support Custom Weight'))
                ->description(__("Input custom weights for your decision support system."))
                ->commands(
                    Button::make(__('Save'))
                        ->type(Color::DEFAULT())
                        ->icon('check')
                        ->method('save')
                ),
        ];
    }

    public function save(User $user, Request $request)
    {
        $user->dssWeight()->updateOrCreate([
            'gk_speed' => $request->input('users.dss_weights.gk_speed'),
            'gk_balance' => $request->input('users.dss_weights.gk_balance'),
            'gk_strength' => $request->input('users.dss_weights.gk_strength'),
            'gk_durability' => $request->input('users.dss_weights.gk_durability'),
            'gk_agility' => $request->input('users.dss_weights.gk_agility'),
            'gk_power' => $request->input('users.dss_weights.gk_power'),
            'gk_stamina' => $request->input('users.dss_weights.gk_stamina'),
            'gk_jumping' => $request->input('users.dss_weights.gk_jumping'),

            'gk_pass' => $request->input('users.dss_weights.gk_pass'),
            'gk_control' => $request->input('users.dss_weights.gk_control'),
            'gk_long_pass' => $request->input('users.dss_weights.gk_long_pass'),
            'gk_shot_acc' => $request->input('users.dss_weights.gk_shot_acc'),
            'gk_heading' => $request->input('users.dss_weights.gk_heading'),
            'gk_tackle' => $request->input('users.dss_weights.gk_tackle'),
            'gk_catching' => $request->input('users.dss_weights.gk_catching'),
            'gk_reflex' => $request->input('users.dss_weights.gk_reflex'),

            'def_positioning' => $request->input('users.dss_weights.def_positioning'),
            'def_creative' => $request->input('users.dss_weights.def_creative'),
            'def_determination' => $request->input('users.dss_weights.def_determination'),
            'def_reading' => $request->input('users.dss_weights.def_reading'),

            'def_speed' => $request->input('users.dss_weights.def_speed'),
            'def_balance' => $request->input('users.dss_weights.def_balance'),
            'def_strength' => $request->input('users.dss_weights.def_strength'),
            'def_durability' => $request->input('users.dss_weights.def_durability'),
            'def_agility' => $request->input('users.dss_weights.def_agility'),
            'def_power' => $request->input('users.dss_weights.def_power'),
            'def_stamina' => $request->input('users.dss_weights.def_stamina'),
            'def_jumping' => $request->input('users.dss_weights.def_jumping'),

            'def_pass' => $request->input('users.dss_weights.def_pass'),
            'def_control' => $request->input('users.dss_weights.def_control'),
            'def_long_pass' => $request->input('users.dss_weights.def_long_pass'),
            'def_shot_acc' => $request->input('users.dss_weights.def_shot_acc'),
            'def_heading' => $request->input('users.dss_weights.def_heading'),
            'def_tackle' => $request->input('users.dss_weights.def_tackle'),
            'def_catching' => $request->input('users.dss_weights.def_catching'),
            'def_reflex' => $request->input('users.dss_weights.def_reflex'),

            'def_positioning' => $request->input('users.dss_weights.def_positioning'),
            'def_creative' => $request->input('users.dss_weights.def_creative'),
            'def_determination' => $request->input('users.dss_weights.def_determination'),
            'def_reading' => $request->input('users.dss_weights.def_reading'),

            'dm_speed' => $request->input('users.dss_weights.dm_speed'),
            'dm_balance' => $request->input('users.dss_weights.dm_balance'),
            'dm_strength' => $request->input('users.dss_weights.dm_strength'),
            'dm_durability' => $request->input('users.dss_weights.dm_durability'),
            'dm_agility' => $request->input('users.dss_weights.dm_agility'),
            'dm_power' => $request->input('users.dss_weights.dm_power'),
            'dm_stamina' => $request->input('users.dss_weights.dm_stamina'),
            'dm_jumping' => $request->input('users.dss_weights.dm_jumping'),

            'dm_pass' => $request->input('users.dss_weights.dm_pass'),
            'dm_control' => $request->input('users.dss_weights.dm_control'),
            'dm_long_pass' => $request->input('users.dss_weights.dm_long_pass'),
            'dm_shot_acc' => $request->input('users.dss_weights.dm_shot_acc'),
            'dm_heading' => $request->input('users.dss_weights.dm_heading'),
            'dm_tackle' => $request->input('users.dss_weights.dm_tackle'),
            'dm_catching' => $request->input('users.dss_weights.dm_catching'),
            'dm_reflex' => $request->input('users.dss_weights.dm_reflex'),

            'dm_positioning' => $request->input('users.dss_weights.dm_positioning'),
            'dm_creative' => $request->input('users.dss_weights.dm_creative'),
            'dm_determination' => $request->input('users.dss_weights.dm_determination'),
            'dm_reading' => $request->input('users.dss_weights.dm_reading'),

            'am_speed' => $request->input('users.dss_weights.am_speed'),
            'am_balance' => $request->input('users.dss_weights.am_balance'),
            'am_strength' => $request->input('users.dss_weights.am_strength'),
            'am_durability' => $request->input('users.dss_weights.am_durability'),
            'am_agility' => $request->input('users.dss_weights.am_agility'),
            'am_power' => $request->input('users.dss_weights.am_power'),
            'am_stamina' => $request->input('users.dss_weights.am_stamina'),
            'am_jumping' => $request->input('users.dss_weights.am_jumping'),

            'am_pass' => $request->input('users.dss_weights.am_pass'),
            'am_control' => $request->input('users.dss_weights.am_control'),
            'am_long_pass' => $request->input('users.dss_weights.am_long_pass'),
            'am_shot_acc' => $request->input('users.dss_weights.am_shot_acc'),
            'am_heading' => $request->input('users.dss_weights.am_heading'),
            'am_tackle' => $request->input('users.dss_weights.am_tackle'),
            'am_catching' => $request->input('users.dss_weights.am_catching'),
            'am_reflex' => $request->input('users.dss_weights.am_reflex'),

            'am_positioning' => $request->input('users.dss_weights.am_positioning'),
            'am_creative' => $request->input('users.dss_weights.am_creative'),
            'am_determination' => $request->input('users.dss_weights.am_determination'),
            'am_reading' => $request->input('users.dss_weights.am_reading'),

            'wing_speed' => $request->input('users.dss_weights.wing_speed'),
            'wing_balance' => $request->input('users.dss_weights.wing_balance'),
            'wing_strength' => $request->input('users.dss_weights.wing_strength'),
            'wing_durability' => $request->input('users.dss_weights.wing_durability'),
            'wing_agility' => $request->input('users.dss_weights.wing_agility'),
            'wing_power' => $request->input('users.dss_weights.wing_power'),
            'wing_stamina' => $request->input('users.dss_weights.wing_stamina'),
            'wing_jumping' => $request->input('users.dss_weights.wing_jumping'),

            'wing_pass' => $request->input('users.dss_weights.wing_pass'),
            'wing_control' => $request->input('users.dss_weights.wing_control'),
            'wing_long_pass' => $request->input('users.dss_weights.wing_long_pass'),
            'wing_shot_acc' => $request->input('users.dss_weights.wing_shot_acc'),
            'wing_heading' => $request->input('users.dss_weights.wing_heading'),
            'wing_tackle' => $request->input('users.dss_weights.wing_tackle'),
            'wing_catching' => $request->input('users.dss_weights.wing_catching'),
            'wing_reflex' => $request->input('users.dss_weights.wing_reflex'),

            'wing_positioning' => $request->input('users.dss_weights.wing_positioning'),
            'wing_creative' => $request->input('users.dss_weights.wing_creative'),
            'wing_determination' => $request->input('users.dss_weights.wing_determination'),
            'wing_reading' => $request->input('users.dss_weights.wing_reading'),

            'st_speed' => $request->input('users.dss_weights.st_speed'),
            'st_balance' => $request->input('users.dss_weights.st_balance'),
            'st_strength' => $request->input('users.dss_weights.st_strength'),
            'st_durability' => $request->input('users.dss_weights.st_durability'),
            'st_agility' => $request->input('users.dss_weights.st_agility'),
            'st_power' => $request->input('users.dss_weights.st_power'),
            'st_stamina' => $request->input('users.dss_weights.st_stamina'),
            'st_jumping' => $request->input('users.dss_weights.st_jumping'),

            'st_pass' => $request->input('users.dss_weights.st_pass'),
            'st_control' => $request->input('users.dss_weights.st_control'),
            'st_long_pass' => $request->input('users.dss_weights.st_long_pass'),
            'st_shot_acc' => $request->input('users.dss_weights.st_shot_acc'),
            'st_heading' => $request->input('users.dss_weights.st_heading'),
            'st_tackle' => $request->input('users.dss_weights.st_tackle'),
            'st_catching' => $request->input('users.dss_weights.st_catching'),
            'st_reflex' => $request->input('users.dss_weights.st_reflex'),

            'st_positioning' => $request->input('users.dss_weights.st_positioning'),
            'st_creative' => $request->input('users.dss_weights.st_creative'),
            'st_determination' => $request->input('users.dss_weights.st_determination'),
            'st_reading' => $request->input('users.dss_weights.st_reading'),           
        ]);

        Toast::info(__('Preferences updated.'));
    }
}
