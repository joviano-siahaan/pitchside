<?php

namespace App\Orchid\Screens;

use App\Models\Opponents;
use App\Models\User;
use Illuminate\Http\Request;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\Select;
use Orchid\Screen\Fields\Quill;
use Orchid\Screen\Fields\Relation;
use Orchid\Screen\Fields\TextArea;
use Orchid\Screen\Fields\Upload;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\Actions\Button;
use Orchid\Screen\Fields\DateTimer; 
use Orchid\Screen\Fields\Cropper; 
use Orchid\Screen\Screen;
use Orchid\Support\Facades\Alert;

class OpponentsEditScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Add Opponents';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = 'Add Opponents Details';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(Opponents $opponents): array
    {
        $this->exists = $opponents->exists;

        if($this->exists){
            $this->name = 'Edit Opponents';
        }

        return [
            'opponents' => $opponents
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [
            Button::make('Add Opponents')
                ->icon('pencil')
                ->method('createOrUpdate')
                ->canSee(!$this->exists),

            Button::make('Edit')
                ->icon('note')
                ->method('createOrUpdate')
                ->canSee($this->exists),

            Button::make('Remove')
                ->icon('trash')
                ->method('remove')
                ->canSee($this->exists),
        ];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            Layout::rows([
                Input::make('opponents.team_name')
                    ->title('Opponent Name')
                    ->placeholder('Input Opponent Name.')
                    ->help('Input Opponent Name.'),

                Input::make('opponents.abv')
                    ->title('Opponent Abbreviation')
                    ->placeholder('Input Opponent Abbreviation.')
                    ->help('Input Opponent Abbreviation.'),

                Cropper::make('opponents.urlImage')
                    ->title('Photo')
                    ->maxWidth(700)
                    ->maxHeight(700)
                    ->maxFileSize(2)
                    ->targetRelativeUrl()         
                ])
        ];
    }

    public function createOrUpdate(Opponents $opponents, Request $request)
    {
        $opponents->fill($request->get('opponents'))->save();

        Alert::info('You have successfully added an opponent.');

        return redirect()->route('platform.opponents.list');
    }

    /**
     * @param Post $post
     *
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function remove(Opponents $opponents)
    {
        $opponents->delete();

        Alert::info('You have successfully deleted an opponent.');

        return redirect()->route('platform.opponents.list');
    }

}
