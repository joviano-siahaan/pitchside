<?php

namespace App\Orchid\Screens;

use App\Models\User;
use App\Models\Opponents;
use App\Models\Fixtures;
use App\Models\Players;
use App\Models\playerStats;
use Illuminate\Http\Request;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Fields\Select;
use Orchid\Screen\Fields\Quill;
use Orchid\Screen\Fields\Relation;
use Orchid\Screen\Fields\TextArea;
use Orchid\Screen\Fields\Upload;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\Actions\Button;
use Orchid\Screen\Fields\DateTimer; 
use Orchid\Screen\Fields\Cropper; 
use Orchid\Screen\Screen;
use Orchid\Support\Facades\Alert;
use Illuminate\Support\Facades\DB;

class statsEditScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Add Stats';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = ' ';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(playerStats $playerStats): array
    {
        $this->exists = $playerStats->exists;

        if($this->exists){
            $this->name = 'Edit Player Stats';
        }

        return [
            'playerStats' => $playerStats
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [
            Button::make('Add')
                ->icon('pencil')
                ->method('createOrUpdate')
                ->canSee(!$this->exists),

            Button::make('Edit')
                ->icon('note')
                ->method('createOrUpdate')
                ->canSee($this->exists),

            Button::make('Remove')
                ->icon('trash')
                ->method('remove')
                ->canSee($this->exists),
        ];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            Layout::rows([                
                Select::make('playerStats.player_id')
                    ->title('Player')
                    ->required()
                    ->fromModel(Players::class, 'name')
                    ->targetId(),
            ]),

            Layout::rows([                
                Select::make('playerStats.fixtures_id')
                    ->title('Fixture')
                    ->required()
                    ->fromQuery(
                        Opponents::where('opponents.user_id', auth()->id())
                            ->leftJoin('fixtures','fixtures.opp_id','=','opponents.id')
                            ->select(DB::raw("concat(`opponents`.`team_name`, ' - ',`fixtures`.`match_date`) as result, `fixtures`.`id` as `id`"))
                            ->withoutGlobalScope('user_id'),
                                'result', 'id')
                    ->targetId(),
            ]),

            Layout::tabs([
                'General' => Layout::rows([
                    Input::make('playerStats.min_played')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Min. Played')
                        ->required(),
                    Input::make('playerStats.goals')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Goals')
                        ->required(),
                    Input::make('playerStats.assist')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Assist')
                        ->required(),
                    Input::make('playerStats.goals_conceded')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Goals Conceded')
                        ->required(),
                    Input::make('playerStats.own_goals')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Own Goals')
                        ->required(),
                    Input::make('playerStats.yellow_c')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Yellow Card')
                        ->required(),
                    Input::make('playerStats.red_c')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Red Card')
                        ->required(),                                                       
                ]),                    

                'Involvement' => Layout::rows([
                    Input::make('playerStats.touches_t')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Total Touches')
                        ->required(),
                    Input::make('playerStats.touches_opp_half')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Touches in Opp. Half')
                        ->required(),
                    Input::make('playerStats.touches_f3')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Touches in Final 3rd')
                        ->required(),
                    Input::make('playerStats.pass_received_t')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Total Passes Received')
                        ->required(), 
                    Input::make('playerStats.pass_received_opp_half')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Passes Received in Opp. Half')
                        ->required(),
                    Input::make('playerStats.pass_received_f3')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Passes Received in Final 3rd')
                        ->required(),

                    Input::make('playerStats.take_ons_t')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Total Take Ons')
                        ->required(), 
                    Input::make('playerStats.take_ons_s')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Successful Take Ons')
                        ->required(),                                                       
                ]),

                'Distribution' => Layout::rows([
                    Input::make('playerStats.pass_t')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Total Pass')
                        ->required(), 
                    Input::make('playerStats.pass_s')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Successful Passes')
                        ->required(),
                    Input::make('playerStats.chance_created')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Chance Created')
                        ->required(), 
                    Input::make('playerStats.big_chance_created')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Big Chance Created')
                        ->required(),                                                       
                ]),

                'Goal Threat' => Layout::rows([
                    Input::make('playerStats.attempts_t')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Total Attempts')
                        ->required(), 
                    Input::make('playerStats.attempts_on_target')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Attempts on Target')
                        ->required(),                                                       
                ]),

                'Defending' => Layout::rows([
                    Input::make('playerStats.aerial_t')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Total Aerial Duels')
                        ->required(), 
                    Input::make('playerStats.aerial_w')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Aerial Duels Won')
                        ->required(),
                    Input::make('playerStats.tackles_t')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Total Tackles')
                        ->required(), 
                    Input::make('playerStats.tackles_w')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Tackles Won')
                        ->required(),
                    Input::make('playerStats.interceptions')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Interceptions')
                        ->required(), 
                    Input::make('playerStats.recoveries')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Recoveries')
                        ->required(),
                    Input::make('playerStats.clearances')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Clearances')
                        ->required(), 
                    Input::make('playerStats.blocks')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Blocks')
                        ->required(),
                    Input::make('playerStats.err_chance')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Error Leading to Chance')
                        ->required(), 
                    Input::make('playerStats.err_goals')
                        ->type('number')
                        ->min(0)
                        ->max(99)
                        ->title('Error Leading to Goal')
                        ->required(),                                                       
                ]),                                                  
            ]),                     
        ];
    }

    public function createOrUpdate(PlayerStats $playerStats, Request $request)
    {
        $playerStats->updateOrCreate(
            
            [
                'id' => $playerStats->id,  
            ],

            [
                'fixtures_id' => $request->input('playerStats.fixtures_id'),
                'player_id' =>  $request->input('playerStats.player_id'),

                'min_played' => $request->input('playerStats.min_played'),
                'goals' => $request->input('playerStats.goals'),
                'assist' => $request->input('playerStats.assist'),
                'goals_conceded' => $request->input('playerStats.goals_conceded'),
                'own_goals' => $request->input('playerStats.own_goals'),
                'yellow_c' => $request->input('playerStats.yellow_c'),
                'red_c' => $request->input('playerStats.red_c'),

                'touches_t' => $request->input('playerStats.touches_t'),
                'touches_opp_half' => $request->input('playerStats.touches_opp_half'),
                'touches_f3' => $request->input('playerStats.touches_f3'),
                'min_touches' => $request->input('playerStats.touches_t') == 0 ? 0 : ($request->input('playerStats.min_played') / $request->input('playerStats.touches_t')),             

                'pass_received_t' => $request->input('playerStats.pass_received_t'),
                'pass_received_opp_half' => $request->input('playerStats.pass_received_opp_half'),
                'pass_received_f3' => $request->input('playerStats.pass_received_f3'),
                'min_pass_received' => $request->input('playerStats.received_t') == 0 ? 0 : ($request->input('playerStats.min_played') / $request->input('playerStats.received_t')),

                'take_ons_t' => $request->input('playerStats.take_ons_t'),
                'take_ons_s' => $request->input('playerStats.take_ons_s'),
                'take_ons_s_p' => $request->input('playerStats.take_ont_t') == 0 ? 0 : ($request->input('playerStats.take_ons_s') / $request->input('playerStats.take_ont_t')),

                'pass_t' => $request->input('playerStats.pass_t'),
                'pass_s' => $request->input('playerStats.pass_s'),
                'pass_s_p' => $request->input('playerStats.pass_t') == 0 ? 0 : ($request->input('playerStats.pass_s') / $request->input('playerStats.pass_t')),                

                'chance_created' => $request->input('playerStats.chance_created'),
                'big_chance_created' => $request->input('playerStats.big_chance_created'),
                'min_chance_created' => $request->input('playerStats.chance_created') == 0 ? 0 : ($request->input('playerStats.min_played') / $request->input('playerStats.chance_created')),

                'goals_threat' => $request->input('playerStats.goals'),
                'min_goals' => $request->input('playerStats.goals') == 0 ? 0 : ($request->input('playerStats.min_played') / $request->input('playerStats.goals')),

                'attempts_t' => $request->input('playerStats.attempts_t'),
                'attempts_on_target' => $request->input('playerStats.attempts_on_target'),
                'min_attempts' => $request->input('playerStats.attempts_t') == 0 ? 0 : ($request->input('playerStats.min_played') / $request->input('playerStats.attempts_t')),

                'shot_acc' => $request->input('playerStats.attempts_t') == 0 ? 0 : ($request->input('playerStats.attempts_on_target') / $request->input('playerStats.attempts_t')),
                'goal_conversion' => $request->input('playerStats.goals') / $request->input('playerStats.attempts_t'),

                'aerial_t' => $request->input('playerStats.aerial_t'),
                'aerial_w' => $request->input('playerStats.aerial_w'),
                'aerial_w_p' => $request->input('playerStats.aerial_t') == 0 ? 0 : ($request->input('playerStats.aerial_w') / $request->input('playerStats.aerial_t')),

                'tackles_t' => $request->input('playerStats.tackles_t'),
                'tackles_w' => $request->input('playerStats.tackles_w'),
                'tackles_w_p' => $request->input('playerStats.tackles_t') == 0 ? 0 : ($request->input('playerStats.tackles_w') / $request->input('playerStats.tackles_t')),               

                'interceptions' => $request->input('playerStats.interceptions'),
                'recoveries' => $request->input('playerStats.recoveries'),
                'clearances' => $request->input('playerStats.clearances'),
                'blocks' => $request->input('playerStats.blocks'),
                'err_chance' => $request->input('playerStats.err_chance'),
                'err_goals' => $request->input('playerStats.err_goals'),
            ]
        );        

        Alert::info('You have successfully added statistics for this fixture.');

        return redirect()->route('platform.players.list');
    }

    /**
     * @param Post $post
     *
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function remove(PlayerStats $playerStats)
    {
        $playerStats->delete();

        Alert::info('You have successfully deleted a statistic from a fixture.');

        return redirect()->route('platform.players.stats');
    }
}
