<?php

namespace App\Orchid\Screens;

use App\Models\Players;
use App\Models\User;
use App\Models\dssWeight;
use App\Models\AttPhysical;
use App\Models\AttTechnical;
use App\Models\AttTactical;
use Orchid\Screen\Screen;
use Illuminate\Http\Request;
use Orchid\Screen\Layouts\Card;
use Orchid\Screen\Contracts\Cardable;
use Orchid\Support\Facades\Layout;
use Orchid\Support\Color;
use Orchid\Screen\Layouts\Compendium;
use Orchid\Screen\Actions\Button;
use Illuminate\Support\Facades\Storage;
use Orchid\Screen\Actions\Link;
use Orchid\Support\Facades\Alert;
use Orchid\Screen\Fields\Group;


class dssCustomScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Best Position (custom weight)';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = 'Calculated using Simple Additive Weighting Method with custom weights';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(Players $players, dssWeight $dssWeight): array
    {
        return [

            'players' => $players,
            'dssWeight' => $dssWeight,
            $id = $players->id,

            $this->name = Players::findOrFail($id)->presenter()->header(),
            $this->description = Players::findOrFail($id)->presenter()->position(),
        
            'card-attribute' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Attribute';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    return new Compendium([
                        'Speed'                 => $speed,
                        'Balance'               => $balance,
                        'Strength'              => $strength,
                        'Durability'            => $durability,
                        'Agility'               => $agility,
                        'Power'                 => $power,
                        'Stamina'               => $stamina,
                        'Jumping'               => $jumping,
                        'Passing'               => $pass,
                        'Control'               => $control,
                        'Long Passing'          => $long_pass,
                        'Shot Acc.'             => $shot_acc,
                        'Heading'               => $heading,
                        'Tackling'              => $tackle,
                        'Catching'              => $catching,
                        'Reflex'                => $reflex,
                        'Positioning'           => $positioning,
                        'Creative'              => $creative,
                        'Determination'         => $determination,
                        'Reading the Game'      => $reading,                        
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },            

            'card-normalized' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Attribute (Normalized)';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    return new Compendium([
                        'Speed'                 => $speed_norm,
                        'Balance'               => $balance_norm,
                        'Strength'              => $strength_norm,
                        'Durability'            => $durability_norm,
                        'Agility'               => $agility_norm,
                        'Power'                 => $power_norm,
                        'Stamina'               => $stamina_norm,
                        'Jumping'               => $jumping_norm,
                        'Passing'               => $pass_norm,
                        'Control'               => $control_norm,
                        'Long Passing'          => $long_pass_norm,
                        'Shot Acc.'             => $shot_acc_norm,
                        'Heading'               => $heading_norm,
                        'Tackle'                 => $tackle_norm,
                        'Catching'              => $catching_norm,
                        'Reflex'                => $reflex_norm,
                        'Positioning'           => $positioning_norm,
                        'Creative'              => $creative_norm,
                        'Determination'         => $determination_norm,
                        'Reading the Game'      => $reading_norm,                        
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-gk' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Value of Preference';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    $weight_speed_gk             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_speed();       
                    $weight_balance_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_balance();      
                    $weight_strength_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_strength();        
                    $weight_durability_gk        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_durability();      
                    $weight_agility_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_agility();      
                    $weight_power_gk             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_power();          
                    $weight_stamina_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_stamina();         
                    $weight_jumping_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_jumping();      
                    $weight_pass_gk              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_pass();           
                    $weight_control_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_control();        
                    $weight_long_pass_gk         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_long_pass();    
                    $weight_acc_gk               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_shot_acc();            
                    $weight_heading_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_heading();      
                    $weight_tackle_gk            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_tackle();         
                    $weight_catching_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_catching();     
                    $weight_reflex_gk            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_reflex();       
                    $weight_positioning_gk       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_positioning();                       
                    $weight_creative_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_creative();       
                    $weight_determination_gk     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_determination();                        
                    $weight_reading_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_reading();      

                    $speed_vop              = $speed_norm            * $weight_speed_gk;                    
                    $balance_vop            = $balance_norm          * $weight_balance_gk;                
                    $strength_vop           = $strength_norm         * $weight_strength_gk;              
                    $durability_vop         = $durability_norm       * $weight_durability_gk;           
                    $agility_vop            = $agility_norm          * $weight_agility_gk;                                                    
                    $power_vop              = $power_norm            * $weight_power_gk;                                                  
                    $stamina_vop            = $stamina_norm          * $weight_stamina_gk;                                                  
                    $jumping_vop            = $jumping_norm          * $weight_jumping_gk;                                                      
                    $pass_vop               = $pass_norm             * $weight_pass_gk;                   
                    $control_vop            = $control_norm          * $weight_control_gk;              
                    $long_pass_vop          = $long_pass_norm        * $weight_long_pass_gk;           
                    $shot_acc_vop           = $shot_acc_norm         * $weight_acc_gk;           
                    $heading_vop            = $heading_norm          * $weight_heading_gk;               
                    $tackle_vop             = $tackle_norm           * $weight_tackle_gk;                                                             
                    $catching_vop           = $catching_norm         * $weight_catching_gk;            
                    $reflex_vop             = $reflex_norm           * $weight_reflex_gk;                
                    $positioning_vop        = $positioning_norm      * $weight_positioning_gk;         
                    $creative_vop           = $creative_norm         * $weight_creative_gk;            
                    $determination_vop      = $determination_norm    * $weight_determination_gk;       
                    $reading_vop            = $reading_norm          * $weight_reading_gk;             

                    return new Compendium([
                        'Speed'                 => $speed_vop,
                        'Balance'               => $balance_vop,
                        'Strength'              => $strength_vop,
                        'Durability'            => $durability_vop,
                        'Agility'               => $agility_vop,
                        'Power'                 => $power_vop,
                        'Stamina'               => $stamina_vop,
                        'Jumping'               => $jumping_vop,
                        'Passing'               => $pass_vop,
                        'Control'               => $control_vop,
                        'Long Passing'          => $long_pass_vop,
                        'Shot Acc.'             => $shot_acc_vop,
                        'Heading'               => $heading_vop,
                        'Tackle'                 => $tackle_vop,
                        'Catching'              => $catching_vop,
                        'Reflex'                => $reflex_vop,
                        'Positioning'           => $positioning_vop,
                        'Creative'              => $creative_vop,
                        'Determination'         => $determination_vop,
                        'Reading the Game'      => $reading_vop,                        
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-def' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Value of Preference';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    $weight_speed_def             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_speed();       
                    $weight_balance_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_balance();      
                    $weight_strength_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_strength();        
                    $weight_durability_def        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_durability();      
                    $weight_agility_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_agility();      
                    $weight_power_def             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_power();          
                    $weight_stamina_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_stamina();         
                    $weight_jumping_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_jumping();      
                    $weight_pass_def              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_pass();           
                    $weight_control_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_control();        
                    $weight_long_pass_def         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_long_pass();    
                    $weight_acc_def               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_shot_acc();            
                    $weight_heading_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_heading();      
                    $weight_tackle_def            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_tackle();         
                    $weight_catching_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_catching();     
                    $weight_reflex_def            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_reflex();       
                    $weight_positioning_def       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_positioning();                       
                    $weight_creative_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_creative();       
                    $weight_determination_def     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_determination();                        
                    $weight_reading_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_reading();     

                    $speed_vop              = $speed_norm            * $weight_speed_def;                    
                    $balance_vop            = $balance_norm          * $weight_balance_def;                
                    $strength_vop           = $strength_norm         * $weight_strength_def;              
                    $durability_vop         = $durability_norm       * $weight_durability_def;           
                    $agility_vop            = $agility_norm          * $weight_agility_def;                                                    
                    $power_vop              = $power_norm            * $weight_power_def;                                                  
                    $stamina_vop            = $stamina_norm          * $weight_stamina_def;                                                  
                    $jumping_vop            = $jumping_norm          * $weight_jumping_def;                                                      
                    $pass_vop               = $pass_norm             * $weight_pass_def;                   
                    $control_vop            = $control_norm          * $weight_control_def;              
                    $long_pass_vop          = $long_pass_norm        * $weight_long_pass_def;           
                    $shot_acc_vop           = $shot_acc_norm         * $weight_acc_def;           
                    $heading_vop            = $heading_norm          * $weight_heading_def;               
                    $tackle_vop             = $tackle_norm           * $weight_tackle_def;                                                             
                    $catching_vop           = $catching_norm         * $weight_catching_def;            
                    $reflex_vop             = $reflex_norm           * $weight_reflex_def;                
                    $positioning_vop        = $positioning_norm      * $weight_positioning_def;         
                    $creative_vop           = $creative_norm         * $weight_creative_def;            
                    $determination_vop      = $determination_norm    * $weight_determination_def;       
                    $reading_vop            = $reading_norm          * $weight_reading_def;             

                    return new Compendium([
                        'Speed'                 => $speed_vop,
                        'Balance'               => $balance_vop,
                        'Strength'              => $strength_vop,
                        'Durability'            => $durability_vop,
                        'Agility'               => $agility_vop,
                        'Power'                 => $power_vop,
                        'Stamina'               => $stamina_vop,
                        'Jumping'               => $jumping_vop,
                        'Passing'               => $pass_vop,
                        'Control'               => $control_vop,
                        'Long Passing'          => $long_pass_vop,
                        'Shot Acc.'             => $shot_acc_vop,
                        'Heading'               => $heading_vop,
                        'Tackle'                 => $tackle_vop,
                        'Catching'              => $catching_vop,
                        'Reflex'                => $reflex_vop,
                        'Positioning'           => $positioning_vop,
                        'Creative'              => $creative_vop,
                        'Determination'         => $determination_vop,
                        'Reading the Game'      => $reading_vop,                        
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            }, 

            'card-dm' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Value of Preference';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    $weight_speed_dm             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_speed();       
                    $weight_balance_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_balance();      
                    $weight_strength_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_strength();        
                    $weight_durability_dm        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_durability();      
                    $weight_agility_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_agility();      
                    $weight_power_dm             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_power();          
                    $weight_stamina_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_stamina();         
                    $weight_jumping_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_jumping();      
                    $weight_pass_dm              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_pass();           
                    $weight_control_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_control();        
                    $weight_long_pass_dm         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_long_pass();    
                    $weight_acc_dm               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_shot_acc();            
                    $weight_heading_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_heading();      
                    $weight_tackle_dm            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_tackle();         
                    $weight_catching_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_catching();     
                    $weight_reflex_dm            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_reflex();       
                    $weight_positioning_dm       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_positioning();                       
                    $weight_creative_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_creative();       
                    $weight_determination_dm     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_determination();                        
                    $weight_reading_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_reading();     

                    $speed_vop              = $speed_norm            * $weight_speed_dm;                    
                    $balance_vop            = $balance_norm          * $weight_balance_dm;                
                    $strength_vop           = $strength_norm         * $weight_strength_dm;              
                    $durability_vop         = $durability_norm       * $weight_durability_dm;           
                    $agility_vop            = $agility_norm          * $weight_agility_dm;                                                    
                    $power_vop              = $power_norm            * $weight_power_dm;                                                  
                    $stamina_vop            = $stamina_norm          * $weight_stamina_dm;                                                  
                    $jumping_vop            = $jumping_norm          * $weight_jumping_dm;                                                      
                    $pass_vop               = $pass_norm             * $weight_pass_dm;                   
                    $control_vop            = $control_norm          * $weight_control_dm;              
                    $long_pass_vop          = $long_pass_norm        * $weight_long_pass_dm;           
                    $shot_acc_vop           = $shot_acc_norm         * $weight_acc_dm;           
                    $heading_vop            = $heading_norm          * $weight_heading_dm;               
                    $tackle_vop             = $tackle_norm           * $weight_tackle_dm;                                                             
                    $catching_vop           = $catching_norm         * $weight_catching_dm;            
                    $reflex_vop             = $reflex_norm           * $weight_reflex_dm;                
                    $positioning_vop        = $positioning_norm      * $weight_positioning_dm;         
                    $creative_vop           = $creative_norm         * $weight_creative_dm;            
                    $determination_vop      = $determination_norm    * $weight_determination_dm;       
                    $reading_vop            = $reading_norm          * $weight_reading_dm;             

                    return new Compendium([
                        'Speed'                 => $speed_vop,
                        'Balance'               => $balance_vop,
                        'Strength'              => $strength_vop,
                        'Durability'            => $durability_vop,
                        'Agility'               => $agility_vop,
                        'Power'                 => $power_vop,
                        'Stamina'               => $stamina_vop,
                        'Jumping'               => $jumping_vop,
                        'Passing'               => $pass_vop,
                        'Control'               => $control_vop,
                        'Long Passing'          => $long_pass_vop,
                        'Shot Acc.'             => $shot_acc_vop,
                        'Heading'               => $heading_vop,
                        'Tackle'                 => $tackle_vop,
                        'Catching'              => $catching_vop,
                        'Reflex'                => $reflex_vop,
                        'Positioning'           => $positioning_vop,
                        'Creative'              => $creative_vop,
                        'Determination'         => $determination_vop,
                        'Reading the Game'      => $reading_vop,                        
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-am' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Value of Preference';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    $weight_speed_am             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_speed();       
                    $weight_balance_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_balance();      
                    $weight_strength_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_strength();        
                    $weight_durability_am        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_durability();      
                    $weight_agility_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_agility();      
                    $weight_power_am             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_power();          
                    $weight_stamina_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_stamina();         
                    $weight_jumping_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_jumping();      
                    $weight_pass_am              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_pass();           
                    $weight_control_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_control();        
                    $weight_long_pass_am         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_long_pass();    
                    $weight_acc_am               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_shot_acc();            
                    $weight_heading_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_heading();      
                    $weight_tackle_am            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_tackle();         
                    $weight_catching_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_catching();     
                    $weight_reflex_am            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_reflex();       
                    $weight_positioning_am       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_positioning();                       
                    $weight_creative_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_creative();       
                    $weight_determination_am     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_determination();                        
                    $weight_reading_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_reading();     

                    $speed_vop              = $speed_norm            * $weight_speed_am;                    
                    $balance_vop            = $balance_norm          * $weight_balance_am;                
                    $strength_vop           = $strength_norm         * $weight_strength_am;              
                    $durability_vop         = $durability_norm       * $weight_durability_am;           
                    $agility_vop            = $agility_norm          * $weight_agility_am;                                                    
                    $power_vop              = $power_norm            * $weight_power_am;                                                  
                    $stamina_vop            = $stamina_norm          * $weight_stamina_am;                                                  
                    $jumping_vop            = $jumping_norm          * $weight_jumping_am;                                                      
                    $pass_vop               = $pass_norm             * $weight_pass_am;                   
                    $control_vop            = $control_norm          * $weight_control_am;              
                    $long_pass_vop          = $long_pass_norm        * $weight_long_pass_am;           
                    $shot_acc_vop           = $shot_acc_norm         * $weight_acc_am;           
                    $heading_vop            = $heading_norm          * $weight_heading_am;               
                    $tackle_vop             = $tackle_norm           * $weight_tackle_am;                                                             
                    $catching_vop           = $catching_norm         * $weight_catching_am;            
                    $reflex_vop             = $reflex_norm           * $weight_reflex_am;                
                    $positioning_vop        = $positioning_norm      * $weight_positioning_am;         
                    $creative_vop           = $creative_norm         * $weight_creative_am;            
                    $determination_vop      = $determination_norm    * $weight_determination_am;       
                    $reading_vop            = $reading_norm          * $weight_reading_am;             

                    return new Compendium([
                        'Speed'                 => $speed_vop,
                        'Balance'               => $balance_vop,
                        'Strength'              => $strength_vop,
                        'Durability'            => $durability_vop,
                        'Agility'               => $agility_vop,
                        'Power'                 => $power_vop,
                        'Stamina'               => $stamina_vop,
                        'Jumping'               => $jumping_vop,
                        'Passing'               => $pass_vop,
                        'Control'               => $control_vop,
                        'Long Passing'          => $long_pass_vop,
                        'Shot Acc.'             => $shot_acc_vop,
                        'Heading'               => $heading_vop,
                        'Tackle'                 => $tackle_vop,
                        'Catching'              => $catching_vop,
                        'Reflex'                => $reflex_vop,
                        'Positioning'           => $positioning_vop,
                        'Creative'              => $creative_vop,
                        'Determination'         => $determination_vop,
                        'Reading the Game'      => $reading_vop,                        
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-wing' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Value of Preference';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    $weight_speed_wing             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_speed();       
                    $weight_balance_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_balance();      
                    $weight_strength_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_strength();        
                    $weight_durability_wing        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_durability();      
                    $weight_agility_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_agility();      
                    $weight_power_wing             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_power();          
                    $weight_stamina_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_stamina();         
                    $weight_jumping_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_jumping();      
                    $weight_pass_wing              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_pass();           
                    $weight_control_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_control();        
                    $weight_long_pass_wing         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_long_pass();    
                    $weight_acc_wing               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_shot_acc();            
                    $weight_heading_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_heading();      
                    $weight_tackle_wing            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_tackle();         
                    $weight_catching_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_catching();     
                    $weight_reflex_wing            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_reflex();       
                    $weight_positioning_wing       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_positioning();                       
                    $weight_creative_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_creative();       
                    $weight_determination_wing     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_determination();                        
                    $weight_reading_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_reading();    

                    $speed_vop              = $speed_norm            * $weight_speed_wing;                    
                    $balance_vop            = $balance_norm          * $weight_balance_wing;                
                    $strength_vop           = $strength_norm         * $weight_strength_wing;              
                    $durability_vop         = $durability_norm       * $weight_durability_wing;           
                    $agility_vop            = $agility_norm          * $weight_agility_wing;                                                    
                    $power_vop              = $power_norm            * $weight_power_wing;                                                  
                    $stamina_vop            = $stamina_norm          * $weight_stamina_wing;                                                  
                    $jumping_vop            = $jumping_norm          * $weight_jumping_wing;                                                      
                    $pass_vop               = $pass_norm             * $weight_pass_wing;                   
                    $control_vop            = $control_norm          * $weight_control_wing;              
                    $long_pass_vop          = $long_pass_norm        * $weight_long_pass_wing;           
                    $shot_acc_vop           = $shot_acc_norm         * $weight_acc_wing;           
                    $heading_vop            = $heading_norm          * $weight_heading_wing;               
                    $tackle_vop             = $tackle_norm           * $weight_tackle_wing;                                                             
                    $catching_vop           = $catching_norm         * $weight_catching_wing;            
                    $reflex_vop             = $reflex_norm           * $weight_reflex_wing;                
                    $positioning_vop        = $positioning_norm      * $weight_positioning_wing;         
                    $creative_vop           = $creative_norm         * $weight_creative_wing;            
                    $determination_vop      = $determination_norm    * $weight_determination_wing;       
                    $reading_vop            = $reading_norm          * $weight_reading_wing;             

                    return new Compendium([
                        'Speed'                 => $speed_vop,
                        'Balance'               => $balance_vop,
                        'Strength'              => $strength_vop,
                        'Durability'            => $durability_vop,
                        'Agility'               => $agility_vop,
                        'Power'                 => $power_vop,
                        'Stamina'               => $stamina_vop,
                        'Jumping'               => $jumping_vop,
                        'Passing'               => $pass_vop,
                        'Control'               => $control_vop,
                        'Long Passing'          => $long_pass_vop,
                        'Shot Acc.'             => $shot_acc_vop,
                        'Heading'               => $heading_vop,
                        'Tackle'                 => $tackle_vop,
                        'Catching'              => $catching_vop,
                        'Reflex'                => $reflex_vop,
                        'Positioning'           => $positioning_vop,
                        'Creative'              => $creative_vop,
                        'Determination'         => $determination_vop,
                        'Reading the Game'      => $reading_vop,                        
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-st' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Value of Preference';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    $weight_speed_st             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_speed();       
                    $weight_balance_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_balance();      
                    $weight_strength_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_strength();        
                    $weight_durability_st        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_durability();      
                    $weight_agility_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_agility();      
                    $weight_power_st             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_power();          
                    $weight_stamina_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_stamina();         
                    $weight_jumping_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_jumping();      
                    $weight_pass_st              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_pass();           
                    $weight_control_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_control();        
                    $weight_long_pass_st         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_long_pass();    
                    $weight_acc_st               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_shot_acc();            
                    $weight_heading_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_heading();      
                    $weight_tackle_st            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_tackle();         
                    $weight_catching_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_catching();     
                    $weight_reflex_st            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_reflex();       
                    $weight_positioning_st       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_positioning();                       
                    $weight_creative_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_creative();       
                    $weight_determination_st     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_determination();                        
                    $weight_reading_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_reading();      

                    $speed_vop              = $speed_norm            * $weight_speed_st;                    
                    $balance_vop            = $balance_norm          * $weight_balance_st;                
                    $strength_vop           = $strength_norm         * $weight_strength_st;              
                    $durability_vop         = $durability_norm       * $weight_durability_st;           
                    $agility_vop            = $agility_norm          * $weight_agility_st;                                                    
                    $power_vop              = $power_norm            * $weight_power_st;                                                  
                    $stamina_vop            = $stamina_norm          * $weight_stamina_st;                                                  
                    $jumping_vop            = $jumping_norm          * $weight_jumping_st;                                                      
                    $pass_vop               = $pass_norm             * $weight_pass_st;                   
                    $control_vop            = $control_norm          * $weight_control_st;              
                    $long_pass_vop          = $long_pass_norm        * $weight_long_pass_st;           
                    $shot_acc_vop           = $shot_acc_norm         * $weight_acc_st;           
                    $heading_vop            = $heading_norm          * $weight_heading_st;               
                    $tackle_vop             = $tackle_norm           * $weight_tackle_st;                                                             
                    $catching_vop           = $catching_norm         * $weight_catching_st;            
                    $reflex_vop             = $reflex_norm           * $weight_reflex_st;                
                    $positioning_vop        = $positioning_norm      * $weight_positioning_st;         
                    $creative_vop           = $creative_norm         * $weight_creative_st;            
                    $determination_vop      = $determination_norm    * $weight_determination_st;       
                    $reading_vop            = $reading_norm          * $weight_reading_st;             

                    return new Compendium([
                        'Speed'                 => $speed_vop,
                        'Balance'               => $balance_vop,
                        'Strength'              => $strength_vop,
                        'Durability'            => $durability_vop,
                        'Agility'               => $agility_vop,
                        'Power'                 => $power_vop,
                        'Stamina'               => $stamina_vop,
                        'Jumping'               => $jumping_vop,
                        'Passing'               => $pass_vop,
                        'Control'               => $control_vop,
                        'Long Passing'          => $long_pass_vop,
                        'Shot Acc.'             => $shot_acc_vop,
                        'Heading'               => $heading_vop,
                        'Tackle'                 => $tackle_vop,
                        'Catching'              => $catching_vop,
                        'Reflex'                => $reflex_vop,
                        'Positioning'           => $positioning_vop,
                        'Creative'              => $creative_vop,
                        'Determination'         => $determination_vop,
                        'Reading the Game'      => $reading_vop,                        
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },          

            'card-total' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Total Value of Preference';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    $weight_speed_gk             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_speed();       
                    $weight_balance_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_balance();      
                    $weight_strength_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_strength();        
                    $weight_durability_gk        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_durability();      
                    $weight_agility_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_agility();      
                    $weight_power_gk             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_power();          
                    $weight_stamina_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_stamina();         
                    $weight_jumping_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_jumping();      
                    $weight_pass_gk              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_pass();           
                    $weight_control_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_control();        
                    $weight_long_pass_gk         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_long_pass();    
                    $weight_acc_gk               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_shot_acc();            
                    $weight_heading_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_heading();      
                    $weight_tackle_gk            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_tackle();         
                    $weight_catching_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_catching();     
                    $weight_reflex_gk            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_reflex();       
                    $weight_positioning_gk       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_positioning();                       
                    $weight_creative_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_creative();       
                    $weight_determination_gk     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_determination();                        
                    $weight_reading_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_reading();      

                    $speed_vop_gk              = $speed_norm            * $weight_speed_gk;                    
                    $balance_vop_gk            = $balance_norm          * $weight_balance_gk;                
                    $strength_vop_gk           = $strength_norm         * $weight_strength_gk;              
                    $durability_vop_gk         = $durability_norm       * $weight_durability_gk;           
                    $agility_vop_gk            = $agility_norm          * $weight_agility_gk;                                                    
                    $power_vop_gk              = $power_norm            * $weight_power_gk;                                                  
                    $stamina_vop_gk            = $stamina_norm          * $weight_stamina_gk;                                                  
                    $jumping_vop_gk            = $jumping_norm          * $weight_jumping_gk;                                                      
                    $pass_vop_gk               = $pass_norm             * $weight_pass_gk;                   
                    $control_vop_gk            = $control_norm          * $weight_control_gk;              
                    $long_pass_vop_gk          = $long_pass_norm        * $weight_long_pass_gk;           
                    $shot_acc_vop_gk           = $shot_acc_norm         * $weight_acc_gk;           
                    $heading_vop_gk            = $heading_norm          * $weight_heading_gk;               
                    $tackle_vop_gk             = $tackle_norm           * $weight_tackle_gk;                                                             
                    $catching_vop_gk           = $catching_norm         * $weight_catching_gk;            
                    $reflex_vop_gk             = $reflex_norm           * $weight_reflex_gk;                
                    $positioning_vop_gk        = $positioning_norm      * $weight_positioning_gk;         
                    $creative_vop_gk           = $creative_norm         * $weight_creative_gk;            
                    $determination_vop_gk      = $determination_norm    * $weight_determination_gk;       
                    $reading_vop_gk            = $reading_norm          * $weight_reading_gk; 

                    $weight_speed_def             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_speed();       
                    $weight_balance_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_balance();      
                    $weight_strength_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_strength();        
                    $weight_durability_def        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_durability();      
                    $weight_agility_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_agility();      
                    $weight_power_def             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_power();          
                    $weight_stamina_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_stamina();         
                    $weight_jumping_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_jumping();      
                    $weight_pass_def              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_pass();           
                    $weight_control_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_control();        
                    $weight_long_pass_def         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_long_pass();    
                    $weight_acc_def               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_shot_acc();            
                    $weight_heading_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_heading();      
                    $weight_tackle_def            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_tackle();         
                    $weight_catching_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_catching();     
                    $weight_reflex_def            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_reflex();       
                    $weight_positioning_def       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_positioning();                       
                    $weight_creative_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_creative();       
                    $weight_determination_def     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_determination();                        
                    $weight_reading_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_reading();      

                    $speed_vop_def              = $speed_norm            * $weight_speed_def;                    
                    $balance_vop_def            = $balance_norm          * $weight_balance_def;                
                    $strength_vop_def           = $strength_norm         * $weight_strength_def;              
                    $durability_vop_def         = $durability_norm       * $weight_durability_def;           
                    $agility_vop_def            = $agility_norm          * $weight_agility_def;                                                    
                    $power_vop_def              = $power_norm            * $weight_power_def;                                                  
                    $stamina_vop_def            = $stamina_norm          * $weight_stamina_def;                                                  
                    $jumping_vop_def            = $jumping_norm          * $weight_jumping_def;                                                      
                    $pass_vop_def               = $pass_norm             * $weight_pass_def;                   
                    $control_vop_def            = $control_norm          * $weight_control_def;              
                    $long_pass_vop_def          = $long_pass_norm        * $weight_long_pass_def;           
                    $shot_acc_vop_def           = $shot_acc_norm         * $weight_acc_def;           
                    $heading_vop_def            = $heading_norm          * $weight_heading_def;               
                    $tackle_vop_def             = $tackle_norm           * $weight_tackle_def;                                                             
                    $catching_vop_def           = $catching_norm         * $weight_catching_def;            
                    $reflex_vop_def             = $reflex_norm           * $weight_reflex_def;                
                    $positioning_vop_def        = $positioning_norm      * $weight_positioning_def;         
                    $creative_vop_def           = $creative_norm         * $weight_creative_def;            
                    $determination_vop_def      = $determination_norm    * $weight_determination_def;       
                    $reading_vop_def            = $reading_norm          * $weight_reading_def;             

                    $weight_speed_dm             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_speed();       
                    $weight_balance_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_balance();      
                    $weight_strength_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_strength();        
                    $weight_durability_dm        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_durability();      
                    $weight_agility_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_agility();      
                    $weight_power_dm             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_power();          
                    $weight_stamina_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_stamina();         
                    $weight_jumping_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_jumping();      
                    $weight_pass_dm              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_pass();           
                    $weight_control_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_control();        
                    $weight_long_pass_dm         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_long_pass();    
                    $weight_acc_dm               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_shot_acc();            
                    $weight_heading_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_heading();      
                    $weight_tackle_dm            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_tackle();         
                    $weight_catching_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_catching();     
                    $weight_reflex_dm            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_reflex();       
                    $weight_positioning_dm       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_positioning();                       
                    $weight_creative_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_creative();       
                    $weight_determination_dm     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_determination();                        
                    $weight_reading_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_reading();      

                    $speed_vop_dm              = $speed_norm            * $weight_speed_dm;                    
                    $balance_vop_dm            = $balance_norm          * $weight_balance_dm;                
                    $strength_vop_dm           = $strength_norm         * $weight_strength_dm;              
                    $durability_vop_dm         = $durability_norm       * $weight_durability_dm;           
                    $agility_vop_dm            = $agility_norm          * $weight_agility_dm;                                                    
                    $power_vop_dm              = $power_norm            * $weight_power_dm;                                                  
                    $stamina_vop_dm            = $stamina_norm          * $weight_stamina_dm;                                                  
                    $jumping_vop_dm            = $jumping_norm          * $weight_jumping_dm;                                                      
                    $pass_vop_dm               = $pass_norm             * $weight_pass_dm;                   
                    $control_vop_dm            = $control_norm          * $weight_control_dm;              
                    $long_pass_vop_dm          = $long_pass_norm        * $weight_long_pass_dm;           
                    $shot_acc_vop_dm           = $shot_acc_norm         * $weight_acc_dm;           
                    $heading_vop_dm            = $heading_norm          * $weight_heading_dm;               
                    $tackle_vop_dm             = $tackle_norm           * $weight_tackle_dm;                                                             
                    $catching_vop_dm           = $catching_norm         * $weight_catching_dm;            
                    $reflex_vop_dm             = $reflex_norm           * $weight_reflex_dm;                
                    $positioning_vop_dm        = $positioning_norm      * $weight_positioning_dm;         
                    $creative_vop_dm           = $creative_norm         * $weight_creative_dm;            
                    $determination_vop_dm      = $determination_norm    * $weight_determination_dm;       
                    $reading_vop_dm            = $reading_norm          * $weight_reading_dm;             

                    $weight_speed_am             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_speed();       
                    $weight_balance_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_balance();      
                    $weight_strength_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_strength();        
                    $weight_durability_am        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_durability();      
                    $weight_agility_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_agility();      
                    $weight_power_am             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_power();          
                    $weight_stamina_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_stamina();         
                    $weight_jumping_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_jumping();      
                    $weight_pass_am              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_pass();           
                    $weight_control_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_control();        
                    $weight_long_pass_am         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_long_pass();    
                    $weight_acc_am               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_shot_acc();            
                    $weight_heading_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_heading();      
                    $weight_tackle_am            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_tackle();         
                    $weight_catching_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_catching();     
                    $weight_reflex_am            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_reflex();       
                    $weight_positioning_am       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_positioning();                       
                    $weight_creative_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_creative();       
                    $weight_determination_am     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_determination();                        
                    $weight_reading_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_reading();     

                    $speed_vop_am              = $speed_norm            * $weight_speed_am;                    
                    $balance_vop_am            = $balance_norm          * $weight_balance_am;                
                    $strength_vop_am           = $strength_norm         * $weight_strength_am;              
                    $durability_vop_am         = $durability_norm       * $weight_durability_am;           
                    $agility_vop_am            = $agility_norm          * $weight_agility_am;                                                    
                    $power_vop_am              = $power_norm            * $weight_power_am;                                                  
                    $stamina_vop_am            = $stamina_norm          * $weight_stamina_am;                                                  
                    $jumping_vop_am            = $jumping_norm          * $weight_jumping_am;                                                      
                    $pass_vop_am               = $pass_norm             * $weight_pass_am;                   
                    $control_vop_am            = $control_norm          * $weight_control_am;              
                    $long_pass_vop_am          = $long_pass_norm        * $weight_long_pass_am;           
                    $shot_acc_vop_am           = $shot_acc_norm         * $weight_acc_am;           
                    $heading_vop_am            = $heading_norm          * $weight_heading_am;               
                    $tackle_vop_am             = $tackle_norm           * $weight_tackle_am;                                                             
                    $catching_vop_am           = $catching_norm         * $weight_catching_am;            
                    $reflex_vop_am             = $reflex_norm           * $weight_reflex_am;                
                    $positioning_vop_am        = $positioning_norm      * $weight_positioning_am;         
                    $creative_vop_am           = $creative_norm         * $weight_creative_am;            
                    $determination_vop_am      = $determination_norm    * $weight_determination_am;       
                    $reading_vop_am            = $reading_norm          * $weight_reading_am;

                    $weight_speed_wing             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_speed();       
                    $weight_balance_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_balance();      
                    $weight_strength_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_strength();        
                    $weight_durability_wing        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_durability();      
                    $weight_agility_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_agility();      
                    $weight_power_wing             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_power();          
                    $weight_stamina_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_stamina();         
                    $weight_jumping_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_jumping();      
                    $weight_pass_wing              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_pass();           
                    $weight_control_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_control();        
                    $weight_long_pass_wing         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_long_pass();    
                    $weight_acc_wing               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_shot_acc();            
                    $weight_heading_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_heading();      
                    $weight_tackle_wing            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_tackle();         
                    $weight_catching_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_catching();     
                    $weight_reflex_wing            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_reflex();       
                    $weight_positioning_wing       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_positioning();                       
                    $weight_creative_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_creative();       
                    $weight_determination_wing     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_determination();                        
                    $weight_reading_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_reading();      

                    $speed_vop_wing              = $speed_norm            * $weight_speed_wing;                    
                    $balance_vop_wing            = $balance_norm          * $weight_balance_wing;                
                    $strength_vop_wing           = $strength_norm         * $weight_strength_wing;              
                    $durability_vop_wing         = $durability_norm       * $weight_durability_wing;           
                    $agility_vop_wing            = $agility_norm          * $weight_agility_wing;                                                    
                    $power_vop_wing              = $power_norm            * $weight_power_wing;                                                  
                    $stamina_vop_wing            = $stamina_norm          * $weight_stamina_wing;                                                  
                    $jumping_vop_wing            = $jumping_norm          * $weight_jumping_wing;                                                      
                    $pass_vop_wing               = $pass_norm             * $weight_pass_wing;                   
                    $control_vop_wing            = $control_norm          * $weight_control_wing;              
                    $long_pass_vop_wing          = $long_pass_norm        * $weight_long_pass_wing;           
                    $shot_acc_vop_wing           = $shot_acc_norm         * $weight_acc_wing;           
                    $heading_vop_wing            = $heading_norm          * $weight_heading_wing;               
                    $tackle_vop_wing             = $tackle_norm           * $weight_tackle_wing;                                                             
                    $catching_vop_wing           = $catching_norm         * $weight_catching_wing;            
                    $reflex_vop_wing             = $reflex_norm           * $weight_reflex_wing;                
                    $positioning_vop_wing        = $positioning_norm      * $weight_positioning_wing;         
                    $creative_vop_wing           = $creative_norm         * $weight_creative_wing;            
                    $determination_vop_wing      = $determination_norm    * $weight_determination_wing;       
                    $reading_vop_wing            = $reading_norm          * $weight_reading_wing;

                    $weight_speed_st             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_speed();       
                    $weight_balance_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_balance();      
                    $weight_strength_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_strength();        
                    $weight_durability_st        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_durability();      
                    $weight_agility_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_agility();      
                    $weight_power_st             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_power();          
                    $weight_stamina_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_stamina();         
                    $weight_jumping_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_jumping();      
                    $weight_pass_st              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_pass();           
                    $weight_control_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_control();        
                    $weight_long_pass_st         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_long_pass();    
                    $weight_acc_st               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_shot_acc();            
                    $weight_heading_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_heading();      
                    $weight_tackle_st            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_tackle();         
                    $weight_catching_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_catching();     
                    $weight_reflex_st            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_reflex();       
                    $weight_positioning_st       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_positioning();                       
                    $weight_creative_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_creative();       
                    $weight_determination_st     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_determination();                        
                    $weight_reading_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_reading();     

                    $speed_vop_st              = $speed_norm            * $weight_speed_st;                    
                    $balance_vop_st            = $balance_norm          * $weight_balance_st;                
                    $strength_vop_st           = $strength_norm         * $weight_strength_st;              
                    $durability_vop_st         = $durability_norm       * $weight_durability_st;           
                    $agility_vop_st            = $agility_norm          * $weight_agility_st;                                                    
                    $power_vop_st              = $power_norm            * $weight_power_st;                                                  
                    $stamina_vop_st            = $stamina_norm          * $weight_stamina_st;                                                  
                    $jumping_vop_st            = $jumping_norm          * $weight_jumping_st;                                                      
                    $pass_vop_st               = $pass_norm             * $weight_pass_st;                   
                    $control_vop_st            = $control_norm          * $weight_control_st;              
                    $long_pass_vop_st          = $long_pass_norm        * $weight_long_pass_st;           
                    $shot_acc_vop_st           = $shot_acc_norm         * $weight_acc_st;           
                    $heading_vop_st            = $heading_norm          * $weight_heading_st;               
                    $tackle_vop_st             = $tackle_norm           * $weight_tackle_st;                                                             
                    $catching_vop_st           = $catching_norm         * $weight_catching_st;            
                    $reflex_vop_st             = $reflex_norm           * $weight_reflex_st;                
                    $positioning_vop_st        = $positioning_norm      * $weight_positioning_st;         
                    $creative_vop_st           = $creative_norm         * $weight_creative_st;            
                    $determination_vop_st      = $determination_norm    * $weight_determination_st;       
                    $reading_vop_st            = $reading_norm          * $weight_reading_st;             

                    $sum_gk =
                        $speed_vop_gk +                       
                        $balance_vop_gk +                   
                        $strength_vop_gk +                 
                        $durability_vop_gk +              
                        $agility_vop_gk +                                                       
                        $power_vop_gk +                                                     
                        $stamina_vop_gk +                                                     
                        $jumping_vop_gk +                                                         
                        $pass_vop_gk +                      
                        $control_vop_gk +                 
                        $long_pass_vop_gk +              
                        $shot_acc_vop_gk +         
                        $heading_vop_gk +                  
                        $tackle_vop_gk +                                                                
                        $catching_vop_gk +               
                        $reflex_vop_gk +                   
                        $positioning_vop_gk +            
                        $creative_vop_gk +               
                        $determination_vop_gk +          
                        $reading_vop_gk;                          

                    $sum_def =
                        $speed_vop_def +                       
                        $balance_vop_def +                   
                        $strength_vop_def +                 
                        $durability_vop_def +              
                        $agility_vop_def +                                                       
                        $power_vop_def +                                                     
                        $stamina_vop_def +                                                     
                        $jumping_vop_def +                                                         
                        $pass_vop_def +                      
                        $control_vop_def +                 
                        $long_pass_vop_def +              
                        $shot_acc_vop_def +         
                        $heading_vop_def +                  
                        $tackle_vop_def +                                                                
                        $catching_vop_def +               
                        $reflex_vop_def +                   
                        $positioning_vop_def +            
                        $creative_vop_def +               
                        $determination_vop_def +          
                        $reading_vop_def;

                    $sum_dm =
                        $speed_vop_dm +                       
                        $balance_vop_dm +                   
                        $strength_vop_dm +                 
                        $durability_vop_dm +              
                        $agility_vop_dm +                                                       
                        $power_vop_dm +                                                     
                        $stamina_vop_dm +                                                     
                        $jumping_vop_dm +                                                         
                        $pass_vop_dm +                      
                        $control_vop_dm +                 
                        $long_pass_vop_dm +              
                        $shot_acc_vop_dm +         
                        $heading_vop_dm +                  
                        $tackle_vop_dm +                                                                
                        $catching_vop_dm +               
                        $reflex_vop_dm +                   
                        $positioning_vop_dm +            
                        $creative_vop_dm +               
                        $determination_vop_dm +          
                        $reading_vop_dm;

                    $sum_am =
                        $speed_vop_am +                       
                        $balance_vop_am +                   
                        $strength_vop_am +                 
                        $durability_vop_am +              
                        $agility_vop_am +                                                       
                        $power_vop_am +                                                     
                        $stamina_vop_am +                                                     
                        $jumping_vop_am +                                                         
                        $pass_vop_am +                      
                        $control_vop_am +                 
                        $long_pass_vop_am +              
                        $shot_acc_vop_am +         
                        $heading_vop_am +                  
                        $tackle_vop_am +                                                                
                        $catching_vop_am +               
                        $reflex_vop_am +                   
                        $positioning_vop_am +            
                        $creative_vop_am +               
                        $determination_vop_am +          
                        $reading_vop_am;

                    $sum_wing =
                        $speed_vop_wing +                       
                        $balance_vop_wing +                   
                        $strength_vop_wing +                 
                        $durability_vop_wing +              
                        $agility_vop_wing +                                                       
                        $power_vop_wing +                                                     
                        $stamina_vop_wing +                                                     
                        $jumping_vop_wing +                                                         
                        $pass_vop_wing +                      
                        $control_vop_wing +                 
                        $long_pass_vop_wing +              
                        $shot_acc_vop_wing +         
                        $heading_vop_wing +                  
                        $tackle_vop_wing +                                                                
                        $catching_vop_wing +               
                        $reflex_vop_wing +                   
                        $positioning_vop_wing +            
                        $creative_vop_wing +               
                        $determination_vop_wing +          
                        $reading_vop_wing;

                    $sum_st =
                        $speed_vop_st +                       
                        $balance_vop_st +                   
                        $strength_vop_st +                 
                        $durability_vop_st +              
                        $agility_vop_st +                                                       
                        $power_vop_st +                                                     
                        $stamina_vop_st +                                                     
                        $jumping_vop_st +                                                         
                        $pass_vop_st +                      
                        $control_vop_st +                 
                        $long_pass_vop_st +              
                        $shot_acc_vop_st +         
                        $heading_vop_st +                  
                        $tackle_vop_st +                                                                
                        $catching_vop_st +               
                        $reflex_vop_st +                   
                        $positioning_vop_st +            
                        $creative_vop_st +               
                        $determination_vop_st +          
                        $reading_vop_st;

                    $result = array (
                      array('Goalkeeper',$sum_gk),
                      array('Defender',$sum_def),
                      array('Def. Midfield',$sum_dm),
                      array('Att. Midfield',$sum_am),
                      array('Winger',$sum_wing),
                      array('Striker',$sum_st)                      
                    );

                    usort($result, function($a, $b) {
                        return $b[1] <=> $a[1];
                    });

                    return new Compendium([
                        $result[0][0]            => $result[0][1],
                        $result[1][0]            => $result[1][1],
                        $result[2][0]            => $result[2][1],
                        $result[3][0]            => $result[3][1],
                        $result[4][0]            => $result[4][1],
                        $result[5][0]            => $result[5][1]                      
                    ]);

                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-end' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Result';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {

                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];           

                    $name = Players::findOrFail($id)->presenter()->name();

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    $max = max(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        );                                        

                    $min = min(
                        $speed,
                        $balance,
                        $strength,
                        $durability,
                        $agility,                  
                        $power,                
                        $stamina,                  
                        $jumping,                   
                        $pass,
                        $control,
                        $long_pass,
                        $shot_acc,
                        $heading,
                        $tackle,                        
                        $catching,
                        $reflex,
                        $positioning,
                        $creative,
                        $determination,
                        $reading,                       
                        ); 

                    $speed_norm             = ($speed-$min)/($max-$min); 
                    $balance_norm           = ($balance-$min)/($max-$min); 
                    $strength_norm          = ($strength-$min)/($max-$min); 
                    $durability_norm        = ($durability-$min)/($max-$min); 
                    $agility_norm           = ($agility-$min)/($max-$min);                   
                    $power_norm             = ($power-$min)/($max-$min);                 
                    $stamina_norm           = ($stamina-$min)/($max-$min);                   
                    $jumping_norm           = ($jumping-$min)/($max-$min);                    
                    $pass_norm              = ($pass-$min)/($max-$min); 
                    $control_norm           = ($control-$min)/($max-$min); 
                    $long_pass_norm         = ($long_pass-$min)/($max-$min); 
                    $shot_acc_norm          = ($shot_acc-$min)/($max-$min); 
                    $heading_norm           = ($heading-$min)/($max-$min); 
                    $tackle_norm            = ($tackle-$min)/($max-$min);                         
                    $catching_norm          = ($catching-$min)/($max-$min); 
                    $reflex_norm            = ($reflex-$min)/($max-$min); 
                    $positioning_norm       = ($positioning-$min)/($max-$min); 
                    $creative_norm          = ($creative-$min)/($max-$min); 
                    $determination_norm     = ($determination-$min)/($max-$min); 
                    $reading_norm           = ($reading-$min)/($max-$min);

                    $weight_speed_gk             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_speed();       
                    $weight_balance_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_balance();      
                    $weight_strength_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_strength();        
                    $weight_durability_gk        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_durability();      
                    $weight_agility_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_agility();      
                    $weight_power_gk             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_power();          
                    $weight_stamina_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_stamina();         
                    $weight_jumping_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_jumping();      
                    $weight_pass_gk              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_pass();           
                    $weight_control_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_control();        
                    $weight_long_pass_gk         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_long_pass();    
                    $weight_acc_gk               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_shot_acc();            
                    $weight_heading_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_heading();      
                    $weight_tackle_gk            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_tackle();         
                    $weight_catching_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_catching();     
                    $weight_reflex_gk            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_reflex();       
                    $weight_positioning_gk       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_positioning();                       
                    $weight_creative_gk          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_creative();       
                    $weight_determination_gk     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_determination();                        
                    $weight_reading_gk           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->gk_reading();        

                    $speed_vop_gk              = $speed_norm            * $weight_speed_gk;                    
                    $balance_vop_gk            = $balance_norm          * $weight_balance_gk;                
                    $strength_vop_gk           = $strength_norm         * $weight_strength_gk;              
                    $durability_vop_gk         = $durability_norm       * $weight_durability_gk;           
                    $agility_vop_gk            = $agility_norm          * $weight_agility_gk;                                                    
                    $power_vop_gk              = $power_norm            * $weight_power_gk;                                                  
                    $stamina_vop_gk            = $stamina_norm          * $weight_stamina_gk;                                                  
                    $jumping_vop_gk            = $jumping_norm          * $weight_jumping_gk;                                                      
                    $pass_vop_gk               = $pass_norm             * $weight_pass_gk;                   
                    $control_vop_gk            = $control_norm          * $weight_control_gk;              
                    $long_pass_vop_gk          = $long_pass_norm        * $weight_long_pass_gk;           
                    $shot_acc_vop_gk           = $shot_acc_norm         * $weight_acc_gk;           
                    $heading_vop_gk            = $heading_norm          * $weight_heading_gk;               
                    $tackle_vop_gk             = $tackle_norm           * $weight_tackle_gk;                                                             
                    $catching_vop_gk           = $catching_norm         * $weight_catching_gk;            
                    $reflex_vop_gk             = $reflex_norm           * $weight_reflex_gk;                
                    $positioning_vop_gk        = $positioning_norm      * $weight_positioning_gk;         
                    $creative_vop_gk           = $creative_norm         * $weight_creative_gk;            
                    $determination_vop_gk      = $determination_norm    * $weight_determination_gk;       
                    $reading_vop_gk            = $reading_norm          * $weight_reading_gk; 

                    $weight_speed_def             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_speed();       
                    $weight_balance_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_balance();      
                    $weight_strength_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_strength();        
                    $weight_durability_def        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_durability();      
                    $weight_agility_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_agility();      
                    $weight_power_def             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_power();          
                    $weight_stamina_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_stamina();         
                    $weight_jumping_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_jumping();      
                    $weight_pass_def              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_pass();           
                    $weight_control_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_control();        
                    $weight_long_pass_def         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_long_pass();    
                    $weight_acc_def               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_shot_acc();            
                    $weight_heading_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_heading();      
                    $weight_tackle_def            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_tackle();         
                    $weight_catching_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_catching();     
                    $weight_reflex_def            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_reflex();       
                    $weight_positioning_def       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_positioning();                       
                    $weight_creative_def          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_creative();       
                    $weight_determination_def     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_determination();                        
                    $weight_reading_def           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->def_reading();     

                    $speed_vop_def              = $speed_norm            * $weight_speed_def;                    
                    $balance_vop_def            = $balance_norm          * $weight_balance_def;                
                    $strength_vop_def           = $strength_norm         * $weight_strength_def;              
                    $durability_vop_def         = $durability_norm       * $weight_durability_def;           
                    $agility_vop_def            = $agility_norm          * $weight_agility_def;                                                    
                    $power_vop_def              = $power_norm            * $weight_power_def;                                                  
                    $stamina_vop_def            = $stamina_norm          * $weight_stamina_def;                                                  
                    $jumping_vop_def            = $jumping_norm          * $weight_jumping_def;                                                      
                    $pass_vop_def               = $pass_norm             * $weight_pass_def;                   
                    $control_vop_def            = $control_norm          * $weight_control_def;              
                    $long_pass_vop_def          = $long_pass_norm        * $weight_long_pass_def;           
                    $shot_acc_vop_def           = $shot_acc_norm         * $weight_acc_def;           
                    $heading_vop_def            = $heading_norm          * $weight_heading_def;               
                    $tackle_vop_def             = $tackle_norm           * $weight_tackle_def;                                                             
                    $catching_vop_def           = $catching_norm         * $weight_catching_def;            
                    $reflex_vop_def             = $reflex_norm           * $weight_reflex_def;                
                    $positioning_vop_def        = $positioning_norm      * $weight_positioning_def;         
                    $creative_vop_def           = $creative_norm         * $weight_creative_def;            
                    $determination_vop_def      = $determination_norm    * $weight_determination_def;       
                    $reading_vop_def            = $reading_norm          * $weight_reading_def;             

                    $weight_speed_dm             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_speed();       
                    $weight_balance_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_balance();      
                    $weight_strength_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_strength();        
                    $weight_durability_dm        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_durability();      
                    $weight_agility_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_agility();      
                    $weight_power_dm             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_power();          
                    $weight_stamina_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_stamina();         
                    $weight_jumping_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_jumping();      
                    $weight_pass_dm              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_pass();           
                    $weight_control_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_control();        
                    $weight_long_pass_dm         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_long_pass();    
                    $weight_acc_dm               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_shot_acc();            
                    $weight_heading_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_heading();      
                    $weight_tackle_dm            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_tackle();         
                    $weight_catching_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_catching();     
                    $weight_reflex_dm            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_reflex();       
                    $weight_positioning_dm       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_positioning();                       
                    $weight_creative_dm          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_creative();       
                    $weight_determination_dm     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_determination();                        
                    $weight_reading_dm           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->dm_reading();     

                    $speed_vop_dm              = $speed_norm            * $weight_speed_dm;                    
                    $balance_vop_dm            = $balance_norm          * $weight_balance_dm;                
                    $strength_vop_dm           = $strength_norm         * $weight_strength_dm;              
                    $durability_vop_dm         = $durability_norm       * $weight_durability_dm;           
                    $agility_vop_dm            = $agility_norm          * $weight_agility_dm;                                                    
                    $power_vop_dm              = $power_norm            * $weight_power_dm;                                                  
                    $stamina_vop_dm            = $stamina_norm          * $weight_stamina_dm;                                                  
                    $jumping_vop_dm            = $jumping_norm          * $weight_jumping_dm;                                                      
                    $pass_vop_dm               = $pass_norm             * $weight_pass_dm;                   
                    $control_vop_dm            = $control_norm          * $weight_control_dm;              
                    $long_pass_vop_dm          = $long_pass_norm        * $weight_long_pass_dm;           
                    $shot_acc_vop_dm           = $shot_acc_norm         * $weight_acc_dm;           
                    $heading_vop_dm            = $heading_norm          * $weight_heading_dm;               
                    $tackle_vop_dm             = $tackle_norm           * $weight_tackle_dm;                                                             
                    $catching_vop_dm           = $catching_norm         * $weight_catching_dm;            
                    $reflex_vop_dm             = $reflex_norm           * $weight_reflex_dm;                
                    $positioning_vop_dm        = $positioning_norm      * $weight_positioning_dm;         
                    $creative_vop_dm           = $creative_norm         * $weight_creative_dm;            
                    $determination_vop_dm      = $determination_norm    * $weight_determination_dm;       
                    $reading_vop_dm            = $reading_norm          * $weight_reading_dm;             

                    $weight_speed_am             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_speed();       
                    $weight_balance_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_balance();      
                    $weight_strength_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_strength();        
                    $weight_durability_am        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_durability();      
                    $weight_agility_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_agility();      
                    $weight_power_am             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_power();          
                    $weight_stamina_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_stamina();         
                    $weight_jumping_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_jumping();      
                    $weight_pass_am              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_pass();           
                    $weight_control_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_control();        
                    $weight_long_pass_am         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_long_pass();    
                    $weight_acc_am               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_shot_acc();            
                    $weight_heading_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_heading();      
                    $weight_tackle_am            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_tackle();         
                    $weight_catching_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_catching();     
                    $weight_reflex_am            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_reflex();       
                    $weight_positioning_am       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_positioning();                       
                    $weight_creative_am          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_creative();       
                    $weight_determination_am     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_determination();                        
                    $weight_reading_am           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->am_reading();     

                    $speed_vop_am              = $speed_norm            * $weight_speed_am;                    
                    $balance_vop_am            = $balance_norm          * $weight_balance_am;                
                    $strength_vop_am           = $strength_norm         * $weight_strength_am;              
                    $durability_vop_am         = $durability_norm       * $weight_durability_am;           
                    $agility_vop_am            = $agility_norm          * $weight_agility_am;                                                    
                    $power_vop_am              = $power_norm            * $weight_power_am;                                                  
                    $stamina_vop_am            = $stamina_norm          * $weight_stamina_am;                                                  
                    $jumping_vop_am            = $jumping_norm          * $weight_jumping_am;                                                      
                    $pass_vop_am               = $pass_norm             * $weight_pass_am;                   
                    $control_vop_am            = $control_norm          * $weight_control_am;              
                    $long_pass_vop_am          = $long_pass_norm        * $weight_long_pass_am;           
                    $shot_acc_vop_am           = $shot_acc_norm         * $weight_acc_am;           
                    $heading_vop_am            = $heading_norm          * $weight_heading_am;               
                    $tackle_vop_am             = $tackle_norm           * $weight_tackle_am;                                                             
                    $catching_vop_am           = $catching_norm         * $weight_catching_am;            
                    $reflex_vop_am             = $reflex_norm           * $weight_reflex_am;                
                    $positioning_vop_am        = $positioning_norm      * $weight_positioning_am;         
                    $creative_vop_am           = $creative_norm         * $weight_creative_am;            
                    $determination_vop_am      = $determination_norm    * $weight_determination_am;       
                    $reading_vop_am            = $reading_norm          * $weight_reading_am;

                    $weight_speed_wing             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_speed();       
                    $weight_balance_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_balance();      
                    $weight_strength_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_strength();        
                    $weight_durability_wing        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_durability();      
                    $weight_agility_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_agility();      
                    $weight_power_wing             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_power();          
                    $weight_stamina_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_stamina();         
                    $weight_jumping_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_jumping();      
                    $weight_pass_wing              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_pass();           
                    $weight_control_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_control();        
                    $weight_long_pass_wing         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_long_pass();    
                    $weight_acc_wing               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_shot_acc();            
                    $weight_heading_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_heading();      
                    $weight_tackle_wing            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_tackle();         
                    $weight_catching_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_catching();     
                    $weight_reflex_wing            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_reflex();       
                    $weight_positioning_wing       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_positioning();                       
                    $weight_creative_wing          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_creative();       
                    $weight_determination_wing     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_determination();                        
                    $weight_reading_wing           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->wing_reading();     

                    $speed_vop_wing              = $speed_norm            * $weight_speed_wing;                    
                    $balance_vop_wing            = $balance_norm          * $weight_balance_wing;                
                    $strength_vop_wing           = $strength_norm         * $weight_strength_wing;              
                    $durability_vop_wing         = $durability_norm       * $weight_durability_wing;           
                    $agility_vop_wing            = $agility_norm          * $weight_agility_wing;                                                    
                    $power_vop_wing              = $power_norm            * $weight_power_wing;                                                  
                    $stamina_vop_wing            = $stamina_norm          * $weight_stamina_wing;                                                  
                    $jumping_vop_wing            = $jumping_norm          * $weight_jumping_wing;                                                      
                    $pass_vop_wing               = $pass_norm             * $weight_pass_wing;                   
                    $control_vop_wing            = $control_norm          * $weight_control_wing;              
                    $long_pass_vop_wing          = $long_pass_norm        * $weight_long_pass_wing;           
                    $shot_acc_vop_wing           = $shot_acc_norm         * $weight_acc_wing;           
                    $heading_vop_wing            = $heading_norm          * $weight_heading_wing;               
                    $tackle_vop_wing             = $tackle_norm           * $weight_tackle_wing;                                                             
                    $catching_vop_wing           = $catching_norm         * $weight_catching_wing;            
                    $reflex_vop_wing             = $reflex_norm           * $weight_reflex_wing;                
                    $positioning_vop_wing        = $positioning_norm      * $weight_positioning_wing;         
                    $creative_vop_wing           = $creative_norm         * $weight_creative_wing;            
                    $determination_vop_wing      = $determination_norm    * $weight_determination_wing;       
                    $reading_vop_wing            = $reading_norm          * $weight_reading_wing;

                    $weight_speed_st             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_speed();       
                    $weight_balance_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_balance();      
                    $weight_strength_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_strength();        
                    $weight_durability_st        = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_durability();      
                    $weight_agility_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_agility();      
                    $weight_power_st             = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_power();          
                    $weight_stamina_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_stamina();         
                    $weight_jumping_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_jumping();      
                    $weight_pass_st              = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_pass();           
                    $weight_control_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_control();        
                    $weight_long_pass_st         = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_long_pass();    
                    $weight_acc_st               = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_shot_acc();            
                    $weight_heading_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_heading();      
                    $weight_tackle_st            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_tackle();         
                    $weight_catching_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_catching();     
                    $weight_reflex_st            = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_reflex();       
                    $weight_positioning_st       = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_positioning();                       
                    $weight_creative_st          = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_creative();       
                    $weight_determination_st     = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_determination();                        
                    $weight_reading_st           = dssWeight::where('userPref_id', auth()->id())->firstOrFail()->presenter()->st_reading();     

                    $speed_vop_st              = $speed_norm            * $weight_speed_st;                    
                    $balance_vop_st            = $balance_norm          * $weight_balance_st;                
                    $strength_vop_st           = $strength_norm         * $weight_strength_st;              
                    $durability_vop_st         = $durability_norm       * $weight_durability_st;           
                    $agility_vop_st            = $agility_norm          * $weight_agility_st;                                                    
                    $power_vop_st              = $power_norm            * $weight_power_st;                                                  
                    $stamina_vop_st            = $stamina_norm          * $weight_stamina_st;                                                  
                    $jumping_vop_st            = $jumping_norm          * $weight_jumping_st;                                                      
                    $pass_vop_st               = $pass_norm             * $weight_pass_st;                   
                    $control_vop_st            = $control_norm          * $weight_control_st;              
                    $long_pass_vop_st          = $long_pass_norm        * $weight_long_pass_st;           
                    $shot_acc_vop_st           = $shot_acc_norm         * $weight_acc_st;           
                    $heading_vop_st            = $heading_norm          * $weight_heading_st;               
                    $tackle_vop_st             = $tackle_norm           * $weight_tackle_st;                                                             
                    $catching_vop_st           = $catching_norm         * $weight_catching_st;            
                    $reflex_vop_st             = $reflex_norm           * $weight_reflex_st;                
                    $positioning_vop_st        = $positioning_norm      * $weight_positioning_st;         
                    $creative_vop_st           = $creative_norm         * $weight_creative_st;            
                    $determination_vop_st      = $determination_norm    * $weight_determination_st;       
                    $reading_vop_st            = $reading_norm          * $weight_reading_st;             

                    $sum_gk =
                        $speed_vop_gk +                       
                        $balance_vop_gk +                   
                        $strength_vop_gk +                 
                        $durability_vop_gk +              
                        $agility_vop_gk +                                                       
                        $power_vop_gk +                                                     
                        $stamina_vop_gk +                                                     
                        $jumping_vop_gk +                                                         
                        $pass_vop_gk +                      
                        $control_vop_gk +                 
                        $long_pass_vop_gk +              
                        $shot_acc_vop_gk +         
                        $heading_vop_gk +                  
                        $tackle_vop_gk +                                                                
                        $catching_vop_gk +               
                        $reflex_vop_gk +                   
                        $positioning_vop_gk +            
                        $creative_vop_gk +               
                        $determination_vop_gk +          
                        $reading_vop_gk;                          

                    $sum_def =
                        $speed_vop_def +                       
                        $balance_vop_def +                   
                        $strength_vop_def +                 
                        $durability_vop_def +              
                        $agility_vop_def +                                                       
                        $power_vop_def +                                                     
                        $stamina_vop_def +                                                     
                        $jumping_vop_def +                                                         
                        $pass_vop_def +                      
                        $control_vop_def +                 
                        $long_pass_vop_def +              
                        $shot_acc_vop_def +         
                        $heading_vop_def +                  
                        $tackle_vop_def +                                                                
                        $catching_vop_def +               
                        $reflex_vop_def +                   
                        $positioning_vop_def +            
                        $creative_vop_def +               
                        $determination_vop_def +          
                        $reading_vop_def;

                    $sum_dm =
                        $speed_vop_dm +                       
                        $balance_vop_dm +                   
                        $strength_vop_dm +                 
                        $durability_vop_dm +              
                        $agility_vop_dm +                                                       
                        $power_vop_dm +                                                     
                        $stamina_vop_dm +                                                     
                        $jumping_vop_dm +                                                         
                        $pass_vop_dm +                      
                        $control_vop_dm +                 
                        $long_pass_vop_dm +              
                        $shot_acc_vop_dm +         
                        $heading_vop_dm +                  
                        $tackle_vop_dm +                                                                
                        $catching_vop_dm +               
                        $reflex_vop_dm +                   
                        $positioning_vop_dm +            
                        $creative_vop_dm +               
                        $determination_vop_dm +          
                        $reading_vop_dm;

                    $sum_am =
                        $speed_vop_am +                       
                        $balance_vop_am +                   
                        $strength_vop_am +                 
                        $durability_vop_am +              
                        $agility_vop_am +                                                       
                        $power_vop_am +                                                     
                        $stamina_vop_am +                                                     
                        $jumping_vop_am +                                                         
                        $pass_vop_am +                      
                        $control_vop_am +                 
                        $long_pass_vop_am +              
                        $shot_acc_vop_am +         
                        $heading_vop_am +                  
                        $tackle_vop_am +                                                                
                        $catching_vop_am +               
                        $reflex_vop_am +                   
                        $positioning_vop_am +            
                        $creative_vop_am +               
                        $determination_vop_am +          
                        $reading_vop_am;

                    $sum_wing =
                        $speed_vop_wing +                       
                        $balance_vop_wing +                   
                        $strength_vop_wing +                 
                        $durability_vop_wing +              
                        $agility_vop_wing +                                                       
                        $power_vop_wing +                                                     
                        $stamina_vop_wing +                                                     
                        $jumping_vop_wing +                                                         
                        $pass_vop_wing +                      
                        $control_vop_wing +                 
                        $long_pass_vop_wing +              
                        $shot_acc_vop_wing +         
                        $heading_vop_wing +                  
                        $tackle_vop_wing +                                                                
                        $catching_vop_wing +               
                        $reflex_vop_wing +                   
                        $positioning_vop_wing +            
                        $creative_vop_wing +               
                        $determination_vop_wing +          
                        $reading_vop_wing;

                    $sum_st =
                        $speed_vop_st +                       
                        $balance_vop_st +                   
                        $strength_vop_st +                 
                        $durability_vop_st +              
                        $agility_vop_st +                                                       
                        $power_vop_st +                                                     
                        $stamina_vop_st +                                                     
                        $jumping_vop_st +                                                         
                        $pass_vop_st +                      
                        $control_vop_st +                 
                        $long_pass_vop_st +              
                        $shot_acc_vop_st +         
                        $heading_vop_st +                  
                        $tackle_vop_st +                                                                
                        $catching_vop_st +               
                        $reflex_vop_st +                   
                        $positioning_vop_st +            
                        $creative_vop_st +               
                        $determination_vop_st +          
                        $reading_vop_st;

                    $result = array (
                      array('Goalkeeper',$sum_gk),
                      array('Defender',$sum_def),
                      array('Def. Midfield',$sum_dm),
                      array('Att. Midfield',$sum_am),
                      array('Winger',$sum_wing),
                      array('Striker',$sum_st)                      
                    );

                    usort($result, function($a, $b) {
                        return $b[1] <=> $a[1];
                    });

                    return 'According to custom weights, the best position for ' . $name . ' is ' . $result[0][0] . '.';

                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            Layout::columns([
                new Card('card-attribute', [
                ]), 
                new Card('card-normalized', [
                ]),                         
            ]), 
            Layout::tabs([
                'Goalkeeper' => Layout::columns([
                            new Card('card-gk', [
                            ]),                                                                
                        ]),                                                                
                'Defender' => Layout::columns([
                            new Card('card-def', [
                            ]),                                                                
                        ]),
                'Def. Midfield' => Layout::columns([
                            new Card('card-dm', [
                            ]),                                                                
                        ]),                                                                
                'Att. Midfield' => Layout::columns([
                            new Card('card-am', [
                            ]),                                                                
                        ]),
                'Winger' => Layout::columns([
                            new Card('card-wing', [
                            ]),                                                                
                        ]),                                                                
                'Striker' => Layout::columns([
                            new Card('card-st', [
                            ]),                                                                
                        ]),
            ]),
            Layout::columns([
                new Card('card-total', [
                ]), 
                new Card('card-end', [
                ]),                         
            ]),
        ];
    }
}
