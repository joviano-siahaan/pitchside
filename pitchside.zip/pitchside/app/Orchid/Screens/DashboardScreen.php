<?php

namespace App\Orchid\Screens;

use App\Orchid\Layouts\Examples\ChartBarExample;
use App\Orchid\Layouts\Examples\MetricsExample;
use App\Orchid\Layouts\Chart\barChartDashboard;
use App\Orchid\Layouts\Chart\barChartDashboard2;
use App\Orchid\Layouts\Players\PlayersListLayout;
use App\Orchid\Layouts\FixturesListLayout;
use App\Orchid\Layouts\OpponentsListLayout;
use App\Models\Players;
use App\Models\Fixtures;
use App\Models\playerStats;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Orchid\Screen\Actions\Button;
use Orchid\Screen\Actions\DropDown;
use Orchid\Screen\Actions\ModalToggle;
use Orchid\Screen\Fields\Input;
use Orchid\Screen\Repository;
use Orchid\Screen\Screen;
use Orchid\Screen\TD;
use Orchid\Support\Facades\Layout;
use Orchid\Support\Facades\Toast;
use App\View\Components\TableTitle;
use App\View\Components\TableTitle2;
use Illuminate\Support\Facades\DB;

class DashboardScreen extends Screen
{
    /**
     * Fish text for the table.
     */
    public const TEXT_EXAMPLE = 'Lorem ipsum at sed ad fusce faucibus primis, potenti inceptos ad taciti nisi tristique
    urna etiam, primis ut lacus habitasse malesuada ut. Lectus aptent malesuada mattis ut etiam fusce nec sed viverra,
    semper mattis viverra malesuada quam metus vulputate torquent magna, lobortis nec nostra nibh sollicitudin
    erat in luctus.';

    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Dashboard';

    /**
     * Display header description.
     *
     * @var string
     */
    public $description = '';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(): array
    {
        return [
            'charts'  => [
                [
                    'name'   => 'Some Data',
                    'values' => [25, 40, 30, 35, 8, 52, 17],
                    'labels' => ['12am-3am', '3am-6am', '6am-9am', '9am-12pm', '12pm-3pm', '3pm-6pm', '6pm-9pm'],
                ],
            ],

           'dashboard_chart' => Players::GetGoals('players.name',
                                                        'player_stats',
                                                        'players.id',
                                                        'player_stats.player_id',
                                                        'players.name',
                                                        'players.user_id')->toChart(),

           'dashboard_chart2' => Players::GetAssist('players.name',
                                                        'player_stats',
                                                        'players.id',
                                                        'player_stats.player_id',
                                                        'players.name',
                                                        'players.user_id')->toChart(),

            'metrics' => [
                ['keyValue' => DB::table('players')->where('user_id', auth()->id())->count()],
                ['keyValue' => DB::table('fixtures')->where('user_id', auth()->id())->count()],
                ['keyValue' => DB::table('opponents')->where('user_id', auth()->id())->count()],
                ['keyValue' => DB::table('player_stats')->where('user_id', auth()->id())->count()],
            ],
            'players' => Players::paginate(),
            'fixtures' => Fixtures::paginate(),
            'table_name' => 'Players',
            'table_name2' => 'Fixtures',
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [];
    }

    /**
     * Views.
     *
     * @return string[]|\Orchid\Screen\Layout[]
     */
    public function layout(): array
    {
        return [
            MetricsExample::class,
            barChartDashboard::class,
            barChartDashboard2::class,
            Layout::component(TableTitle::class),
            PlayersListLayout::class,
            Layout::component(TableTitle2::class),
            FixturesListLayout::class,
        ];
    }
}
