<?php

namespace App\Orchid\Screens;

use App\Models\Players;
use App\Models\User;
use App\Models\dssWeight;
use App\Models\AttPhysical;
use App\Models\AttTechnical;
use App\Models\AttTactical;
use Orchid\Screen\Screen;
use Illuminate\Http\Request;
use Orchid\Screen\Layouts\Card;
use Orchid\Screen\Contracts\Cardable;
use Orchid\Support\Facades\Layout;
use Orchid\Support\Color;
use Orchid\Screen\Layouts\Compendium;
use Orchid\Screen\Actions\Button;
use Illuminate\Support\Facades\Storage;
use Orchid\Screen\Actions\Link;
use Orchid\Support\Facades\Alert;
use Orchid\Screen\Fields\Group;
use Illuminate\Database\Eloquent\Model;
use App\Orchid\Layouts\Chart\barPhysicalChart;
use App\Orchid\Layouts\Chart\barTechnicalChart;
use App\Orchid\Layouts\Chart\barTacticalChart;
use Illuminate\Support\Facades\DB;

class PlayersViewScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Players';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = 'PlayersViewScreen';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(Players $players, dssWeight $dssWeight): array
    {

        return [

            'players' => $players,
            'dssWeight' => $dssWeight,
            $id = $players->id,

            $this->name = Players::findOrFail($id)->presenter()->header(),
            $this->description = Players::findOrFail($id)->presenter()->position(),

            'card' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Player Details';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $name = Players::findOrFail($id)->presenter()->name();
                    $position = Players::findOrFail($id)->presenter()->position();
                    $number = Players::findOrFail($id)->presenter()->number();
                    $dob = Players::findOrFail($id)->presenter()->dob();
                    $prefFoot = Players::findOrFail($id)->presenter()->prefFoot();
                    $weight = Players::findOrFail($id)->presenter()->weight();
                    $height = Players::findOrFail($id)->presenter()->height();

                    return new Compendium([
                        'Full Name'              => $name,
                        'Position'               => $position,
                        'Shirt Number'           => $number,
                        'Date of Birth'          => $dob,
                        'Pref. Foot'             => $prefFoot,
                        'Weight'                 => $weight,
                        'Height'                 => $height,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $img = Players::findOrFail($id)->presenter()->img();

                    return $img;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-physical' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Physical';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $speed = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed();
                    $balance = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance();
                    $strength = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength();
                    $durability = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability();
                    $agility = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility();
                    $power = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power();
                    $stamina = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina();
                    $jumping = AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping();

                    return new Compendium([
                        'Speed'              => $speed,
                        'Balance'            => $balance,
                        'Strength'           => $strength,
                        'Durability'         => $durability,
                        'Agility'            => $agility,
                        'Power'              => $power,
                        'Stamina'            => $stamina,
                        'Jumping'            => $jumping,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-technical' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Technical';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass();
                    $control = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control();
                    $long_pass = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass();
                    $shot_acc = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc();
                    $heading = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading();
                    $tackle = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle();
                    $catching = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching();
                    $reflex = AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex();

                    return new Compendium([
                        'Passing'               => $pass,
                        'Control'               => $control,
                        'Long Passing'          => $long_pass,
                        'Shot Acc.'             => $shot_acc,
                        'Heading'               => $heading,
                        'Power'                 => $tackle,
                        'Catching'              => $catching,
                        'Reflex'                => $reflex,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-tactical' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Tactical';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    return new Compendium([
                        'Positioning'               => $positioning,
                        'Creative'                  => $creative,
                        'Determination'             => $determination,
                        'Reading the Game'          => $reading,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-general' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'General';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $positioning = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning();
                    $creative = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative();
                    $determination = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination();
                    $reading = AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading();

                    return new Compendium([
                        'Positioning'               => $positioning,
                        'Creative'                  => $creative,
                        'Determination'             => $determination,
                        'Reading the Game'          => $reading,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'physical-charts' => [
                [
                    'name'   => 'Physical',
                    'values' => [   
                                    AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->speed(),
                                    AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->balance(),
                                    AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->strength(),
                                    AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->durability(),
                                    AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->agility(),
                                    AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->power(),
                                    AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->stamina(),
                                    AttPhysical::where('players_id', $id)->firstOrFail()->presenter()->jumping(),
                                ],
                    'labels' => ['Speed', 'Balance', 'Strength', 'Durability', 'Agility', 'Power', 'Stamina', 'Jumping'],
                ],
            ],

            'technical-charts' => [
                [
                    'name'   => 'Technical',
                    'values' => [   
                                    AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->pass(),
                                    AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->control(),
                                    AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->long_pass(),
                                    AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->shot_acc(),
                                    AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->heading(),
                                    AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->tackle(),
                                    AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->catching(),
                                    AttTechnical::where('players_id', $id)->firstOrFail()->presenter()->reflex(),
                                ],
                    'labels' => ['Pass', 'Control', 'Long Pass', 'Shot Acc.', 'Heading', 'tackle', 'Catching', 'Reflex'],
                ],
            ],

            'tactical-charts' => [
                [
                    'name'   => 'Tactical',
                    'values' => [   
                                    AttTactical::where('players_id', $id)->firstOrFail()->presenter()->positioning(),
                                    AttTactical::where('players_id', $id)->firstOrFail()->presenter()->creative(),
                                    AttTactical::where('players_id', $id)->firstOrFail()->presenter()->determination(),
                                    AttTactical::where('players_id', $id)->firstOrFail()->presenter()->reading(),
                                ],
                    'labels' => ['Positioning', 'Creative', 'Determination', 'Reading the Game'],
                ],
            ],

            'card-stats-general' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'General';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $query = DB::table('players')
                                ->leftJoin('player_stats','player_stats.player_id','=','players.id')
                                ->select('players.name', 
                                    DB::raw('SUM(player_stats.min_played) as min_played'), 
                                    DB::raw('SUM(player_stats.goals) as goals'), 
                                    DB::raw('SUM(player_stats.assist) as assist'), 
                                    DB::raw('SUM(player_stats.goals_conceded) as goals_conceded'), 
                                    DB::raw('SUM(player_stats.own_goals) as own_goals'), 
                                    DB::raw('SUM(player_stats.yellow_c) as yellow_c'), 
                                    DB::raw('SUM(player_stats.red_c) as red_c'), 
                                    DB::raw('SUM(player_stats.touches_t) as touches_t'), 
                                    DB::raw('SUM(player_stats.touches_opp_half) as touches_opp_half'), 
                                    DB::raw('SUM(player_stats.touches_f3) as touches_f3'), 
                                    DB::raw('SUM(player_stats.min_touches) as min_touches'), 
                                    DB::raw('SUM(player_stats.pass_received_t) as pass_received_t'), 
                                    DB::raw('SUM(player_stats.pass_received_opp_half) as pass_received_opp_half'), 
                                    DB::raw('SUM(player_stats.pass_received_f3) as pass_received_f3'), 
                                    DB::raw('SUM(player_stats.min_pass_received) as min_pass_received'), 
                                    DB::raw('SUM(player_stats.take_ons_t) as take_ons_t'), 
                                    DB::raw('SUM(player_stats.take_ons_s) as take_ons_s'), 
                                    DB::raw('SUM(player_stats.take_ons_s_p) as take_ons_s_p'), 
                                    DB::raw('SUM(player_stats.pass_t) as pass_t'), 
                                    DB::raw('SUM(player_stats.pass_s) as pass_s'), 
                                    DB::raw('SUM(player_stats.pass_s_p) as pass_s_p'), 
                                    DB::raw('SUM(player_stats.chance_created) as chance_created'), 
                                    DB::raw('SUM(player_stats.big_chance_created) as big_chance_created'), 
                                    DB::raw('SUM(player_stats.min_chance_created) as min_chance_created'), 
                                    DB::raw('SUM(player_stats.goals_threat) as goals_threat'), 
                                    DB::raw('SUM(player_stats.min_goals) as min_goals'), 
                                    DB::raw('SUM(player_stats.attempts_t) as attempts_t'), 
                                    DB::raw('SUM(player_stats.attempts_on_target) as attempts_on_target'), 
                                    DB::raw('SUM(player_stats.min_attempts) as min_attempts'), 
                                    DB::raw('SUM(player_stats.shot_acc) as shot_acc'), 
                                    DB::raw('SUM(player_stats.goal_conversion) as goal_conversion'), 
                                    DB::raw('SUM(player_stats.aerial_t) as aerial_t'), 
                                    DB::raw('SUM(player_stats.aerial_w) as aerial_w'), 
                                    DB::raw('SUM(player_stats.aerial_w_p) as aerial_w_p'), 
                                    DB::raw('SUM(player_stats.tackles_t) as tackles_t'), 
                                    DB::raw('SUM(player_stats.tackles_w) as tackles_w'), 
                                    DB::raw('SUM(player_stats.tackles_w_p) as tackles_w_p'), 
                                    DB::raw('SUM(player_stats.interceptions) as interceptions'), 
                                    DB::raw('SUM(player_stats.recoveries) as recoveries'), 
                                    DB::raw('SUM(player_stats.clearances) as clearances'), 
                                    DB::raw('SUM(player_stats.blocks) as blocks'), 
                                    DB::raw('SUM(player_stats.err_chance) as err_chance'), 
                                    DB::raw('SUM(player_stats.err_goals) as err_goals'))
                                ->groupBy('players.name')
                                ->where('players.id', '=', $id)
                                ->where('players.user_id', '=', auth()->id())
                                ->first();

                    return new Compendium([
                        'Minutes Played'              => $query->min_played,
                        'Goals'                       => $query->goals,
                        'Assist'                      => $query->assist,
                        'Goals Conceded'              => $query->goals_conceded,
                        'Own Goals'                   => $query->own_goals,
                        'Yellow Card'                 => $query->yellow_c,
                        'Red Card'                    => $query->red_c,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-stats-involvement' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Involvement';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $query = DB::table('players')
                                ->leftJoin('player_stats','player_stats.player_id','=','players.id')
                                ->select('players.name', 
                                    DB::raw('SUM(player_stats.min_played) as min_played'), 
                                    DB::raw('SUM(player_stats.goals) as goals'), 
                                    DB::raw('SUM(player_stats.assist) as assist'), 
                                    DB::raw('SUM(player_stats.goals_conceded) as goals_conceded'), 
                                    DB::raw('SUM(player_stats.own_goals) as own_goals'), 
                                    DB::raw('SUM(player_stats.yellow_c) as yellow_c'), 
                                    DB::raw('SUM(player_stats.red_c) as red_c'), 
                                    DB::raw('SUM(player_stats.touches_t) as touches_t'), 
                                    DB::raw('SUM(player_stats.touches_opp_half) as touches_opp_half'), 
                                    DB::raw('SUM(player_stats.touches_f3) as touches_f3'), 
                                    DB::raw('SUM(player_stats.min_touches) as min_touches'), 
                                    DB::raw('SUM(player_stats.pass_received_t) as pass_received_t'), 
                                    DB::raw('SUM(player_stats.pass_received_opp_half) as pass_received_opp_half'), 
                                    DB::raw('SUM(player_stats.pass_received_f3) as pass_received_f3'), 
                                    DB::raw('SUM(player_stats.min_pass_received) as min_pass_received'), 
                                    DB::raw('SUM(player_stats.take_ons_t) as take_ons_t'), 
                                    DB::raw('SUM(player_stats.take_ons_s) as take_ons_s'), 
                                    DB::raw('SUM(player_stats.take_ons_s_p) as take_ons_s_p'), 
                                    DB::raw('SUM(player_stats.pass_t) as pass_t'), 
                                    DB::raw('SUM(player_stats.pass_s) as pass_s'), 
                                    DB::raw('SUM(player_stats.pass_s_p) as pass_s_p'), 
                                    DB::raw('SUM(player_stats.chance_created) as chance_created'), 
                                    DB::raw('SUM(player_stats.big_chance_created) as big_chance_created'), 
                                    DB::raw('SUM(player_stats.min_chance_created) as min_chance_created'), 
                                    DB::raw('SUM(player_stats.goals_threat) as goals_threat'), 
                                    DB::raw('SUM(player_stats.min_goals) as min_goals'), 
                                    DB::raw('SUM(player_stats.attempts_t) as attempts_t'), 
                                    DB::raw('SUM(player_stats.attempts_on_target) as attempts_on_target'), 
                                    DB::raw('SUM(player_stats.min_attempts) as min_attempts'), 
                                    DB::raw('SUM(player_stats.shot_acc) as shot_acc'), 
                                    DB::raw('SUM(player_stats.goal_conversion) as goal_conversion'), 
                                    DB::raw('SUM(player_stats.aerial_t) as aerial_t'), 
                                    DB::raw('SUM(player_stats.aerial_w) as aerial_w'), 
                                    DB::raw('SUM(player_stats.aerial_w_p) as aerial_w_p'), 
                                    DB::raw('SUM(player_stats.tackles_t) as tackles_t'), 
                                    DB::raw('SUM(player_stats.tackles_w) as tackles_w'), 
                                    DB::raw('SUM(player_stats.tackles_w_p) as tackles_w_p'), 
                                    DB::raw('SUM(player_stats.interceptions) as interceptions'), 
                                    DB::raw('SUM(player_stats.recoveries) as recoveries'), 
                                    DB::raw('SUM(player_stats.clearances) as clearances'), 
                                    DB::raw('SUM(player_stats.blocks) as blocks'), 
                                    DB::raw('SUM(player_stats.err_chance) as err_chance'), 
                                    DB::raw('SUM(player_stats.err_goals) as err_goals'))
                                ->groupBy('players.name')
                                ->where('players.id', '=', $id)
                                ->where('players.user_id', '=', auth()->id())
                                ->first();

                    return new Compendium([
                        'Total Touches'                         => $query->touches_t,
                        'Touches in Opp. Half'                  => $query->touches_opp_half,
                        'Touches in Final Third'                => $query->touches_f3,
                        'Minutes/Touches'                       => $query->min_touches,
                        'Total Pass Received'                   => $query->pass_received_t,
                        'Pass Received in Opp. Half'            => $query->pass_received_opp_half,
                        'Pass Received in Final Third'          => $query->pass_received_f3,
                        'Minutes/Pass Received'                 => $query->min_pass_received,
                        'Total Take Ons'                        => $query->take_ons_t,
                        'Successful Take Ons'                   => $query->take_ons_s,
                        'Successful Take Ons %'                 => $query->take_ons_s_p,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-stats-distribution' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Distribution';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $query = DB::table('players')
                                ->leftJoin('player_stats','player_stats.player_id','=','players.id')
                                ->select('players.name', 
                                    DB::raw('SUM(player_stats.min_played) as min_played'), 
                                    DB::raw('SUM(player_stats.goals) as goals'), 
                                    DB::raw('SUM(player_stats.assist) as assist'), 
                                    DB::raw('SUM(player_stats.goals_conceded) as goals_conceded'), 
                                    DB::raw('SUM(player_stats.own_goals) as own_goals'), 
                                    DB::raw('SUM(player_stats.yellow_c) as yellow_c'), 
                                    DB::raw('SUM(player_stats.red_c) as red_c'), 
                                    DB::raw('SUM(player_stats.touches_t) as touches_t'), 
                                    DB::raw('SUM(player_stats.touches_opp_half) as touches_opp_half'), 
                                    DB::raw('SUM(player_stats.touches_f3) as touches_f3'), 
                                    DB::raw('SUM(player_stats.min_touches) as min_touches'), 
                                    DB::raw('SUM(player_stats.pass_received_t) as pass_received_t'), 
                                    DB::raw('SUM(player_stats.pass_received_opp_half) as pass_received_opp_half'), 
                                    DB::raw('SUM(player_stats.pass_received_f3) as pass_received_f3'), 
                                    DB::raw('SUM(player_stats.min_pass_received) as min_pass_received'), 
                                    DB::raw('SUM(player_stats.take_ons_t) as take_ons_t'), 
                                    DB::raw('SUM(player_stats.take_ons_s) as take_ons_s'), 
                                    DB::raw('SUM(player_stats.take_ons_s_p) as take_ons_s_p'), 
                                    DB::raw('SUM(player_stats.pass_t) as pass_t'), 
                                    DB::raw('SUM(player_stats.pass_s) as pass_s'), 
                                    DB::raw('SUM(player_stats.pass_s_p) as pass_s_p'), 
                                    DB::raw('SUM(player_stats.chance_created) as chance_created'), 
                                    DB::raw('SUM(player_stats.big_chance_created) as big_chance_created'), 
                                    DB::raw('SUM(player_stats.min_chance_created) as min_chance_created'), 
                                    DB::raw('SUM(player_stats.goals_threat) as goals_threat'), 
                                    DB::raw('SUM(player_stats.min_goals) as min_goals'), 
                                    DB::raw('SUM(player_stats.attempts_t) as attempts_t'), 
                                    DB::raw('SUM(player_stats.attempts_on_target) as attempts_on_target'), 
                                    DB::raw('SUM(player_stats.min_attempts) as min_attempts'), 
                                    DB::raw('SUM(player_stats.shot_acc) as shot_acc'), 
                                    DB::raw('SUM(player_stats.goal_conversion) as goal_conversion'), 
                                    DB::raw('SUM(player_stats.aerial_t) as aerial_t'), 
                                    DB::raw('SUM(player_stats.aerial_w) as aerial_w'), 
                                    DB::raw('SUM(player_stats.aerial_w_p) as aerial_w_p'), 
                                    DB::raw('SUM(player_stats.tackles_t) as tackles_t'), 
                                    DB::raw('SUM(player_stats.tackles_w) as tackles_w'), 
                                    DB::raw('SUM(player_stats.tackles_w_p) as tackles_w_p'), 
                                    DB::raw('SUM(player_stats.interceptions) as interceptions'), 
                                    DB::raw('SUM(player_stats.recoveries) as recoveries'), 
                                    DB::raw('SUM(player_stats.clearances) as clearances'), 
                                    DB::raw('SUM(player_stats.blocks) as blocks'), 
                                    DB::raw('SUM(player_stats.err_chance) as err_chance'), 
                                    DB::raw('SUM(player_stats.err_goals) as err_goals'))
                                ->groupBy('players.name')
                                ->where('players.id', '=', $id)
                                ->where('players.user_id', '=', auth()->id())
                                ->first();

                    return new Compendium([
                        'Total Passes'                          => $query->pass_t,
                        'Successful Passes'                     => $query->pass_s,
                        'Successful Passes %'                   => $query->pass_s_p,
                        'Chance Created'                        => $query->chance_created,
                        'Big Chance Created'                    => $query->big_chance_created,
                        'Minutes/Chance Created'                => $query->min_chance_created,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-stats-goal_threat' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Goal Threat';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $query = DB::table('players')
                                ->leftJoin('player_stats','player_stats.player_id','=','players.id')
                                ->select('players.name', 
                                    DB::raw('SUM(player_stats.min_played) as min_played'), 
                                    DB::raw('SUM(player_stats.goals) as goals'), 
                                    DB::raw('SUM(player_stats.assist) as assist'), 
                                    DB::raw('SUM(player_stats.goals_conceded) as goals_conceded'), 
                                    DB::raw('SUM(player_stats.own_goals) as own_goals'), 
                                    DB::raw('SUM(player_stats.yellow_c) as yellow_c'), 
                                    DB::raw('SUM(player_stats.red_c) as red_c'), 
                                    DB::raw('SUM(player_stats.touches_t) as touches_t'), 
                                    DB::raw('SUM(player_stats.touches_opp_half) as touches_opp_half'), 
                                    DB::raw('SUM(player_stats.touches_f3) as touches_f3'), 
                                    DB::raw('SUM(player_stats.min_touches) as min_touches'), 
                                    DB::raw('SUM(player_stats.pass_received_t) as pass_received_t'), 
                                    DB::raw('SUM(player_stats.pass_received_opp_half) as pass_received_opp_half'), 
                                    DB::raw('SUM(player_stats.pass_received_f3) as pass_received_f3'), 
                                    DB::raw('SUM(player_stats.min_pass_received) as min_pass_received'), 
                                    DB::raw('SUM(player_stats.take_ons_t) as take_ons_t'), 
                                    DB::raw('SUM(player_stats.take_ons_s) as take_ons_s'), 
                                    DB::raw('SUM(player_stats.take_ons_s_p) as take_ons_s_p'), 
                                    DB::raw('SUM(player_stats.pass_t) as pass_t'), 
                                    DB::raw('SUM(player_stats.pass_s) as pass_s'), 
                                    DB::raw('SUM(player_stats.pass_s_p) as pass_s_p'), 
                                    DB::raw('SUM(player_stats.chance_created) as chance_created'), 
                                    DB::raw('SUM(player_stats.big_chance_created) as big_chance_created'), 
                                    DB::raw('SUM(player_stats.min_chance_created) as min_chance_created'), 
                                    DB::raw('SUM(player_stats.goals_threat) as goals_threat'), 
                                    DB::raw('SUM(player_stats.min_goals) as min_goals'), 
                                    DB::raw('SUM(player_stats.attempts_t) as attempts_t'), 
                                    DB::raw('SUM(player_stats.attempts_on_target) as attempts_on_target'), 
                                    DB::raw('SUM(player_stats.min_attempts) as min_attempts'), 
                                    DB::raw('SUM(player_stats.shot_acc) as shot_acc'), 
                                    DB::raw('SUM(player_stats.goal_conversion) as goal_conversion'), 
                                    DB::raw('SUM(player_stats.aerial_t) as aerial_t'), 
                                    DB::raw('SUM(player_stats.aerial_w) as aerial_w'), 
                                    DB::raw('SUM(player_stats.aerial_w_p) as aerial_w_p'), 
                                    DB::raw('SUM(player_stats.tackles_t) as tackles_t'), 
                                    DB::raw('SUM(player_stats.tackles_w) as tackles_w'), 
                                    DB::raw('SUM(player_stats.tackles_w_p) as tackles_w_p'), 
                                    DB::raw('SUM(player_stats.interceptions) as interceptions'), 
                                    DB::raw('SUM(player_stats.recoveries) as recoveries'), 
                                    DB::raw('SUM(player_stats.clearances) as clearances'), 
                                    DB::raw('SUM(player_stats.blocks) as blocks'), 
                                    DB::raw('SUM(player_stats.err_chance) as err_chance'), 
                                    DB::raw('SUM(player_stats.err_goals) as err_goals'))
                                ->groupBy('players.name')
                                ->where('players.id', '=', $id)
                                ->where('players.user_id', '=', auth()->id())
                                ->first();

                    return new Compendium([
                        'Minutes/Goals'                         => $query->min_goals,
                        'Total Attempts'                        => $query->attempts_t,
                        'Attempts On Target'                    => $query->attempts_on_target,
                        'Minutes/Attempts'                      => $query->min_attempts,
                        'Shot Accuracy'                         => $query->shot_acc,
                        'Goal Conversion'                       => $query->goal_conversion,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-stats-defending' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Defending';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[4];

                    $query = DB::table('players')
                                ->leftJoin('player_stats','player_stats.player_id','=','players.id')
                                ->select('players.name', 
                                    DB::raw('SUM(player_stats.min_played) as min_played'), 
                                    DB::raw('SUM(player_stats.goals) as goals'), 
                                    DB::raw('SUM(player_stats.assist) as assist'), 
                                    DB::raw('SUM(player_stats.goals_conceded) as goals_conceded'), 
                                    DB::raw('SUM(player_stats.own_goals) as own_goals'), 
                                    DB::raw('SUM(player_stats.yellow_c) as yellow_c'), 
                                    DB::raw('SUM(player_stats.red_c) as red_c'), 
                                    DB::raw('SUM(player_stats.touches_t) as touches_t'), 
                                    DB::raw('SUM(player_stats.touches_opp_half) as touches_opp_half'), 
                                    DB::raw('SUM(player_stats.touches_f3) as touches_f3'), 
                                    DB::raw('SUM(player_stats.min_touches) as min_touches'), 
                                    DB::raw('SUM(player_stats.pass_received_t) as pass_received_t'), 
                                    DB::raw('SUM(player_stats.pass_received_opp_half) as pass_received_opp_half'), 
                                    DB::raw('SUM(player_stats.pass_received_f3) as pass_received_f3'), 
                                    DB::raw('SUM(player_stats.min_pass_received) as min_pass_received'), 
                                    DB::raw('SUM(player_stats.take_ons_t) as take_ons_t'), 
                                    DB::raw('SUM(player_stats.take_ons_s) as take_ons_s'), 
                                    DB::raw('SUM(player_stats.take_ons_s_p) as take_ons_s_p'), 
                                    DB::raw('SUM(player_stats.pass_t) as pass_t'), 
                                    DB::raw('SUM(player_stats.pass_s) as pass_s'), 
                                    DB::raw('SUM(player_stats.pass_s_p) as pass_s_p'), 
                                    DB::raw('SUM(player_stats.chance_created) as chance_created'), 
                                    DB::raw('SUM(player_stats.big_chance_created) as big_chance_created'), 
                                    DB::raw('SUM(player_stats.min_chance_created) as min_chance_created'), 
                                    DB::raw('SUM(player_stats.goals_threat) as goals_threat'), 
                                    DB::raw('SUM(player_stats.min_goals) as min_goals'), 
                                    DB::raw('SUM(player_stats.attempts_t) as attempts_t'), 
                                    DB::raw('SUM(player_stats.attempts_on_target) as attempts_on_target'), 
                                    DB::raw('SUM(player_stats.min_attempts) as min_attempts'), 
                                    DB::raw('SUM(player_stats.shot_acc) as shot_acc'), 
                                    DB::raw('SUM(player_stats.goal_conversion) as goal_conversion'), 
                                    DB::raw('SUM(player_stats.aerial_t) as aerial_t'), 
                                    DB::raw('SUM(player_stats.aerial_w) as aerial_w'), 
                                    DB::raw('SUM(player_stats.aerial_w_p) as aerial_w_p'), 
                                    DB::raw('SUM(player_stats.tackles_t) as tackles_t'), 
                                    DB::raw('SUM(player_stats.tackles_w) as tackles_w'), 
                                    DB::raw('SUM(player_stats.tackles_w_p) as tackles_w_p'), 
                                    DB::raw('SUM(player_stats.interceptions) as interceptions'), 
                                    DB::raw('SUM(player_stats.recoveries) as recoveries'), 
                                    DB::raw('SUM(player_stats.clearances) as clearances'), 
                                    DB::raw('SUM(player_stats.blocks) as blocks'), 
                                    DB::raw('SUM(player_stats.err_chance) as err_chance'), 
                                    DB::raw('SUM(player_stats.err_goals) as err_goals'))
                                ->groupBy('players.name')
                                ->where('players.id', '=', $id)
                                ->where('players.user_id', '=', auth()->id())
                                ->first();

                    return new Compendium([
                        'Total Aerial Duels'                         => $query->aerial_t,
                        'Aerial Duels Won'                           => $query->aerial_w,
                        'Aerial Duels Won %'                         => $query->aerial_w_p,
                        'Total Tackles Duels'                        => $query->tackles_t,
                        'Tackles Duels Won'                          => $query->tackles_w,
                        'Tackles Duels Won %'                        => $query->tackles_w_p,
                        'Interceptions'                              => $query->interceptions,
                        'Clearances'                                 => $query->clearances,
                        'Recoveries'                                 => $query->recoveries,
                        'Blocks'                                     => $query->blocks,
                        'Error Leading to Chance'                    => $query->err_chance,
                        'Error Leading to Goal'                      => $query->err_goals,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [
            Button::make('Recommend Position')
                ->icon('note')
                ->method('dss'),  

            Button::make('Individual Stats')
                ->icon('note')
                ->method('addStats'),

            Button::make('Edit Player')
                ->icon('note')
                ->method('editPlayer'),

            Button::make('Remove Player')
                ->icon('trash')
                ->method('removePlayer'),                             
        ];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            new Card('card', [
            ]),

        Layout::accordion([
            'Attributes' => [
                Layout::tabs([
                    'Physical' => barPhysicalChart::class,                    
                    'Technical' => barTechnicalChart::class,
                    'Tactical' => barTacticalChart::class,                                  
                ]),
                
                Layout::columns([
                    new Card('card-physical', [
                        ]), 
                    new Card('card-technical', [
                        ]), 
                    new Card('card-tactical', [
                        ]),                         
                ]),
            ],
            'Overall Stats' => [

                new Card('card-stats-general', [
                    ]),

                Layout::columns([ 
                    new Card('card-stats-goal_threat', [
                        ]), 
                    new Card('card-stats-distribution', [
                        ]),                         
                ]),

                Layout::columns([
                    new Card('card-stats-involvement', [
                        ]), 
                    new Card('card-stats-defending', [
                        ]),                          
                ]),
            ],
        ]),                     
        ];
    }

    public function editPlayer(Players $players)
    {
        return redirect()->route('platform.players.edit', $players);
    }

    public function addStats(Players $players)
    {
        return redirect()->route('platform.players.stats', $players);
    }

    public function dss(Players $players)
    {
        return redirect()->route('platform.players.dss', $players);
    }

    public function removePlayer(Players $players)
    {
        $players->delete();
        $players->AttPhysical()->delete();
        $players->AttTechnical()->delete();
        $players->AttTactical()->delete();

        Alert::info('You have successfully deleted a player.');

        return redirect()->route('platform.players.list');
    }   
}
