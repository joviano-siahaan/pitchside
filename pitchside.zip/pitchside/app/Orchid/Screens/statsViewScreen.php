<?php

namespace App\Orchid\Screens;

use App\Models\Players;
use App\Models\User;
use App\Models\Fixtures;
use App\Models\playerStats;
use App\Models\Opponents;
use Orchid\Screen\Screen;
use Illuminate\Http\Request;
use Orchid\Screen\Layouts\Card;
use Orchid\Screen\Contracts\Cardable;
use Orchid\Support\Facades\Layout;
use Orchid\Support\Color;
use Orchid\Screen\Layouts\Compendium;
use Orchid\Screen\Actions\Button;
use Illuminate\Support\Facades\Storage;
use Orchid\Screen\Actions\Link;
use Orchid\Support\Facades\Alert;
use Orchid\Screen\Fields\Group;
use Illuminate\Database\Eloquent\Model;

class statsViewScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'statsViewScreen';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = 'statsViewScreen';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(playerStats $playerStats, Fixtures $fixtures): array
    {
        return [
            'playerStats' => $playerStats,
            'fixtures' => $fixtures,
            $fixtures_id = $playerStats->fixtures_id,
            $opponent_id = Fixtures::findOrFail($fixtures_id)->opp_id,
            $player_id = $playerStats->player_id,

            $this->description = 'Opponent: ' . Opponents::findOrFail($opponent_id)->presenter()->team_name() . ' (' . Fixtures::findOrFail($fixtures_id)->match_date . ')',
            $this->name = Players::findOrFail($player_id)->presenter()->name(),

            'card-general' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'General';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];

                    $min_played = playerStats::findOrFail($id)->presenter()->min_played();
                    $goals = playerStats::findOrFail($id)->presenter()->goals();
                    $assist = playerStats::findOrFail($id)->presenter()->assist();
                    $goals_conceded = playerStats::findOrFail($id)->presenter()->goals_conceded();
                    $own_goals = playerStats::findOrFail($id)->presenter()->own_goals();
                    $yellow_c = playerStats::findOrFail($id)->presenter()->yellow_c();
                    $red_c = playerStats::findOrFail($id)->presenter()->red_c();

                    return new Compendium([
                        'Minutes Played'              => $min_played,
                        'Goals'                       => $goals,
                        'Assist'                      => $assist,
                        'Goals Conceded'              => $goals_conceded,
                        'Own Goals'                   => $own_goals,
                        'Yellow Card'                 => $yellow_c,
                        'Red Card'                    => $red_c,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-involvement' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Involvement';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];

                    $touches_t = playerStats::findOrFail($id)->presenter()->touches_t();
                    $touches_opp_half = playerStats::findOrFail($id)->presenter()->touches_opp_half();
                    $touches_f3 = playerStats::findOrFail($id)->presenter()->touches_f3();
                    $min_touches = playerStats::findOrFail($id)->presenter()->min_touches();
                    $pass_received_t = playerStats::findOrFail($id)->presenter()->pass_received_t();
                    $pass_received_opp_half = playerStats::findOrFail($id)->presenter()->pass_received_opp_half();
                    $pass_received_f3 = playerStats::findOrFail($id)->presenter()->pass_received_f3();
                    $min_pass_received = playerStats::findOrFail($id)->presenter()->min_pass_received();
                    $take_ons_t = playerStats::findOrFail($id)->presenter()->take_ons_t();
                    $take_ons_s = playerStats::findOrFail($id)->presenter()->take_ons_s();
                    $take_ons_s_p = playerStats::findOrFail($id)->presenter()->take_ons_s_p();

                    return new Compendium([
                        'Total Touches'                         => $touches_t,
                        'Touches in Opp. Half'                  => $touches_opp_half,
                        'Touches in Final Third'                => $touches_f3,
                        'Minutes/Touches'                       => $min_touches,
                        'Total Pass Received'                   => $pass_received_t,
                        'Pass Received in Opp. Half'            => $pass_received_opp_half,
                        'Pass Received in Final Third'          => $pass_received_f3,
                        'Minutes/Pass Received'                 => $min_pass_received,
                        'Total Take Ons'                        => $take_ons_t,
                        'Successful Take Ons'                   => $take_ons_s,
                        'Successful Take Ons %'                 => $take_ons_s_p,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-distribution' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Distribution';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];

                    $pass_t = playerStats::findOrFail($id)->presenter()->pass_t();
                    $pass_s = playerStats::findOrFail($id)->presenter()->pass_s();
                    $pass_s_p = playerStats::findOrFail($id)->presenter()->pass_s_p();
                    $chance_created = playerStats::findOrFail($id)->presenter()->chance_created();
                    $big_chance_created = playerStats::findOrFail($id)->presenter()->big_chance_created();
                    $min_chance_created = playerStats::findOrFail($id)->presenter()->min_chance_created();
                    
                    return new Compendium([
                        'Total Passes'                          => $pass_t,
                        'Successful Passes'                     => $pass_s,
                        'Successful Passes %'                   => $pass_s_p,
                        'Chance Created'                        => $chance_created,
                        'Big Chance Created'                    => $big_chance_created,
                        'Minutes/Chance Created'                => $min_chance_created,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-goal_threat' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Goal Threat';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];

                    $min_goals = playerStats::findOrFail($id)->presenter()->min_goals();
                    $attempts_t = playerStats::findOrFail($id)->presenter()->attempts_t();
                    $attempts_on_target = playerStats::findOrFail($id)->presenter()->attempts_on_target();
                    $min_attempts = playerStats::findOrFail($id)->presenter()->min_attempts();
                    $shot_acc = playerStats::findOrFail($id)->presenter()->shot_acc();
                    $goal_conversion = playerStats::findOrFail($id)->presenter()->goal_conversion();
                    
                    return new Compendium([
                        'Minutes/Goals'                         => $min_goals,
                        'Total Attempts'                        => $attempts_t,
                        'Attempts On Target'                    => $attempts_on_target,
                        'Minutes/Attempts'                      => $min_attempts,
                        'Shot Accuracy'                         => $shot_acc,
                        'Goal Conversion'                       => $goal_conversion,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },

            'card-defending' => new class implements Cardable {
                /**
                 * @return string
                 */
                public function title(): string
                {
                    return 'Defending';
                }

                /**
                 * @return string
                 */
                public function description(): string
                {       
                    $uri =  $_SERVER["REQUEST_URI"];
                    $uriArray = explode('/', $uri);
                    $id = $uriArray[6];

                    $aerial_t = playerStats::findOrFail($id)->presenter()->aerial_t();
                    $aerial_w = playerStats::findOrFail($id)->presenter()->aerial_w();
                    $aerial_w_p = playerStats::findOrFail($id)->presenter()->aerial_w_p();

                    $tackles_t = playerStats::findOrFail($id)->presenter()->tackles_t();
                    $tackles_w = playerStats::findOrFail($id)->presenter()->tackles_w();
                    $tackles_w_p = playerStats::findOrFail($id)->presenter()->tackles_w_p();

                    $interceptions = playerStats::findOrFail($id)->presenter()->interceptions();
                    $clearances = playerStats::findOrFail($id)->presenter()->clearances();
                    $recoveries = playerStats::findOrFail($id)->presenter()->recoveries();

                    $blocks = playerStats::findOrFail($id)->presenter()->blocks();
                    $err_chance = playerStats::findOrFail($id)->presenter()->err_chance();
                    $err_goals = playerStats::findOrFail($id)->presenter()->err_goals();                    
                    
                    return new Compendium([
                        'Total Aerial Duels'                         => $aerial_t,
                        'Aerial Duels Won'                           => $aerial_w,
                        'Aerial Duels Won %'                         => $aerial_w_p,
                        'Total Tackles Duels'                        => $tackles_t,
                        'Tackles Duels Won'                          => $tackles_w,
                        'Tackles Duels Won %'                        => $tackles_w_p,
                        'Interceptions'                              => $interceptions,
                        'Clearances'                                 => $clearances,
                        'Recoveries'                                 => $recoveries,
                        'Blocks'                                     => $blocks,
                        'Error Leading to Chance'                    => $err_chance,
                        'Error Leading to Goal'                      => $err_goals,
                    ]);
                }

                /**
                 * @return string
                 */
                public function image(): ?string
                {
                    return null;
                }

                /**
                 * @return mixed
                 */
                public function color(): ?Color
                {
                    return null;
                }

                /**
                 * {@inheritdoc}
                 */
                public function status(): ?Color
                {
                    return null;
                }
            },                        
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [
            Button::make('Edit Stat')
                ->icon('note')
                ->method('editStat'),

            Button::make('Remove Stat')
                ->icon('trash')
                ->method('removeStat'),                             
        ];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            new Card('card-general', [
            ]),

            Layout::columns([
                new Card('card-involvement', [
                    ]), 
                new Card('card-defending', [
                    ]),                          
            ]),

            Layout::columns([
                new Card('card-distribution', [
                    ]), 
                new Card('card-goal_threat', [
                    ]),                          
            ]),                                
        ];
    }

    public function editStat(playerStats $playerStats)
    {
        return redirect()->route('platform.players.stats.edit', $playerStats);
    }

    public function removeStat(playerStats $playerStats)
    {
        $playerStats->delete();

        Alert::info('You have successfully deleted a player.');

        return redirect()->route('platform.players.list');
    }
}
