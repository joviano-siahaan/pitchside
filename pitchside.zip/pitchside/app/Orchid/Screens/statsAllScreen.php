<?php

namespace App\Orchid\Screens;

use App\Models\Players;
use App\Models\Fixtures;
use App\Models\Opponents;
use App\Models\User;
use App\Models\playerStats;
use Orchid\Screen\Screen;
use Illuminate\Http\Request;
use Orchid\Screen\Layouts\Card;
use Orchid\Screen\Contracts\Cardable;
use Orchid\Support\Facades\Layout;
use Orchid\Support\Color;
use Orchid\Screen\Layouts\Compendium;
use Orchid\Screen\Actions\Button;
use Illuminate\Support\Facades\Storage;
use Orchid\Screen\Actions\Link;
use Orchid\Support\Facades\Alert;
use Orchid\Screen\Fields\Group;
use App\Orchid\Layouts\StatsListAllGeneralLayout;
use App\Orchid\Layouts\StatsListAllDistributionLayout;
use App\Orchid\Layouts\StatsListAllInvolvementLayout;
use App\Orchid\Layouts\StatsListAllGoalThreatLayout;
use App\Orchid\Layouts\StatsListAllDefendingLayout;
use Illuminate\Support\Facades\DB;

class statsAllScreen extends Screen
{
    /**
     * Display header name.
     *
     * @var string
     */
    public $name = 'Player Statistics';

    /**
     * Display header description.
     *
     * @var string|null
     */
    public $description = ' ';

    /**
     * Query data.
     *
     * @return array
     */
    public function query(): array
    {
        return [
                'playerStats' => Players::where('players.user_id', '=', auth()->id())
                    ->leftJoin('player_stats','player_stats.player_id','=','players.id')
                    ->select('players.name', 
                        DB::raw('SUM(player_stats.min_played) as min_played'), 
                        DB::raw('SUM(player_stats.goals) as goals'), 
                        DB::raw('SUM(player_stats.assist) as assist'), 
                        DB::raw('SUM(player_stats.goals_conceded) as goals_conceded'), 
                        DB::raw('SUM(player_stats.own_goals) as own_goals'), 
                        DB::raw('SUM(player_stats.yellow_c) as yellow_c'), 
                        DB::raw('SUM(player_stats.red_c) as red_c'), 
                        DB::raw('SUM(player_stats.touches_t) as touches_t'), 
                        DB::raw('SUM(player_stats.touches_opp_half) as touches_opp_half'), 
                        DB::raw('SUM(player_stats.touches_f3) as touches_f3'), 
                        DB::raw('SUM(player_stats.min_touches) as min_touches'), 
                        DB::raw('SUM(player_stats.pass_received_t) as pass_received_t'), 
                        DB::raw('SUM(player_stats.pass_received_opp_half) as pass_received_opp_half'), 
                        DB::raw('SUM(player_stats.pass_received_f3) as pass_received_f3'), 
                        DB::raw('SUM(player_stats.min_pass_received) as min_pass_received'), 
                        DB::raw('SUM(player_stats.take_ons_t) as take_ons_t'), 
                        DB::raw('SUM(player_stats.take_ons_s) as take_ons_s'), 
                        DB::raw('SUM(player_stats.take_ons_s_p) as take_ons_s_p'), 
                        DB::raw('SUM(player_stats.pass_t) as pass_t'), 
                        DB::raw('SUM(player_stats.pass_s) as pass_s'), 
                        DB::raw('SUM(player_stats.pass_s_p) as pass_s_p'), 
                        DB::raw('SUM(player_stats.chance_created) as chance_created'), 
                        DB::raw('SUM(player_stats.big_chance_created) as big_chance_created'), 
                        DB::raw('SUM(player_stats.min_chance_created) as min_chance_created'), 
                        DB::raw('SUM(player_stats.goals_threat) as goals_threat'), 
                        DB::raw('SUM(player_stats.min_goals) as min_goals'), 
                        DB::raw('SUM(player_stats.attempts_t) as attempts_t'), 
                        DB::raw('SUM(player_stats.attempts_on_target) as attempts_on_target'), 
                        DB::raw('SUM(player_stats.min_attempts) as min_attempts'), 
                        DB::raw('SUM(player_stats.shot_acc) as shot_acc'), 
                        DB::raw('SUM(player_stats.goal_conversion) as goal_conversion'), 
                        DB::raw('SUM(player_stats.aerial_t) as aerial_t'), 
                        DB::raw('SUM(player_stats.aerial_w) as aerial_w'), 
                        DB::raw('SUM(player_stats.aerial_w_p) as aerial_w_p'), 
                        DB::raw('SUM(player_stats.tackles_t) as tackles_t'), 
                        DB::raw('SUM(player_stats.tackles_w) as tackles_w'), 
                        DB::raw('SUM(player_stats.tackles_w_p) as tackles_w_p'), 
                        DB::raw('SUM(player_stats.interceptions) as interceptions'), 
                        DB::raw('SUM(player_stats.recoveries) as recoveries'), 
                        DB::raw('SUM(player_stats.clearances) as clearances'), 
                        DB::raw('SUM(player_stats.blocks) as blocks'), 
                        DB::raw('SUM(player_stats.err_chance) as err_chance'), 
                        DB::raw('SUM(player_stats.err_goals) as err_goals'))
                    ->groupBy('players.name')
                    ->withoutGlobalScope('user_id')
                    ->where('players.user_id', '=', auth()->id())
                    ->get(),
        ];
    }

    /**
     * Button commands.
     *
     * @return \Orchid\Screen\Action[]
     */
    public function commandBar(): array
    {
        return [];
    }

    /**
     * Views.
     *
     * @return \Orchid\Screen\Layout[]|string[]
     */
    public function layout(): array
    {
        return [
            Layout::tabs([
                'General' => StatsListAllGeneralLayout::class,
                'Involvement' => StatsListAllInvolvementLayout::class,
                'Distribution' => StatsListAllDistributionLayout::class,
                'Goal Threat' => StatsListAllGoalThreatLayout::class,
                'Defending' => StatsListAllDefendingLayout::class,
            ]),
        ];
    }
}
