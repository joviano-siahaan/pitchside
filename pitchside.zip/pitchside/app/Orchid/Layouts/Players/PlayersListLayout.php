<?php

namespace App\Orchid\Layouts\Players;

use App\Models\Players;
use Orchid\Screen\Actions\Link;
use Orchid\Screen\Layouts\Table;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\TD;

class PlayersListLayout extends Table
{
    /**
     * @var string
     */
    protected $title = 'Players';

    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'players';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('number', 'Shirt Num.'),
            TD::make('name', 'Player Name')
                ->render(function (Players $players) {
                    return Link::make($players->name)
                        ->route('platform.players.view', $players);
                }),
            TD::make('position', 'Position'),
            TD::make('prefFoot', 'Pref. Foot'),
            TD::make('birthDate', 'Date of Birth'),
            TD::make('weight', 'Weight (kg)'),
            TD::make('height', 'Height (cm)'),
        ];
    }
}
