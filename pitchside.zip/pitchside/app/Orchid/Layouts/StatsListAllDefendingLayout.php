<?php

namespace App\Orchid\Layouts;

use Orchid\Screen\Actions\Link;
use Orchid\Screen\Layouts\Table;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\TD;
use App\Models\Players;

class StatsListAllDefendingLayout extends Table
{
    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'playerStats';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('Player Name')
                ->render(function ($playerStats) {
                    return $playerStats->name;
                }),
            TD::make('AD')
                ->popover('Total Aerial Duels')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->aerial_t;
                }),
            TD::make('ADw')
                ->popover('Total Aerial Duels Won')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->aerial_w;
                }),
            TD::make('ADw%')
                ->popover('Total Aerial Duels Won %')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->aerial_w_p;
                }),
            TD::make('T')
                ->popover('Total Tackles')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->tackles_t;
                }),
            TD::make('Tw')
                ->popover('Total Tackles Won')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->tackles_w;
                }),
            TD::make('Tw%')
                ->popover('Total Tackles Won %')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->tackles_w_p;
                }), 
            TD::make('I')
                ->popover('Interceptions')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->interceptions;
                }),
            TD::make('R')
                ->popover('Recoveries')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->recoveries;
                }),
            TD::make('C')
                ->popover('Clearances')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->clearances;
                }),
            TD::make('B')
                ->popover('Blocks')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->blocks;
                }),
            TD::make('eC')
                ->popover('Error Leading to Chance')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->err_chance;
                }),
            TD::make('eG')
                ->popover('Error Leading to Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->err_goals;
                }),                                             
        ];
    }
}
