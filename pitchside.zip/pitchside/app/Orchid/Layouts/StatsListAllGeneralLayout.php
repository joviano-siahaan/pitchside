<?php

namespace App\Orchid\Layouts;

use Orchid\Screen\Actions\Link;
use Orchid\Screen\Layouts\Table;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\TD;
use App\Models\Players;

class StatsListAllGeneralLayout extends Table
{
    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'playerStats';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('Player Name')
                ->render(function ($playerStats) {
                    return $playerStats->name;
                }),
            TD::make('Min.')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_played;
                }),
            TD::make('Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->goals;
                }),
            TD::make('assist')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->assist;
                }),
            TD::make('Con.')
                ->popover('Clean Sheet - Does the player concede 0 goals?')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->goals_conceded;
                }),
            TD::make('OG')
                ->popover('Own Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->own_goals;
                }),
            TD::make('YC')
                ->popover('Yellow Card')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->yellow_c;
                }),
            TD::make('RC')
                ->popover('Red Card')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->red_c;
                }),                                          
        ];
    }
}
