<?php

namespace App\Orchid\Layouts;

use Orchid\Screen\Actions\Link;
use Orchid\Screen\Layouts\Table;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\TD;
use App\Models\Players;

class StatsListAllGoalThreatLayout extends Table
{
    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'playerStats';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('Player Name')
                ->render(function ($playerStats) {
                    return $playerStats->name;
                }),
            TD::make('m/G')
                ->popover('Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_goals;
                }),
            TD::make('GA')
                ->popover('Goal Attempts')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->attempts_t;
                }),
            TD::make('GAot')
                ->popover('Goal Attempts on Target')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->attempts_on_target;
                }),
            TD::make('m/GA')
                ->popover('Minutes/Goal Attempts')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_attempts;
                }),
            TD::make('SA')
                ->popover('Shot Accuracy')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->shot_acc;
                }),
            TD::make('GC')
                ->popover('Goal Conversion')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->goal_conversion;
                }),
        ];
    }
}
