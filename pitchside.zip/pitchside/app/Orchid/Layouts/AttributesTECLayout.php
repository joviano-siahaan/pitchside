<?php

namespace App\Orchid\Layouts;

use Orchid\Screen\Layouts\Table;
use Orchid\Screen\TD;

class AttributesTECLayout extends Table
{
    /**
     * @var string
     */
    protected $title = 'Attribute - Technical';
    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'attTechnical';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('control', 'Ball Control'),  
            TD::make('pass', 'Passing'),
            TD::make('long_pass', 'Long Passing'), 
            TD::make('shot_acc', 'Shot Accuracy'),             
            TD::make('heading', 'Heading'), 
            TD::make('tackle', 'Tackling'), 
            TD::make('catching', 'Catching'), 
            TD::make('reflex', 'Reflex'), 
        ];                          
    }
}
