<?php

namespace App\Orchid\Layouts;

use Orchid\Screen\Actions\Link;
use Orchid\Screen\Layouts\Table;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\TD;
use App\Models\Players;

class StatsListAllDistributionLayout extends Table
{
    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'playerStats';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('Player Name')
                ->render(function ($playerStats) {
                    return $playerStats->name;
                }),
            TD::make('P')
                ->popover('Total Attempted Pass')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_t;
                }),
            TD::make('Ps')
                ->popover('Total Successful Pass')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_s;
                }),
            TD::make('Ps%')
                ->popover('Total Successful Pass %')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_s_p;
                }),
            TD::make('CC')
                ->popover('Chance Created')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->chance_created;
                }),
            TD::make('BCC')
                ->popover('Big Chance Created')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->big_chance_created;
                }),
            TD::make('m/CC')
                ->popover('Minutes/Chance Created')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_chance_created;
                }),    
        ];
    }
}
