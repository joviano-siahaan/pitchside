<?php

namespace App\Orchid\Layouts;

use Orchid\Screen\Layouts\Table;
use Orchid\Screen\TD;

class AttributesTACLayout extends Table
{
    /**
     * @var string
     */
    protected $title = 'Attribute - Tactical';
    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'attTactical';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('positioning', 'Positioning'),  
            TD::make('creative', 'Creativity'),
            TD::make('determination', 'Determination'), 
            TD::make('reading', 'Reading the game'),             
        ];
    }
}
