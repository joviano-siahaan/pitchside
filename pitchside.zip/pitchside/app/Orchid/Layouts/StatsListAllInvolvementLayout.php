<?php

namespace App\Orchid\Layouts;

use Orchid\Screen\Actions\Link;
use Orchid\Screen\Layouts\Table;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\TD;
use App\Models\Players;

class StatsListAllInvolvementLayout extends Table
{
    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'playerStats';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('Player Name')
                ->render(function ($playerStats) {
                    return $playerStats->name;
                }),
            TD::make('Tt')
                ->popover('Total Amount of Touches')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->touches_t;
                }),
            TD::make('Toh')
                ->popover('Touches in Opposition Half')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->touches_opp_half;
                }),
            TD::make('Tf3')
                ->popover('Touches in the Final 3rd')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->touches_f3;
                }),
            TD::make('m/T')
                ->popover('Minutes/Touches')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_touches;
                }),
            TD::make('Pr')
                ->popover('Pass Received')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_received_t;
                }),
            TD::make('Poh')
                ->popover('Pass Received in Opposition Half')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_received_opp_half;
                }),
            TD::make('P3')
                ->popover('Pass Received in Final 3rd')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_received_f3;
                }),
            TD::make('m/P')
                ->popover('Minutes/Pass')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_pass_received;
                }),

            TD::make('TO')
                ->popover('Take Ons')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->take_ons_t;
                }),   
            TD::make('TOs')
                ->popover('Successful Take Ons')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->take_ons_s;
                }),
            TD::make('TOs%')
                ->popover('Successful Take Ons %')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->take_ons_s_p;
                }),

        ];
    }
}
