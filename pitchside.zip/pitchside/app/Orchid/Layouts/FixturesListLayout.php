<?php

namespace App\Orchid\Layouts;

use Orchid\Screen\Layouts\Table;
use Orchid\Screen\TD;
use Orchid\Screen\Actions\Link;

class FixturesListLayout extends Table
{
    /**
     * @var string
     */
    protected $title = 'Fixtures';

    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'fixtures';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [            
            TD::make('Opponent Name')
                ->render(function ($fixtures) {
                    return Link::make($fixtures->opponents->team_name)
                        ->route('platform.fixtures.edit', $fixtures);                    
                }),
            TD::make('')
                ->render(function ($fixtures) {
                    return "<img src='". $fixtures->opponents->urlImage . "'" . 
                        "width='40' 'height='40'";
                }),
            TD::make('match_date', 'Match Date'),
            TD::make('homeaway', 'Home/Away'),
            TD::make('Score')
                ->render(function ($fixtures) {
                    if ($fixtures->homeaway == 'Home') {
                        return $fixtures->team_score . ' - ' . $fixtures->opp_score;
                    }
                    else { 
                        return $fixtures->opp_score . ' - ' . $fixtures->team_score;
                    }

                }),     
            TD::make('Result')
                ->render(function ($fixtures) {
                    if ($fixtures->team_score > $fixtures->opp_score) {
                        return 'Win';
                    }
                    elseif ($fixtures->team_score < $fixtures->opp_score) {
                        return 'Lost';
                    }
                    else {
                        return 'Draw';
                    }
                }) 
        ];
    }
}
