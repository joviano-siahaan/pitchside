        return [
            TD::make('Opponent')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->fixtures->opponents->team_name;
                }),
            TD::make('Min.')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_played;
                }),
            TD::make('Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->goals;
                }),
            TD::make('assist')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->assist;
                }),
            TD::make('CS')
                ->popover('Clean Sheet - Does the player concede 0 goals?')
                ->render(function ($playerStats) { 
                    if ($playerStats->clean_sheet == 0) {
                            return 'No';
                        }
                        elseif ($playerStats->clean_sheet == 1) { 
                            return 'Yes';
                        }                        
                }),
            TD::make('Con.')
                ->popover('Clean Sheet - Does the player concede 0 goals?')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->goals_conceded;
                }),
            TD::make('OG')
                ->popover('Own Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->own_goals;
                }),
            TD::make('Y')
                ->popover('Yellow Card')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->yellow_c;
                }),
            TD::make('R')
                ->popover('Red Card')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->red_c;
                }),

            TD::make('Tt')
                ->popover('Total Amount of Touches')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->touches_t;
                }),
            TD::make('Toh')
                ->popover('Touches in Opposition Half')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->touches_opp_half;
                }),
            TD::make('Tf3')
                ->popover('Touches in the Final 3rd')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->touches_f3;
                }),
            TD::make('m/T')
                ->popover('Minutes/Touches')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_touches;
                }),
            TD::make('Pr')
                ->popover('Pass Received')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_received_t;
                }),
            TD::make('Poh')
                ->popover('Pass Received in Opposition Half')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_received_opp_half;
                }),
            TD::make('P3')
                ->popover('Pass Received in Final 3rd')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_received_f3;
                }),
            TD::make('m/P')
                ->popover('Minutes/Pass')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_pass_received;
                }),

            TD::make('TO')
                ->popover('Take Ons')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->take_ons_t;
                }),   
            TD::make('TOs')
                ->popover('Successful Take Ons')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->take_ons_s;
                }),
            TD::make('TOs%')
                ->popover('Successful Take Ons %')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->take_ons_s_p;
                }),

            TD::make('P')
                ->popover('Total Attempted Pass')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_t;
                }),
            TD::make('Ps')
                ->popover('Total Successful Pass')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_s;
                }),
            TD::make('Ps%')
                ->popover('Total Successful Pass %')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->pass_s_p;
                }),
            TD::make('CC')
                ->popover('Chance Created')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->chance_created;
                }),
            TD::make('BCC')
                ->popover('Big Chance Created')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->big_chance_created;
                }),
            TD::make('m/CC')
                ->popover('Minutes/Chance Created')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_chance_created;
                }),
            TD::make('G')
                ->popover('Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->goal_threat;
                }),
            TD::make('m/G')
                ->popover('Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_goals;
                }),
            TD::make('GA')
                ->popover('Goal Attempts')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->attempts_t;
                }),
            TD::make('GAot')
                ->popover('Goal Attempts on Target')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->attempts_on_target;
                }),
            TD::make('m/GA')
                ->popover('Minutes/Goal Attempts')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->min_attempts;
                }),
            TD::make('SA')
                ->popover('Shot Accuracy')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->shot_acc;
                }),
            TD::make('GC')
                ->popover('Goal Conversion')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->goal_conversion;
                }),

            TD::make('AD')
                ->popover('Total Aerial Duels')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->aerial_t;
                }),
            TD::make('ADw')
                ->popover('Total Aerial Duels Won')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->aerial_w;
                }),
            TD::make('ADw%')
                ->popover('Total Aerial Duels Won %')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->aerial_w_p;
                }),
            TD::make('T')
                ->popover('Total Tackles')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->tackles_t;
                }),
            TD::make('Tw')
                ->popover('Total Tackles Won')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->tackles_w;
                }),
            TD::make('Tw%')
                ->popover('Total Tackles Won %')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->tackles_w_p;
                }), 
            TD::make('I')
                ->popover('Interceptions')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->interceptions;
                }),
            TD::make('R')
                ->popover('Recoveries')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->recoveries;
                }),
            TD::make('C')
                ->popover('Clearances')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->clearances;
                }),
            TD::make('B')
                ->popover('Blocks')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->blocks;
                }),
            TD::make('eC')
                ->popover('Error Leading to Chance')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->err_chance;
                }),
            TD::make('eG')
                ->popover('Error Leading to Goals')
                ->render(function ($playerStats) {
                    return 
                        $playerStats->err_goals;
                }),                                           
        ];