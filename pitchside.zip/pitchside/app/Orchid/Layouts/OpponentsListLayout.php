<?php

namespace App\Orchid\Layouts;

use App\Models\Opponents;
use Orchid\Screen\Actions\Link;
use Orchid\Screen\Layouts\Table;
use Orchid\Support\Facades\Layout;
use Orchid\Screen\TD;

class OpponentsListLayout extends Table
{
    /**
     * @var string
     */
    protected $title = 'Opponents';

    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the table.
     *
     * @var string
     */
    protected $target = 'opponents';

    /**
     * Get the table cells to be displayed.
     *
     * @return TD[]
     */
    protected function columns(): array
    {
        return [
            TD::make('team_name', 'Team Name')
                ->render(function (Opponents $opponents) {
                    return Link::make($opponents->team_name)
                        ->route('platform.opponents.edit', $opponents);
                }),
            TD::make('abv', 'Abbreviation'), 
            TD::make('urlImage', 'Logo')
                ->render(function (Opponents $opponents) {
                    return "<img src='". $opponents->urlImage . "'" . 
                        "width='40' 'height='40'";
                }),            
        ];
    }
}
