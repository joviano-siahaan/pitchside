<?php

declare(strict_types=1);

namespace App\Orchid\Layouts\Chart;

use Orchid\Screen\Layouts\Chart;

class barChartDashboard extends Chart
{
    /**
     * Add a title to the Chart.
     *
     * @var string
     */
    protected $title = 'Goals';

    /**
     * Available options:
     * 'bar', 'line',
     * 'pie', 'percentage'.
     *
     * @var string
     */
    protected $type = 'bar';
    /**
     * Data source.
     *
     * The name of the key to fetch it from the query.
     * The results of which will be elements of the chart.
     *
     * @var string
     */
    protected $target = 'dashboard_chart';

    /**
     * Determines whether to display the export button.
     *
     * @var bool
     */
    protected $export = true;
}
