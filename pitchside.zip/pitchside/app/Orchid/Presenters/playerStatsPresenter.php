<?php

namespace App\Orchid\Presenters;

use Orchid\Support\Presenter;

class playerStatsPresenter extends Presenter
{
    public function min_played(): string
    {
        return $this->entity->min_played;
    }

    public function goals(): string
    {
        return $this->entity->goals;
    }

    public function assist(): string
    {
        return $this->entity->assist;
    }

    public function goals_conceded(): string
    {
        return $this->entity->goals_conceded;
    }

    public function own_goals(): string
    {
        return $this->entity->own_goals;
    }

    public function yellow_c(): string
    {
        return $this->entity->yellow_c;
    }

    public function red_c(): string
    {
        return $this->entity->red_c;
    }

    public function touches_t(): string
    {
        return $this->entity->touches_t;
    }

    public function touches_opp_half(): string
    {
        return $this->entity->touches_opp_half;
    }

    public function touches_f3(): string
    {
        return $this->entity->touches_f3;
    }

    public function min_touches(): string
    {
        return $this->entity->min_touches;
    }

    public function pass_received_t(): string
    {
        return $this->entity->pass_received_t;
    }

    public function pass_received_opp_half(): string
    {
        return $this->entity->pass_received_opp_half;
    }

    public function pass_received_f3(): string
    {
        return $this->entity->pass_received_f3;
    }

    public function min_pass_received(): string
    {
        return $this->entity->min_pass_received;
    }

    public function take_ons_t(): string
    {
        return $this->entity->take_ons_t;
    }

    public function take_ons_s(): string
    {
        return $this->entity->take_ons_s;
    }

    public function take_ons_s_p(): string
    {
        return $this->entity->take_ons_s_p;
    }

    public function pass_t(): string
    {
        return $this->entity->pass_t;
    }

    public function pass_s(): string
    {
        return $this->entity->pass_s;
    }

    public function pass_s_p(): string
    {
        return $this->entity->pass_s_p;
    }

    public function chance_created(): string
    {
        return $this->entity->chance_created;
    }

    public function big_chance_created(): string
    {
        return $this->entity->big_chance_created;
    }

    public function min_chance_created(): string
    {
        return $this->entity->min_chance_created;
    }

    public function goals_threat(): string
    {
        return $this->entity->goals_threat;
    }

    public function min_goals(): string
    {
        return $this->entity->min_goals;
    }

    public function attempts_t(): string
    {
        return $this->entity->attempts_t;
    }

    public function attempts_on_target(): string
    {
        return $this->entity->attempts_on_target;
    }

    public function min_attempts(): string
    {
        return $this->entity->min_attempts;
    }

    public function shot_acc(): string
    {
        return $this->entity->shot_acc;
    }

    public function goal_conversion(): string
    {
        return $this->entity->goal_conversion;
    }

    public function aerial_t(): string
    {
        return $this->entity->aerial_t;
    }

    public function aerial_w(): string
    {
        return $this->entity->aerial_w;
    }

    public function aerial_w_p(): string
    {
        return $this->entity->aerial_w_p;
    }

    public function tackles_t(): string
    {
        return $this->entity->tackles_t;
    }

    public function tackles_w(): string
    {
        return $this->entity->tackles_w;
    }

    public function tackles_w_p(): string
    {
        return $this->entity->tackles_w_p;
    }

    public function interceptions(): string
    {
        return $this->entity->interceptions;
    }


    public function recoveries(): string
    {
        return $this->entity->recoveries;
    }

    public function clearances(): string
    {
        return $this->entity->clearances;
    }

    public function blocks(): string
    {
        return $this->entity->blocks;
    }

    public function err_chance(): string
    {
        return $this->entity->err_chance;
    }

    public function err_goals(): string
    {
        return $this->entity->err_goals;
    }


}
