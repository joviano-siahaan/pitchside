<?php

namespace App\Orchid\Presenters;

use Orchid\Support\Presenter;

class FixturesPresenter extends Presenter
{
    public function home_away(): string
    {
        return $this->entity->home_away;
    }

    public function user_score(): string
    {
        return $this->entity->user_score;
    } 		
    public function opp_score(): string
    {
        return $this->entity->opp_score;
    } 	
    public function match_date(): string
    {
        return $this->entity->match_date;
    } 		
}
