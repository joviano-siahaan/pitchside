<?php

namespace App\Orchid\Presenters;

use Orchid\Support\Presenter;

class AttTechnicalPresenter extends Presenter
{
    public function pass(): string
    {
        return $this->entity->pass;
    }
    public function control(): string
    {
        return $this->entity->control;
    }
    public function long_pass(): string
    {
        return $this->entity->long_pass;
    }
    public function shot_acc(): string
    {
        return $this->entity->shot_acc;
    }
    public function heading(): string
    {
        return $this->entity->heading;
    }
    public function tackle(): string
    {
        return $this->entity->tackle;
    }
    public function catching(): string
    {
        return $this->entity->catching;
    }
    public function reflex(): string
    {
        return $this->entity->reflex;
    }
}
