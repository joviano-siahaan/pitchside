<?php

namespace App\Orchid\Presenters;

use Orchid\Support\Presenter;

class OpponentsPresenter extends Presenter
{
    public function team_name(): string
    {
        return $this->entity->team_name;
    }

    public function abv(): string
    {
        return $this->entity->abv;
    }

    public function img(): string
    {
        return $this->entity->urlImage;
    } 	
}
