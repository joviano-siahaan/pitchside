<?php

namespace App\Orchid\Presenters;

use Orchid\Support\Presenter;

class dssWeightPresenter extends Presenter
{
    public function gk_speed(): string
    {
        return $this->entity->gk_speed;
    }
    public function gk_balance(): string
    {
        return $this->entity->gk_balance;
    }
    public function gk_strength(): string
    {
        return $this->entity->gk_strength;
    }
    public function gk_durability(): string
    {
        return $this->entity->gk_durability;
    }
    public function gk_agility(): string
    {
        return $this->entity->gk_agility;
    }
    public function gk_power(): string
    {
        return $this->entity->gk_power;
    }
    public function gk_stamina(): string
    {
        return $this->entity->gk_stamina;
    }
    public function gk_jumping(): string
    {
        return $this->entity->gk_jumping;
    }
    public function gk_pass(): string
    {
        return $this->entity->gk_pass;
    }
    public function gk_control(): string
    {
        return $this->entity->gk_control;
    }
    public function gk_long_pass(): string
    {
        return $this->entity->gk_long_pass;
    }
    public function gk_shot_acc(): string
    {
        return $this->entity->gk_shot_acc;
    }
    public function gk_heading(): string
    {
        return $this->entity->gk_heading;
    }
    public function gk_tackle(): string
    {
        return $this->entity->gk_tackle;
    }
    public function gk_catching(): string
    {
        return $this->entity->gk_catching;
    }
    public function gk_reflex(): string
    {
        return $this->entity->gk_reflex;
    }
    public function gk_positioning(): string
    {
        return $this->entity->gk_positioning;
    }
    public function gk_creative(): string
    {
        return $this->entity->gk_creative;
    }
    public function gk_determination(): string
    {
        return $this->entity->gk_determination;
    }
    public function gk_reading(): string
    {
        return $this->entity->gk_reading;
    }

    //

    public function def_speed(): string
    {
        return $this->entity->def_speed;
    }
    public function def_balance(): string
    {
        return $this->entity->def_balance;
    }
    public function def_strength(): string
    {
        return $this->entity->def_strength;
    }
    public function def_durability(): string
    {
        return $this->entity->def_durability;
    }
    public function def_agility(): string
    {
        return $this->entity->def_agility;
    }
    public function def_power(): string
    {
        return $this->entity->def_power;
    }
    public function def_stamina(): string
    {
        return $this->entity->def_stamina;
    }
    public function def_jumping(): string
    {
        return $this->entity->def_jumping;
    }
    public function def_pass(): string
    {
        return $this->entity->def_pass;
    }
    public function def_control(): string
    {
        return $this->entity->def_control;
    }
    public function def_long_pass(): string
    {
        return $this->entity->def_long_pass;
    }
    public function def_shot_acc(): string
    {
        return $this->entity->def_shot_acc;
    }
    public function def_heading(): string
    {
        return $this->entity->def_heading;
    }
    public function def_tackle(): string
    {
        return $this->entity->def_tackle;
    }
    public function def_catching(): string
    {
        return $this->entity->def_catching;
    }
    public function def_reflex(): string
    {
        return $this->entity->def_reflex;
    }
    public function def_positioning(): string
    {
        return $this->entity->def_positioning;
    }
    public function def_creative(): string
    {
        return $this->entity->def_creative;
    }
    public function def_determination(): string
    {
        return $this->entity->def_determination;
    }
    public function def_reading(): string
    {
        return $this->entity->def_reading;
    }

    //

    public function dm_speed(): string
    {
        return $this->entity->dm_speed;
    }
    public function dm_balance(): string
    {
        return $this->entity->dm_balance;
    }
    public function dm_strength(): string
    {
        return $this->entity->dm_strength;
    }
    public function dm_durability(): string
    {
        return $this->entity->dm_durability;
    }
    public function dm_agility(): string
    {
        return $this->entity->dm_agility;
    }
    public function dm_power(): string
    {
        return $this->entity->dm_power;
    }
    public function dm_stamina(): string
    {
        return $this->entity->dm_stamina;
    }
    public function dm_jumping(): string
    {
        return $this->entity->dm_jumping;
    }
    public function dm_pass(): string
    {
        return $this->entity->dm_pass;
    }
    public function dm_control(): string
    {
        return $this->entity->dm_control;
    }
    public function dm_long_pass(): string
    {
        return $this->entity->dm_long_pass;
    }
    public function dm_shot_acc(): string
    {
        return $this->entity->dm_shot_acc;
    }
    public function dm_heading(): string
    {
        return $this->entity->dm_heading;
    }
    public function dm_tackle(): string
    {
        return $this->entity->dm_tackle;
    }
    public function dm_catching(): string
    {
        return $this->entity->dm_catching;
    }
    public function dm_reflex(): string
    {
        return $this->entity->dm_reflex;
    }
    public function dm_positioning(): string
    {
        return $this->entity->dm_positioning;
    }
    public function dm_creative(): string
    {
        return $this->entity->dm_creative;
    }
    public function dm_determination(): string
    {
        return $this->entity->dm_determination;
    }
    public function dm_reading(): string
    {
        return $this->entity->dm_reading;
    }

    //

    public function am_speed(): string
    {
        return $this->entity->am_speed;
    }
    public function am_balance(): string
    {
        return $this->entity->am_balance;
    }
    public function am_strength(): string
    {
        return $this->entity->am_strength;
    }
    public function am_durability(): string
    {
        return $this->entity->am_durability;
    }
    public function am_agility(): string
    {
        return $this->entity->am_agility;
    }
    public function am_power(): string
    {
        return $this->entity->am_power;
    }
    public function am_stamina(): string
    {
        return $this->entity->am_stamina;
    }
    public function am_jumping(): string
    {
        return $this->entity->am_jumping;
    }
    public function am_pass(): string
    {
        return $this->entity->am_pass;
    }
    public function am_control(): string
    {
        return $this->entity->am_control;
    }
    public function am_long_pass(): string
    {
        return $this->entity->am_long_pass;
    }
    public function am_shot_acc(): string
    {
        return $this->entity->am_shot_acc;
    }
    public function am_heading(): string
    {
        return $this->entity->am_heading;
    }
    public function am_tackle(): string
    {
        return $this->entity->am_tackle;
    }
    public function am_catching(): string
    {
        return $this->entity->am_catching;
    }
    public function am_reflex(): string
    {
        return $this->entity->am_reflex;
    }
    public function am_positioning(): string
    {
        return $this->entity->am_positioning;
    }
    public function am_creative(): string
    {
        return $this->entity->am_creative;
    }
    public function am_determination(): string
    {
        return $this->entity->am_determination;
    }
    public function am_reading(): string
    {
        return $this->entity->am_reading;
    }

    //

    public function wing_speed(): string
    {
        return $this->entity->wing_speed;
    }
    public function wing_balance(): string
    {
        return $this->entity->wing_balance;
    }
    public function wing_strength(): string
    {
        return $this->entity->wing_strength;
    }
    public function wing_durability(): string
    {
        return $this->entity->wing_durability;
    }
    public function wing_agility(): string
    {
        return $this->entity->wing_agility;
    }
    public function wing_power(): string
    {
        return $this->entity->wing_power;
    }
    public function wing_stamina(): string
    {
        return $this->entity->wing_stamina;
    }
    public function wing_jumping(): string
    {
        return $this->entity->wing_jumping;
    }
    public function wing_pass(): string
    {
        return $this->entity->wing_pass;
    }
    public function wing_control(): string
    {
        return $this->entity->wing_control;
    }
    public function wing_long_pass(): string
    {
        return $this->entity->wing_long_pass;
    }
    public function wing_shot_acc(): string
    {
        return $this->entity->wing_shot_acc;
    }
    public function wing_heading(): string
    {
        return $this->entity->wing_heading;
    }
    public function wing_tackle(): string
    {
        return $this->entity->wing_tackle;
    }
    public function wing_catching(): string
    {
        return $this->entity->wing_catching;
    }
    public function wing_reflex(): string
    {
        return $this->entity->wing_reflex;
    }
    public function wing_positioning(): string
    {
        return $this->entity->wing_positioning;
    }
    public function wing_creative(): string
    {
        return $this->entity->wing_creative;
    }
    public function wing_determination(): string
    {
        return $this->entity->wing_determination;
    }
    public function wing_reading(): string
    {
        return $this->entity->wing_reading;
    }

    //

    public function st_speed(): string
    {
        return $this->entity->st_speed;
    }
    public function st_balance(): string
    {
        return $this->entity->st_balance;
    }
    public function st_strength(): string
    {
        return $this->entity->st_strength;
    }
    public function st_durability(): string
    {
        return $this->entity->st_durability;
    }
    public function st_agility(): string
    {
        return $this->entity->st_agility;
    }
    public function st_power(): string
    {
        return $this->entity->st_power;
    }
    public function st_stamina(): string
    {
        return $this->entity->st_stamina;
    }
    public function st_jumping(): string
    {
        return $this->entity->st_jumping;
    }
    public function st_pass(): string
    {
        return $this->entity->st_pass;
    }
    public function st_control(): string
    {
        return $this->entity->st_control;
    }
    public function st_long_pass(): string
    {
        return $this->entity->st_long_pass;
    }
    public function st_shot_acc(): string
    {
        return $this->entity->st_shot_acc;
    }
    public function st_heading(): string
    {
        return $this->entity->st_heading;
    }
    public function st_tackle(): string
    {
        return $this->entity->st_tackle;
    }
    public function st_catching(): string
    {
        return $this->entity->st_catching;
    }
    public function st_reflex(): string
    {
        return $this->entity->st_reflex;
    }
    public function st_positioning(): string
    {
        return $this->entity->st_positioning;
    }
    public function st_creative(): string
    {
        return $this->entity->st_creative;
    }
    public function st_determination(): string
    {
        return $this->entity->st_determination;
    }
    public function st_reading(): string
    {
        return $this->entity->st_reading;
    }
}
