<?php

namespace App\Orchid\Presenters;

use Orchid\Support\Presenter;

class AttTacticalPresenter extends Presenter
{
    public function positioning(): string
    {
        return $this->entity->positioning;
    }
    public function creative(): string
    {
        return $this->entity->creative;
    }
    public function determination(): string
    {
        return $this->entity->determination;
    }
    public function reading(): string
    {
        return $this->entity->reading;
    }
}
