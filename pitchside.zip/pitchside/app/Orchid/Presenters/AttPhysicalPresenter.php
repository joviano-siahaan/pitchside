<?php

namespace App\Orchid\Presenters;

use Orchid\Support\Presenter;

class AttPhysicalPresenter extends Presenter
{
    public function speed(): string
    {
        return $this->entity->speed;
    }
    public function balance(): string
    {
        return $this->entity->balance;
    }
    public function strength(): string
    {
        return $this->entity->strength;
    }
    public function durability(): string
    {
        return $this->entity->durability;
    }
    public function agility(): string
    {
        return $this->entity->agility;
    }
    public function power(): string
    {
        return $this->entity->power;
    }
    public function stamina(): string
    {
        return $this->entity->stamina;
    }
    public function jumping(): string
    {
        return $this->entity->jumping;
    }
}
