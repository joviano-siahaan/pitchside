<?php

namespace App\Orchid\Presenters;

use Orchid\Support\Presenter;
use Orchid\Screen\Contracts\Cardable; 

class PlayersPresenter extends Presenter
{
    public function header(): string
    {
        return $this->entity->number . '. ' . $this->entity->name;
    }

    public function name(): string
    {
        return $this->entity->name;
    }

    public function position(): string
    {
        return $this->entity->position;
    }

    public function number(): string
    {
        return $this->entity->number;
    } 

    public function dob(): string
    {
        return $this->entity->birthDate;
    }  

    public function weight(): string
    {
        return $this->entity->weight . 'kg';
    }  

    public function height(): string
    {
        return $this->entity->height . 'cm';
    }  

    public function prefFoot(): string
    {
        return $this->entity->prefFoot;
    }    

    public function img(): string
    {
        return $this->entity->urlImage;
    }       
}
