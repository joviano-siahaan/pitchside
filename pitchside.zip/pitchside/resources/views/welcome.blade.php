<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>PitchSide</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
            /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0}a{background-color:transparent}[hidden]{display:none}html{font-family:system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;line-height:1.5}*,:after,:before{box-sizing:border-box;border:0 solid #e2e8f0}a{color:inherit;text-decoration:inherit}svg,video{display:block;vertical-align:middle}video{max-width:100%;height:auto}.bg-white{--bg-opacity:1;background-color:#fff;background-color:rgba(255,255,255,var(--bg-opacity))}.bg-gray-100{--bg-opacity:1;background-color:#f7fafc;background-color:rgba(247,250,252,var(--bg-opacity))}.border-gray-200{--border-opacity:1;border-color:#edf2f7;border-color:rgba(237,242,247,var(--border-opacity))}.border-t{border-top-width:1px}.flex{display:flex}.grid{display:grid}.hidden{display:none}.items-center{align-items:center}.justify-center{justify-content:center}.font-semibold{font-weight:600}.h-5{height:1.25rem}.h-8{height:2rem}.h-16{height:4rem}.text-sm{font-size:.875rem}.text-lg{font-size:1.125rem}.leading-7{line-height:1.75rem}.mx-auto{margin-left:auto;margin-right:auto}.ml-1{margin-left:.25rem}.mt-2{margin-top:.5rem}.mr-2{margin-right:.5rem}.ml-2{margin-left:.5rem}.mt-4{margin-top:1rem}.ml-4{margin-left:1rem}.mt-8{margin-top:2rem}.ml-12{margin-left:3rem}.-mt-px{margin-top:-1px}.max-w-6xl{max-width:72rem}.min-h-screen{min-height:100vh}.overflow-hidden{overflow:hidden}.p-6{padding:1.5rem}.py-4{padding-top:1rem;padding-bottom:1rem}.px-6{padding-left:1.5rem;padding-right:1.5rem}.pt-8{padding-top:2rem}.fixed{position:fixed}.relative{position:relative}.top-0{top:0}.right-0{right:0}.shadow{box-shadow:0 1px 3px 0 rgba(0,0,0,.1),0 1px 2px 0 rgba(0,0,0,.06)}.text-center{text-align:center}.text-gray-200{--text-opacity:1;color:#edf2f7;color:rgba(237,242,247,var(--text-opacity))}.text-gray-300{--text-opacity:1;color:#e2e8f0;color:rgba(226,232,240,var(--text-opacity))}.text-gray-400{--text-opacity:1;color:#cbd5e0;color:rgba(203,213,224,var(--text-opacity))}.text-gray-500{--text-opacity:1;color:#a0aec0;color:rgba(160,174,192,var(--text-opacity))}.text-gray-600{--text-opacity:1;color:#718096;color:rgba(113,128,150,var(--text-opacity))}.text-gray-700{--text-opacity:1;color:#4a5568;color:rgba(74,85,104,var(--text-opacity))}.text-gray-900{--text-opacity:1;color:#1a202c;color:rgba(26,32,44,var(--text-opacity))}.underline{text-decoration:underline}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.w-5{width:1.25rem}.w-8{width:2rem}.w-auto{width:auto}.grid-cols-1{grid-template-columns:repeat(1,minmax(0,1fr))}@media (min-width:640px){.sm\:rounded-lg{border-radius:.5rem}.sm\:block{display:block}.sm\:items-center{align-items:center}.sm\:justify-start{justify-content:flex-start}.sm\:justify-between{justify-content:space-between}.sm\:h-20{height:5rem}.sm\:ml-0{margin-left:0}.sm\:px-6{padding-left:1.5rem;padding-right:1.5rem}.sm\:pt-0{padding-top:0}.sm\:text-left{text-align:left}.sm\:text-right{text-align:right}}@media (min-width:768px){.md\:border-t-0{border-top-width:0}.md\:border-l{border-left-width:1px}.md\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (min-width:1024px){.lg\:px-8{padding-left:2rem;padding-right:2rem}}@media (prefers-color-scheme:dark){.dark\:bg-gray-800{--bg-opacity:1;background-color:#2d3748;background-color:rgba(45,55,72,var(--bg-opacity))}.dark\:bg-gray-900{--bg-opacity:1;background-color:#1a202c;background-color:rgba(26,32,44,var(--bg-opacity))}.dark\:border-gray-700{--border-opacity:1;border-color:#4a5568;border-color:rgba(74,85,104,var(--border-opacity))}.dark\:text-white{--text-opacity:1;color:#fff;color:rgba(255,255,255,var(--text-opacity))}.dark\:text-gray-400{--text-opacity:1;color:#cbd5e0;color:rgba(203,213,224,var(--text-opacity))}}
        </style>

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen sm:items-center py-4 sm:pt-0">
            @if (Route::has('login'))
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    @auth
                        <a href="{{ url('/admin') }}" class="text-sm text-gray-700 underline">Home</a>
                    @else
                        <a href="{{ route('login') }}" class="text-sm text-gray-700 underline">Log in</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="ml-4 text-sm text-gray-700 underline">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
                <div class="flex justify-center pt-8 sm:justify-start sm:pt-0">


                <div class="flex justify-center mt-4 sm:items-center sm:justify-between">
                    <div class="text-center text-sm text-gray-500 sm:text-left">
                        <div class="flex items-center">
                            <a class="d-flex justify-content-center mb-4" fill="black">
                                        <p class="h1 n-m font-thin v-center">
                                <svg xmlns="http://www.w3.org/2000/svg" id="Icons" height="7em" viewBox="0 0 74 74" width="7em" role="img" fill="black" componentname="orchid-icon"><path d="m60 71h-46a1 1 0 0 1 -1-1v-66a1 1 0 0 1 1-1h46a1 1 0 0 1 1 1v66a1 1 0 0 1 -1 1zm-45-2h44v-64h-44z"></path><path d="m14 36h46v2h-46z"></path><path d="m37 48a11 11 0 1 1 11-11 11.012 11.012 0 0 1 -11 11zm0-20a9 9 0 1 0 9 9 9.01 9.01 0 0 0 -9-9z"></path><path d="m51 71h-28a1 1 0 0 1 -1-1v-8a1 1 0 0 1 1-1h28a1 1 0 0 1 1 1v8a1 1 0 0 1 -1 1zm-27-2h26v-6h-26z"></path><path d="m45 62h-2a6 6 0 0 0 -12 0h-2a8 8 0 0 1 16 0z"></path><path d="m51 13h-28a1 1 0 0 1 -1-1v-8a1 1 0 0 1 1-1h28a1 1 0 0 1 1 1v8a1 1 0 0 1 -1 1zm-27-2h26v-6h-26z"></path><path d="m37 20a8.009 8.009 0 0 1 -8-8h2a6 6 0 0 0 12 0h2a8.009 8.009 0 0 1 -8 8z"></path></svg>
                            </p>        </a>
                            <h1 style="font-size: 4em; color: black;">PitchSide</h1>
                        </div>
                    </div>
                </div>


                </div>
                <div class="mt-8 bg-white overflow-hidden shadow sm:rounded-lg">
                    <div class="grid grid-cols-1 md:grid-cols-2">
                        <div class="p-6">
                            <div class="flex items-center">
                                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" height="2em" width="2em"
                                     viewBox="0 0 480 480" style="enable-background:new 0 0 480 480;" xml:space="preserve">
                                <g>
                                    <g>
                                        <path d="M272,176.232h-64c-4.418,0-8,3.582-8,8v224c0,4.418,3.582,8,8,8h64c4.418,0,8-3.582,8-8v-224
                                            C280,179.813,276.418,176.232,272,176.232z M264,400.232h-48v-208h48V400.232z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M464,144.232h-64c-4.418,0-8,3.582-8,8v256c0,4.418,3.582,8,8,8h64c4.418,0,8-3.582,8-8v-256
                                            C472,147.813,468.418,144.232,464,144.232z M456,400.232h-48v-240h48V400.232z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M368,320.232h-64c-4.418,0-8,3.582-8,8v80c0,4.418,3.582,8,8,8h64c4.418,0,8-3.582,8-8v-80
                                            C376,323.813,372.418,320.232,368,320.232z M360,400.232h-48v-64h48V400.232z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M80,208.232H16c-4.418,0-8,3.582-8,8v192c0,4.418,3.582,8,8,8h64c4.418,0,8-3.582,8-8v-192
                                            C88,211.813,84.418,208.232,80,208.232z M72,400.232H24v-176h48V400.232z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M176,256.232h-64c-4.418,0-8,3.582-8,8v144c0,4.418,3.582,8,8,8h64c4.418,0,8-3.582,8-8v-144
                                            C184,259.813,180.418,256.232,176,256.232z M168,400.232h-48v-128h48V400.232z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M432.465,7.769c-17.801-0.128-32.335,14.198-32.463,31.999c-0.065,8.988,3.626,17.595,10.183,23.743l-66.4,121.784
                                            c-6.015-1.665-12.404-1.37-18.24,0.84L263.776,93.44c11.835-13.125,10.789-33.36-2.337-45.194s-33.36-10.789-45.194,2.337
                                            c-8.695,9.644-10.701,23.586-5.077,35.29L162.6,126.296c-13.324-9.719-31.884-7.544-42.6,4.992L79.272,110.92
                                            c3.694-17.283-7.323-34.288-24.605-37.981c-17.283-3.694-34.288,7.322-37.981,24.605c-3.694,17.283,7.322,34.288,24.605,37.981
                                            c2.205,0.471,4.454,0.708,6.709,0.707c9.225-0.03,17.982-4.064,24-11.056l40.728,20.368c-3.843,17.25,7.026,34.35,24.276,38.193
                                            c17.25,3.843,34.35-7.026,38.193-24.276c1.563-7.015,0.719-14.352-2.397-20.829l48.568-40.424
                                            c8.371,6.195,19.299,7.759,29.072,4.16l61.752,92.696c-11.803,13.154-10.707,33.386,2.448,45.189
                                            c13.154,11.803,33.386,10.707,45.189-2.448c11.658-12.993,10.752-32.931-2.036-44.813l66.4-121.784
                                            c2.55,0.666,5.173,1.01,7.808,1.024c17.801,0.128,32.335-14.198,32.463-31.999S450.265,7.898,432.465,7.769z M48,120.232
                                            c-8.837,0-16-7.163-16-16s7.163-16,16-16s16,7.163,16,16S56.837,120.232,48,120.232z M144,168.232c-8.837,0-16-7.163-16-16
                                            s7.163-16,16-16s16,7.163,16,16S152.837,168.232,144,168.232z M240,88.232c-8.837,0-16-7.163-16-16s7.163-16,16-16s16,7.163,16,16
                                            S248.837,88.232,240,88.232z M336,232.232c-8.837,0-16-7.163-16-16s7.163-16,16-16s16,7.163,16,16S344.837,232.232,336,232.232z
                                             M432,56.232c-8.837,0-16-7.163-16-16s7.163-16,16-16s16,7.163,16,16S440.837,56.232,432,56.232z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M472,424.232H8c-4.418,0-8,3.582-8,8v32c0,4.418,3.582,8,8,8h464c4.418,0,8-3.582,8-8v-32
                                            C480,427.813,476.418,424.232,472,424.232z M464,456.232H16v-16h448V456.232z"/>
                                    </g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                </svg>
                                <div class="ml-4 text-lg leading-7 font-semibold"><a class="text-gray-900">Statistics</a></div>
                            </div>

                            <div class="ml-12">
                                <div class="mt-2 text-gray-600 text-sm">
                                    Process and analyze great amounts of data, in order to measure performances of your respective players.
                                </div>
                            </div>
                        </div>

                        <div class="p-6 border-t border-gray-200 dark:border-gray-200 md:border-t-0 md:border-l">
                            <div class="flex items-center">
                                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" height="2em" width="2em"
                                     viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <g>
                                        <path d="M256,0C136.384,0,42.667,42.176,42.667,96S136.384,192,256,192s213.333-42.176,213.333-96S375.616,0,256,0z M256,170.667
                                            c-113.152,0-192-39.36-192-74.667s78.848-74.667,192-74.667S448,60.693,448,96S369.152,170.667,256,170.667z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M458.667,192c-5.888,0-10.667,4.779-10.667,10.667c0,35.307-78.848,74.667-192,74.667s-192-39.36-192-74.667
                                            C64,196.779,59.221,192,53.333,192s-10.667,4.779-10.667,10.667c0,53.824,93.717,96,213.333,96s213.333-42.176,213.333-96
                                            C469.333,196.779,464.555,192,458.667,192z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M458.667,298.667c-5.888,0-10.667,4.779-10.667,10.667C448,344.64,369.152,384,256,384S64,344.64,64,309.333
                                            c0-5.888-4.779-10.667-10.667-10.667s-10.667,4.779-10.667,10.667c0,53.824,93.717,96,213.333,96s213.333-42.176,213.333-96
                                            C469.333,303.445,464.555,298.667,458.667,298.667z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M458.667,85.333C452.779,85.333,448,90.112,448,96v320c0,35.307-78.848,74.667-192,74.667S64,451.307,64,416V96
                                            c0-5.888-4.779-10.667-10.667-10.667S42.667,90.112,42.667,96v320c0,53.824,93.717,96,213.333,96s213.333-42.176,213.333-96V96
                                            C469.333,90.112,464.555,85.333,458.667,85.333z"/>
                                    </g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                </svg>
                                <div class="ml-4 text-lg leading-7 font-semibold"><a class="text-gray-900">Database</a></div>
                            </div>

                            <div class="ml-12">
                                <div class="mt-2 text-gray-600 text-sm">
                                    Store your data securely within our database.
                                </div>
                            </div>
                        </div>

                        <div class="p-6 border-t border-gray-200 dark:border-gray-200">
                            <div class="flex items-center">
                                <svg viewBox="0 0 496 496.002" xmlns="http://www.w3.org/2000/svg" height="2em" width="2em">
                                    <path d="m488 392.003906h-48v-80c0-25.1875-10.6875-47.875-27.703125-63.929687 17.703125-16.578125 27.703125-39.425781 27.703125-64.070313v-80h48c3.234375 0 6.152344-1.953125 7.394531-4.9375 1.238281-2.992187.550781-6.433594-1.738281-8.71875l-88-88c-3.128906-3.128906-8.183594-3.128906-11.3125 0l-88 88c-2.285156 2.285156-2.972656 5.726563-1.734375 8.71875 1.238281 2.984375 4.160156 4.9375 7.390625 4.9375h48v64c0 13.230469-10.765625 24-24 24h-16c0-50.898437-34.152344-93.890625-80.710938-107.464844l21.609376-37.042968c10.886718-2.269532 19.101562-11.933594 19.101562-23.492188 0-13.234375-10.765625-23.99999975-24-23.99999975-10.71875 0-19.710938 7.10937475-22.78125 16.83203175l-106.96875 14.261718c-3.554688-8.832031-12.167969-15.09375-22.25-15.09375-13.230469 0-24 10.765625-24 24 0 1.359375.183594 2.671875.402344 3.972656l-51.898438 44.480469c-1.453125-.277343-2.957031-.453125-4.503906-.453125-13.230469 0-24 10.765625-24 24 0 13.230469 10.769531 24 24 24 1.289062 0 2.539062-.1875 3.769531-.386718l29.769531 38.695312c-.832031 5.203125-1.433593 10.472656-1.523437 15.882812l-55.261719 118.421876c-1.160156 2.480468-.96875 5.375.503906 7.679687 1.464844 2.3125 4.007813 3.707031 6.742188 3.707031h48v96c0 4.414063 3.585938 8 8 8h80v72h16v-80c0-4.417968-3.582031-8-8-8h-80v-96c0-4.417968-3.582031-8-8-8h-43.4375l50.6875-108.617187c.367188-.785157.457031-1.65625.558594-2.511719l31.007812 40.3125c-8.96875 7.335938-14.816406 18.351562-14.816406 30.816406 0 22.054688 17.945312 40 40 40 22.058594 0 40-17.945312 40-40 0-11.265625-4.71875-21.417968-12.238281-28.699218l33.121093-59.621094c1.03125.140625 2.054688.320312 3.117188.320312 13.234375 0 24-10.769531 24-24 0-6.339844-2.511719-12.058594-6.535156-16.355468l21.449218-36.765626c41.886719 10.320313 73.085938 48.09375 73.085938 93.121094h-104v16h136c22.058594 0 40-17.945312 40-40v-72c0-4.417968-3.582031-8-8-8h-36.6875l68.6875-68.691406 68.6875 68.691406h-36.6875c-4.414062 0-8 3.582032-8 8v88c0 20.980469-8.933594 40.324219-24.542969 54.007813-13.710937-8.824219-29.976562-14.007813-47.457031-14.007813h-152v16h152c39.695312 0 72 32.300782 72 72v88c0 4.414063 3.585938 8 8 8h36.6875l-68.6875 68.6875-68.6875-68.6875h36.6875c4.417969 0 8-3.585937 8-8v-72c0-22.058594-17.941406-40-40-40h-136v16h92.121094l-35.375 76.644532c-.496094 1.050781-.746094 2.195312-.746094 3.355468v112h16v-110.242187l37.738281-81.757813h26.261719c13.234375 0 24 10.765625 24 24v64h-48c-3.230469 0-6.152344 1.949219-7.390625 4.933594-1.238281 2.992188-.550781 6.433594 1.734375 8.71875l88 88c1.5625 1.5625 3.609375 2.347656 5.65625 2.347656 2.050781 0 4.097656-.785156 5.65625-2.347656l88-88c2.289062-2.285156 2.976562-5.726562 1.738281-8.71875-1.242187-2.984375-4.160156-4.933594-7.394531-4.933594zm-317.734375-250.027344-67.792969-19.933593c10.777344-10.097657 23.824219-17.761719 38.34375-22.058594l32.945313 36.601563c-1.382813 1.632812-2.585938 3.425781-3.496094 5.390624zm-85.152344-25.046874-38.046875-11.191407c-.855468-3.128906-2.3125-5.984375-4.257812-8.464843l45.65625-39.136719c4.199218 3.609375 9.585937 5.867187 15.535156 5.867187 1.394531 0 2.738281-.1875 4.074219-.410156l21.128906 23.480469c-17.042969 6.320312-32.097656 16.640625-44.089844 29.855469zm37.128907-61.511719c2.03125-2.398438 3.574218-5.183594 4.542968-8.246094l106.96875-14.265625c2.007813 4.992188 5.65625 9.085938 10.253906 11.769531l-21.246093 36.414063c-4.839844-.640625-9.746094-1.085938-14.761719-1.085938h-40c-7.429688 0-14.679688.75-21.710938 2.140625zm133.757812-39.414063c4.410156 0 8 3.589844 8 8 0 4.40625-3.589844 8-8 8-4.40625 0-8-3.59375-8-8 0-4.410156 3.59375-8 8-8zm-152 16c4.410156 0 8 3.589844 8 8 0 4.40625-3.589844 8-8 8-4.40625 0-8-3.59375-8-8 0-4.410156 3.59375-8 8-8zm-88 80c0-4.410156 3.59375-8 8-8 4.410156 0 8 3.589844 8 8 0 4.40625-3.589844 8-8 8-4.40625 0-8-3.59375-8-8zm25.929688 15.789063c1.527343-1.726563 2.824218-3.648438 3.800781-5.757813l28.808593 8.472656c-4.921874 7.453126-8.953124 15.527344-12 24.078126zm86.070312 160.210937c-13.230469 0-24-10.769531-24-24 0-13.234375 10.769531-24 24-24 13.234375 0 24 10.765625 24 24 0 13.230469-10.765625 24-24 24zm0-64c-3.757812 0-7.328125.6875-10.78125 1.660156l-42.632812-55.421874c2.992187-12.847657 8.566406-24.671876 16.152343-34.976563l78.191407 23c1.054687 3.863281 2.992187 7.34375 5.671874 10.175781l-32.382812 58.296875c-4.433594-1.703125-9.195312-2.734375-14.21875-2.734375zm64-64c-4.40625 0-8-3.59375-8-8 0-4.410156 3.59375-8 8-8 4.410156 0 8 3.589844 8 8 0 4.40625-3.589844 8-8 8zm3.21875-31.675781c-1.066406-.140625-2.113281-.324219-3.21875-.324219-1.390625 0-2.734375.183594-4.070312.40625l-28.769532-31.960937c2.921875-.261719 5.855469-.445313 8.839844-.445313h40c1.992188 0 3.9375.175782 5.898438.292969zm0 0"/></svg>
                                <div class="ml-4 text-lg leading-7 font-semibold"><a class="text-gray-900">Decision Support</a></div>
                            </div>

                            <div class="ml-12">
                                <div class="mt-2 text-gray-600 text-sm">
                                    Find out your players best position using our decision support feature. Powered by Simple Additive Weigthing algorithm.
                                </div>
                            </div>
                        </div>

                        <div class="p-6 border-t border-gray-200 dark:border-gray-200 md:border-l">
                            <div class="flex items-center">
                                <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" height="2em" width="2em"
                                     viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
                                <g>
                                    <g>
                                        <path d="M488.399,492h-21.933V173.536c0-14.823-12.06-26.882-26.882-26.882H390.56c-14.823,0-26.882,12.06-26.882,26.882V492
                                            h-55.692V317.825c0-14.823-12.059-26.882-26.882-26.882H232.08c-14.823,0-26.882,12.06-26.882,26.882V492h-55.692v-90.204
                                            c0-14.823-12.06-26.882-26.882-26.882H73.599c-14.823,0-26.882,12.06-26.882,26.882V492H23.601c-5.523,0-10,4.477-10,10
                                            s4.477,10,10,10h464.798c5.523,0,10-4.477,10-10S493.922,492,488.399,492z M129.504,492H66.716v-90.204
                                            c0-3.795,3.087-6.882,6.882-6.882h49.024c3.795,0,6.882,3.087,6.882,6.882V492z M287.985,492h-62.788V317.825
                                            c0-3.795,3.087-6.882,6.882-6.882h49.024c3.794,0,6.882,3.087,6.882,6.882V492z M446.466,492h-62.788V173.536
                                            c0-3.795,3.087-6.882,6.882-6.882h49.024c3.795,0,6.882,3.087,6.882,6.882V492z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <path d="M466.442,10.516c0.14-2.729-0.82-5.504-2.904-7.588c-2.084-2.084-4.859-3.045-7.588-2.904
                                            C455.789,0.017,455.63,0,455.466,0h-60.5c-5.523,0-10,4.477-10,10s4.477,10,10,10h37.357l-98.857,98.858l-37.28-37.28
                                            c-1.875-1.875-4.419-2.929-7.071-2.929c-2.652,0-5.196,1.054-7.071,2.929l-179.769,179.77c-3.905,3.905-3.905,10.237,0,14.143
                                            c1.953,1.951,4.512,2.927,7.071,2.927s5.119-0.976,7.071-2.929L289.115,102.79l37.28,37.28c3.905,3.905,10.237,3.905,14.143,0
                                            L446.466,34.143v33.81c0,5.523,4.477,10,10,10s10-4.477,10-10V11C466.466,10.837,466.449,10.678,466.442,10.516z"/>
                                    </g>
                                </g>
                                <g>
                                    <g>
                                        <circle cx="75.64" cy="303.31" r="10"/>
                                    </g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                <g>
                                </g>
                                </svg>

                                <div class="ml-4 text-lg leading-7 font-semibold text-gray-900">Visualisation</div>
                            </div>

                            <div class="ml-12">
                                <div class="mt-2 text-gray-600 text-sm">
                                    From simple tables and charts, we have a range of visualization tools to help you understand complex data.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
