@push('head')
    <link
        href="/favicon.ico"
        id="favicon"
        rel="icon"
    >
@endpush

<p class="h1 n-m font-thin v-center">
    <x-orchid-icon path="soccer-field"/>

    <span class="m-l d-none d-sm-block">
        PitchSide
    </span>
</p>