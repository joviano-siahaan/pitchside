<p class="small m-n">
    © Copyright {{date('Y')}} <a href="//example.com" target="_blank">PitchSide</a>
</p>