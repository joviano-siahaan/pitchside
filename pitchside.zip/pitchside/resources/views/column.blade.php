<div class="row">
    <div class="col-md-6">
        <input type="text" name="name">
    </div>
    <div class="col-md-6">
        <input type="text" name="name">
    </div>
</div>